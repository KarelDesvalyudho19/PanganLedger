import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CloudRain, Database, Radar as RadarIcon, Sprout, TrendingDown, TrendingUp } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Card';
import { PriceForecastChart } from '../components/charts/PriceForecastChart';
import { Heatmap } from '../components/dashboard/Heatmap';
import { HARI_INI, KECAMATAN, KOMODITAS, heatmapSurplus, rekomendasi, seriHarga, type Kecamatan, type KomoditasKey } from '../data/radar';
import { pct, rp } from '../lib/format';

const REK_STYLE = {
  surplus: { icon: TrendingDown, cls: 'bg-amber-soft text-amber-ink', to: '/simulasi' },
  defisit: { icon: TrendingUp, cls: 'bg-brick-soft text-brick', to: '/dasbor' },
  cuaca: { icon: CloudRain, cls: 'bg-mint text-forest', to: '/radar' },
};

export default function RadarPage() {
  const [kom, setKom] = useState<KomoditasKey>('cabaiMerah');
  const [kec, setKec] = useState<Kecamatan>('Selupu Rejang');
  const k = KOMODITAS.find((x) => x.key === kom)!;

  const seri = useMemo(() => seriHarga(kom, kec), [kom, kec]);
  const grid = useMemo(() => heatmapSurplus(kom), [kom]);
  const rek = useMemo(() => rekomendasi(kom, kec), [kom, kec]);

  const idxHariIni = seri.findIndex((p) => p.prakiraan !== undefined);
  const hariIni = seri[idxHariIni];
  const sekarang = hariIni.aktual ?? 0;
  const akhir = seri[seri.length - 1].prakiraan ?? 0;
  const minPrak = Math.min(...seri.slice(idxHariIni + 1).map((p) => p.prakiraan ?? Infinity));
  const perubahan = ((akhir - sekarang) / sekarang) * 100;
  const tanggalHariIni = HARI_INI.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <>
      <PageHeader
        eyebrow="Radar Tanam & Harga"
        icon={<RadarIcon className="h-3.5 w-3.5" aria-hidden="true" />}
        title="Lihat panen raya sebelum harga jatuh"
        lead="Model deret waktu memprakirakan harga dan pasokan 4–8 minggu ke depan per kecamatan dari data harga pangan (PIHPS), cuaca (BMKG), dan catatan tanam petani."
        aside={
          <ul className="flex flex-wrap gap-2 text-[12px] font-semibold text-ink-soft">
            {['PIHPS harga harian', 'BMKG prakiraan hujan', 'Catatan tanam kelompok'].map((s) => (
              <li key={s} className="flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1.5">
                <Database className="h-3.5 w-3.5 text-forest" aria-hidden="true" /> {s}
              </li>
            ))}
          </ul>
        }
      />

      <div className="container-page space-y-6 py-10">
        {/* Filter */}
        <div className="card flex flex-col gap-4 p-4 sm:p-5 lg:flex-row lg:items-center lg:justify-between">
          <fieldset>
            <legend className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-mute">Komoditas</legend>
            <div className="flex flex-wrap gap-2">
              {KOMODITAS.map((c) => (
                <button
                  key={c.key}
                  type="button"
                  aria-pressed={kom === c.key}
                  onClick={() => setKom(c.key)}
                  className={`rounded-full px-3.5 py-2 text-[13px] font-semibold transition-colors ${kom === c.key ? 'bg-forest text-white' : 'border border-line bg-cream text-ink-soft hover:border-forest/40 hover:text-forest'}`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </fieldset>
          <div className="flex flex-col gap-1.5">
            <label htmlFor="pilih-kec" className="text-[11px] font-bold uppercase tracking-wider text-ink-mute">
              Kecamatan (Rejang Lebong)
            </label>
            <select
              id="pilih-kec"
              value={kec}
              onChange={(e) => setKec(e.target.value as Kecamatan)}
              className="h-10 rounded-full border border-line bg-cream px-4 text-sm font-semibold text-ink focus:border-forest focus:outline-none focus:ring-2 focus:ring-forest/20"
            >
              {KECAMATAN.map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Ringkasan */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Mini label={`Harga ${k.label.toLowerCase()} pekan ini`} value={rp(sekarang)} sub={`Tingkat petani, ${kec}`} />
          <Mini label="Prakiraan minggu ke-8" value={rp(akhir)} sub={`${perubahan >= 0 ? '+' : '–'}${pct(Math.abs(perubahan), 1)} dari hari ini`} tone={perubahan < 0 ? 'amber' : 'forest'} />
          <Mini label="Titik terendah prakiraan" value={rp(minPrak)} sub={minPrak < k.hpp * 1.1 ? 'Mendekati HPP: aktifkan kontrak' : 'Masih di atas HPP acuan'} tone={minPrak < k.hpp * 1.1 ? 'brick' : undefined} />
          <Mini label="Akurasi model (validasi)" value="MAPE 8,4%" sub="Uji mundur 26 minggu, simulasi" />
        </div>

        {/* Grafik + rekomendasi */}
        <div className="grid gap-6 xl:grid-cols-[1.6fr_1fr]">
          <Panel title={`Harga ${k.label.toLowerCase()} · ${kec}`} subtitle={`52 minggu terakhir dan prakiraan 8 minggu (per ${tanggalHariIni})`} simulasi>
            <div className="mb-3 flex flex-wrap gap-x-5 gap-y-2 text-[12px] font-semibold text-ink-soft">
              <span className="flex items-center gap-2"><span className="h-1 w-6 rounded bg-forest" aria-hidden="true" />Harga aktual</span>
              <span className="flex items-center gap-2"><span className="w-6 border-t-2 border-dashed border-amber" aria-hidden="true" />Prakiraan</span>
              <span className="flex items-center gap-2"><span className="h-3 w-6 rounded-sm bg-amber/20" aria-hidden="true" />Pita ketidakpastian 80%</span>
              <span className="flex items-center gap-2"><span className="w-6 border-t-2 border-dashed border-brick" aria-hidden="true" />HPP acuan</span>
            </div>
            <PriceForecastChart data={seri} hariIni={hariIni.tanggal} hpp={k.hpp} />
          </Panel>

          <section aria-labelledby="judul-rek" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 id="judul-rek" className="flex items-center gap-2 font-sans text-base font-bold tracking-normal text-ink">
                <Sprout className="h-4 w-4 text-forest" aria-hidden="true" /> Rekomendasi AI
              </h2>
              <span className="text-[11.5px] font-semibold text-ink-mute">diperbarui setiap Senin</span>
            </div>
            {rek.map((r) => {
              const st = REK_STYLE[r.jenis];
              const Icon = st.icon;
              return (
                <article key={r.judul} className="card p-5 transition-transform hover:-translate-y-0.5">
                  <div className="flex items-start gap-3">
                    <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${st.cls}`}>
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </span>
                    <div className="min-w-0">
                      <h3 className="font-sans text-[15px] font-bold tracking-normal text-ink">{r.judul}</h3>
                      <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-soft">{r.isi}</p>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center justify-between border-t border-line pt-3">
                    <span className="flex items-center gap-2 text-[11.5px] font-semibold text-ink-mute">
                      Keyakinan
                      <span className="h-1.5 w-16 overflow-hidden rounded-full bg-sand" aria-hidden="true">
                        <span className="block h-full rounded-full bg-forest" style={{ width: `${r.keyakinan}%` }} />
                      </span>
                      <span className="num">{r.keyakinan}%</span>
                    </span>
                    <Link to={st.to} className="inline-flex items-center gap-1 text-[12.5px] font-bold text-forest hover:underline">
                      {r.aksi} <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </Link>
                  </div>
                </article>
              );
            })}
          </section>
        </div>

        {/* Heatmap */}
        <Panel
          title={`Peta panas neraca pasokan ${k.label.toLowerCase()}`}
          subtitle="Selisih prakiraan pasokan terhadap kebutuhan (%) per kecamatan, 8 minggu ke depan. Klik nama kecamatan untuk melihat grafiknya."
          simulasi
        >
          <Heatmap grid={grid} selectedKec={kec} onSelectKec={setKec} />
        </Panel>
      </div>
    </>
  );
}

function Mini({ label, value, sub, tone }: { label: string; value: string; sub: string; tone?: 'amber' | 'forest' | 'brick' }) {
  const c = tone === 'amber' ? 'text-amber-ink' : tone === 'brick' ? 'text-brick' : tone === 'forest' ? 'text-forest' : 'text-ink-mute';
  return (
    <div className="card p-4 sm:p-5">
      <p className="text-[12px] font-semibold text-ink-mute">{label}</p>
      <p className="num mt-1.5 font-serif text-2xl text-ink">{value}</p>
      <p className={`mt-1 text-[12px] font-semibold ${c}`}>{sub}</p>
    </div>
  );
}
