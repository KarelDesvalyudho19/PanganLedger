import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ArrowDownRight, ArrowUpRight, BookOpen, Calculator, Link2, RotateCcw, ShieldCheck, Sprout, Wallet } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Card';
import { SliderField } from '../components/ui/SliderField';
import { PayoffChart } from '../components/charts/PayoffChart';
import { ScenarioBars } from '../components/charts/ScenarioBars';
import { SimBadge } from '../components/ui/SimBadge';
import { SIMULASI, SKENARIO, type SkenarioKey } from '../data/simulasi';
import { hitungKontrak } from '../lib/contract';
import { num, rp, rpJt, rpJtSigned } from '../lib/format';
import { useLedger } from '../lib/store';

const ZONA = {
  petani: { label: 'Floor aktif · petani terlindungi', cls: 'bg-mint text-forest' },
  pasar: { label: 'Di dalam koridor · harga pasar berlaku', cls: 'bg-sand text-ink-soft' },
  pembeli: { label: 'Ceiling aktif · pembeli terlindungi', cls: 'bg-amber-soft text-amber-ink' },
};

export default function Simulasi() {
  const { biayaSimulator, lepasDariSimulator } = useLedger();

  const [luasHa, setLuasHa] = useState<number>(SIMULASI.luasHa);
  const [produksiKg, setProduksiKg] = useState<number>(biayaSimulator?.produksiKg ?? SIMULASI.produksiKg);
  const [totalBiaya, setTotalBiaya] = useState<number>(biayaSimulator?.totalBiaya ?? SIMULASI.totalBiaya);
  const [marginPct, setMarginPct] = useState<number>(SIMULASI.marginFloorPct);
  const [ceiling, setCeiling] = useState<number>(SIMULASI.ceiling);
  const [hargaPasar, setHargaPasar] = useState<number>(SIMULASI.hargaPasarDefault);
  const [uangMukaPct, setUangMukaPct] = useState(15);

  // jika pengguna mengirim HPP baru dari Buku Biaya saat halaman terbuka
  useEffect(() => {
    if (biayaSimulator) {
      setTotalBiaya(biayaSimulator.totalBiaya);
      setProduksiKg(biayaSimulator.produksiKg);
    }
  }, [biayaSimulator]);

  const r = useMemo(
    () => hitungKontrak({ luasHa, produksiKg, totalBiaya, marginFloorPct: marginPct, ceiling, hargaPasar }),
    [luasHa, produksiKg, totalBiaya, marginPct, ceiling, hargaPasar],
  );

  const scenarioData = useMemo(
    () =>
      SKENARIO.map((s) => {
        const k = hitungKontrak({ luasHa, produksiKg, totalBiaya, marginFloorPct: marginPct, ceiling, hargaPasar: s.harga });
        return { nama: s.label, tanpa: Math.round(k.labaTanpa / 1e5) / 10, dengan: Math.round(k.labaDengan / 1e5) / 10, k, s };
      }),
    [luasHa, produksiKg, totalBiaya, marginPct, ceiling],
  );

  const aktif = SKENARIO.find((s) => s.harga === hargaPasar)?.key as SkenarioKey | undefined;

  const ubahLuas = (v: number) => {
    const ratio = v / luasHa;
    setLuasHa(v);
    setProduksiKg((p) => Math.round((p * ratio) / 100) * 100);
    setTotalBiaya((b) => Math.round((b * ratio) / 100_000) * 100_000);
  };

  const reset = () => {
    lepasDariSimulator();
    setLuasHa(SIMULASI.luasHa);
    setProduksiKg(SIMULASI.produksiKg);
    setTotalBiaya(SIMULASI.totalBiaya);
    setMarginPct(SIMULASI.marginFloorPct);
    setCeiling(SIMULASI.ceiling);
    setHargaPasar(SIMULASI.hargaPasarDefault);
    setUangMukaPct(15);
  };

  const selisihLaba = r.labaDengan - r.labaTanpa;
  const uangMuka = (uangMukaPct / 100) * r.floor * produksiKg;

  return (
    <>
      <PageHeader
        eyebrow="Simulator Kontrak Koridor"
        icon={<Calculator className="h-3.5 w-3.5" aria-hidden="true" />}
        title="Siapa menanggung risiko harga?"
        lead="Kontrak koridor menjamin harga minimum bagi petani (floor = HPP + margin wajar) dan harga maksimum bagi pembeli (ceiling). Geser harga pasar untuk melihat siapa yang terlindungi."
        aside={
          <div className="card flex items-center gap-3 px-4 py-3 text-sm">
            <span className="font-serif text-lg text-forest">ƒ</span>
            <span className="num font-semibold text-ink">
              Harga diterima = min(max(<span className="text-ink-mute">pasar</span>, floor), ceiling)
            </span>
          </div>
        }
      />

      <div className="container-page grid gap-6 py-10 lg:grid-cols-[360px_1fr] lg:items-start">
        {/* ---------- Input ---------- */}
        <aside className="lg:sticky lg:top-24">
          <Panel
            title="Parameter usaha tani"
            subtitle="Nilai awal: data simulasi cabai merah 0,5 ha"
            action={
              <button type="button" onClick={reset} className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1.5 text-xs font-semibold text-ink-mute hover:bg-sand hover:text-ink">
                <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" /> Atur ulang
              </button>
            }
          >
            {biayaSimulator && (
              <div className="mb-5 flex items-start gap-3 rounded-xl border border-forest/20 bg-mint-soft p-3 text-[13px]">
                <Link2 className="mt-0.5 h-4 w-4 shrink-0 text-forest" aria-hidden="true" />
                <p className="text-ink-soft">
                  Biaya & produksi diambil dari <Link to="/buku-biaya" className="font-semibold text-forest underline-offset-2 hover:underline">Buku Biaya Tani</Link>.{' '}
                  <button type="button" onClick={reset} className="font-semibold text-ink underline underline-offset-2">
                    Pakai data resmi
                  </button>
                </p>
              </div>
            )}
            <div className="space-y-6">
              <SliderField label="Luas lahan" value={luasHa} min={0.25} max={2} step={0.05} onChange={ubahLuas} display={`${num(luasHa, 2)} ha`} suffix="ha" inputWidth="w-14" hint="Mengubah luas ikut menskalakan produksi & biaya." />
              <SliderField label="Produksi" value={produksiKg} min={500} max={16000} step={100} onChange={setProduksiKg} display={`${num(produksiKg)} kg`} suffix="kg" inputWidth="w-20" hint={`Produktivitas ${num(produksiKg / luasHa / 1000, 1)} ton/ha`} />
              <SliderField
                label="Total biaya produksi"
                value={totalBiaya}
                min={5_000_000}
                max={300_000_000}
                step={500_000}
                onChange={setTotalBiaya}
                display={rpJt(totalBiaya)}
                prefix="Rp"
                inputWidth="w-28"
                hint={biayaSimulator ? 'Dari Buku Biaya Tani' : 'Manual, atau kirim dari Buku Biaya'}
              />
              <div className="h-px bg-line" />
              <SliderField label="Margin floor di atas HPP" value={marginPct} min={0} max={40} step={1} onChange={setMarginPct} display={`${marginPct}% → ${rp(r.floor)}`} suffix="%" inputWidth="w-10" hint="Dibulatkan ke kelipatan Rp500." />
              <SliderField label="Ceiling (batas atas)" value={ceiling} min={Math.max(5000, r.floor)} max={80000} step={500} onChange={setCeiling} display={rp(r.ceiling)} prefix="Rp" inputWidth="w-20" />
              <SliderField label="Uang muka pembeli" value={uangMukaPct} min={10} max={20} step={1} onChange={setUangMukaPct} display={`${uangMukaPct}% · ${rpJt(uangMuka)}`} suffix="%" inputWidth="w-10" hint="Disimpan di rekening koperasi/BUMDes." />
              <div className="h-px bg-line" />
              <SliderField label="Harga pasar saat panen" value={hargaPasar} min={0} max={70000} step={500} onChange={setHargaPasar} display={`${rp(hargaPasar)}/kg`} prefix="Rp" inputWidth="w-20" />
            </div>
          </Panel>
        </aside>

        {/* ---------- Output ---------- */}
        <div className="min-w-0 space-y-6">
          {/* KPI */}
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Kpi label="HPP per kg" value={rp(r.hpp)} sub={`${rpJt(totalBiaya)} ÷ ${num(produksiKg)} kg`} icon={<BookOpen className="h-4 w-4" />} />
            <Kpi label="Floor kontrak" value={rp(r.floor)} sub={`HPP + ${marginPct}% · ceiling ${rp(r.ceiling)}`} icon={<ShieldCheck className="h-4 w-4" />} />
            <Kpi label="Harga diterima petani" value={rp(r.hargaDiterima)} sub={ZONA[r.zona].label} icon={<Sprout className="h-4 w-4" />} highlight chipCls={ZONA[r.zona].cls} />
            <Kpi
              label="Posisi pembeli"
              value={r.selisihPembeliPerKg === 0 ? 'Impas' : `${r.selisihPembeliPerKg > 0 ? 'Bayar lebih' : 'Hemat'} ${rp(Math.abs(r.selisihPembeliPerKg))}`}
              sub={r.selisihPembeliPerKg === 0 ? 'Sama dengan harga pasar' : `per kg · total ${rpJt(Math.abs(r.selisihPembeliTotal))}`}
              icon={<Wallet className="h-4 w-4" />}
              tone={r.selisihPembeliPerKg > 0 ? 'amber' : r.selisihPembeliPerKg < 0 ? 'forest' : undefined}
            />
          </div>

          {/* Laba */}
          <div className="grid gap-4 md:grid-cols-[1fr_1fr_0.9fr]">
            <LabaCard label="Laba tanpa kontrak" value={r.labaTanpa} muted />
            <LabaCard label="Laba dengan kontrak" value={r.labaDengan} />
            <div className={`card flex flex-col justify-center p-5 ${selisihLaba >= 0 ? 'bg-mint-soft' : 'bg-amber-soft/60'}`}>
              <p className="text-xs font-bold uppercase tracking-wider text-ink-mute">Efek kontrak bagi petani</p>
              <p className={`num mt-2 flex items-center gap-1.5 font-serif text-[1.7rem] leading-none ${selisihLaba > 0 ? 'text-forest' : selisihLaba < 0 ? 'text-amber-ink' : 'text-ink'}`}>
                {selisihLaba > 0 ? <ArrowUpRight className="h-5 w-5" aria-hidden="true" /> : selisihLaba < 0 ? <ArrowDownRight className="h-5 w-5" aria-hidden="true" /> : null}
                {selisihLaba === 0 ? 'Rp0' : rpJtSigned(selisihLaba)}
              </p>
              <p className="mt-2 text-[12.5px] leading-snug text-ink-soft">
                {selisihLaba > 0
                  ? 'Risiko rugi dipindahkan ke pembeli lewat floor.'
                  : selisihLaba < 0
                    ? 'Petani melepas sebagian laba ekstrem sebagai “premi” kepastian.'
                    : 'Harga di dalam koridor: kontrak netral bagi kedua pihak.'}
              </p>
            </div>
          </div>

          {/* Payoff chart */}
          <Panel
            title="Grafik payoff laba petani"
            subtitle="Laba musim (juta rupiah) pada setiap tingkat harga pasar"
            simulasi
          >
            <div className="mb-3 flex flex-wrap gap-x-5 gap-y-2 text-[12px] font-semibold text-ink-soft">
              <Legend swatch={<span className="h-0.5 w-6 border-t-2 border-dashed border-[#8A959C]" />} label="Tanpa kontrak" />
              <Legend swatch={<span className="h-1 w-6 rounded bg-forest" />} label="Dengan kontrak" />
              <Legend swatch={<span className="h-3.5 w-0 border-l-2 border-dashed border-brick" />} label="HPP (titik impas)" />
              <Legend swatch={<span className="h-3 w-5 rounded-sm bg-forest/15" />} label="Zona perlindungan petani" />
              <Legend swatch={<span className="h-3 w-5 rounded-sm bg-amber/25" />} label="Zona perlindungan pembeli" />
            </div>
            <PayoffChart produksiKg={produksiKg} totalBiaya={totalBiaya} hpp={r.hpp} floor={r.floor} ceiling={r.ceiling} hargaPasar={hargaPasar} />
          </Panel>

          {/* Skenario */}
          <Panel title="Tiga skenario harga panen" subtitle="Klik skenario untuk memindahkan harga pasar" simulasi>
            <div className="grid gap-3 sm:grid-cols-3" role="group" aria-label="Pilih skenario harga">
              {scenarioData.map(({ s, k }) => {
                const on = aktif === s.key;
                return (
                  <button
                    key={s.key}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setHargaPasar(s.harga)}
                    className={`rounded-2xl border p-4 text-left transition-all ${on ? 'border-forest bg-forest text-white shadow-[var(--shadow-lift)]' : 'border-line bg-cream hover:-translate-y-0.5 hover:border-forest/40 hover:bg-white'}`}
                  >
                    <span className={`text-xs font-bold uppercase tracking-wider ${on ? 'text-white/70' : 'text-ink-mute'}`}>{s.label}</span>
                    <span className="num mt-1 block font-serif text-2xl">{rp(s.harga)}</span>
                    <span className={`mt-1 block text-[12px] leading-snug ${on ? 'text-white/80' : 'text-ink-mute'}`}>{s.deskripsi}</span>
                    <span className={`num mt-3 flex justify-between border-t pt-2 text-[12.5px] font-semibold ${on ? 'border-white/20' : 'border-line'}`}>
                      <span className={on ? 'text-white/80' : k.labaTanpa < 0 ? 'text-brick' : 'text-ink-soft'}>{rpJtSigned(k.labaTanpa)}</span>
                      <span>→ {rpJtSigned(k.labaDengan)}</span>
                    </span>
                  </button>
                );
              })}
            </div>
            <div className="mt-6">
              <div className="mb-2 flex flex-wrap gap-x-5 gap-y-2 text-[12px] font-semibold text-ink-soft">
                <Legend swatch={<span className="h-3 w-3 rounded-sm bg-[#8A959C]" />} label="Tanpa kontrak (merah bila rugi)" />
                <Legend swatch={<span className="h-3 w-3 rounded-sm bg-forest" />} label="Dengan kontrak" />
              </div>
              <ScenarioBars data={scenarioData.map(({ nama, tanpa, dengan }) => ({ nama, tanpa, dengan }))} active={SKENARIO.find((s) => s.key === aktif)?.label} />
            </div>
            <div className="relative mt-4 overflow-x-auto">
              <table className="table-clean w-full min-w-[520px] text-sm">
                <thead>
                  <tr>
                    <th scope="col">Skenario</th>
                    <th scope="col" className="!text-right">Harga pasar</th>
                    <th scope="col" className="!text-right">Diterima petani</th>
                    <th scope="col" className="!text-right">Laba tanpa</th>
                    <th scope="col" className="!text-right">Laba dengan</th>
                    <th scope="col" className="!text-right">Pembeli/kg</th>
                  </tr>
                </thead>
                <tbody className="num">
                  {scenarioData.map(({ s, k }) => (
                    <tr key={s.key} className={aktif === s.key ? 'bg-mint-soft/60' : ''}>
                      <td className="font-semibold">{s.label}</td>
                      <td className="text-right">{rp(s.harga)}</td>
                      <td className="text-right font-semibold">{rp(k.hargaDiterima)}</td>
                      <td className={`text-right ${k.labaTanpa < 0 ? 'text-brick' : ''}`}>{rpJtSigned(k.labaTanpa)}</td>
                      <td className="text-right font-semibold text-forest">{rpJtSigned(k.labaDengan)}</td>
                      <td className="whitespace-nowrap text-right text-[13px] text-ink-soft">
                        {k.selisihPembeliPerKg === 0 ? 'Impas' : k.selisihPembeliPerKg > 0 ? `+${rp(k.selisihPembeliPerKg)}` : `–${rp(-k.selisihPembeliPerKg)}`}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>

          <p className="flex items-center gap-2 text-[12px] text-ink-mute">
            <SimBadge /> Perhitungan memakai rumus kontrak sebenarnya; angka usaha tani adalah data simulasi.
          </p>
        </div>
      </div>
    </>
  );
}

function Kpi({ label, value, sub, icon, highlight, chipCls, tone }: { label: string; value: string; sub: string; icon: ReactNode; highlight?: boolean; chipCls?: string; tone?: 'forest' | 'amber' }) {
  return (
    <div className={`card p-4 sm:p-5 ${highlight ? 'border-forest/40 ring-1 ring-forest/15' : ''}`}>
      <p className="flex items-center gap-2 text-[12px] font-semibold text-ink-mute">
        <span className="text-forest" aria-hidden="true">{icon}</span>
        {label}
      </p>
      <p className={`num mt-2 font-serif text-[1.55rem] leading-tight ${tone === 'amber' ? 'text-amber-ink' : tone === 'forest' ? 'text-forest' : 'text-ink'}`}>{value}</p>
      {chipCls ? <p className={`mt-2 inline-block rounded-full px-2 py-0.5 text-[11px] font-bold ${chipCls}`}>{sub}</p> : <p className="mt-1.5 text-[12px] leading-snug text-ink-mute">{sub}</p>}
    </div>
  );
}

function LabaCard({ label, value, muted }: { label: string; value: number; muted?: boolean }) {
  const neg = value < 0;
  return (
    <div className={`card p-5 ${muted ? '' : 'border-forest/30'}`}>
      <p className="text-xs font-bold uppercase tracking-wider text-ink-mute">{label}</p>
      <p className={`num mt-2 font-serif text-[2rem] leading-none ${neg ? 'text-brick' : muted ? 'text-ink' : 'text-forest'}`}>{rpJtSigned(value)}</p>
      <p className="mt-2 text-[12.5px] text-ink-mute">{neg ? 'Rugi: penerimaan di bawah total biaya' : 'Penerimaan dikurangi total biaya musim'}</p>
    </div>
  );
}

function Legend({ swatch, label }: { swatch: ReactNode; label: string }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span className="flex w-6 items-center justify-center" aria-hidden="true">
        {swatch}
      </span>
      {label}
    </span>
  );
}
