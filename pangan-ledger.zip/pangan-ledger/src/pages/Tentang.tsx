import { BookOpen, Check, ChartLine, GraduationCap, Info, Minus, Scale, UserRound } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { SectionHeading } from '../components/ui/SectionHeading';
import { Reveal } from '../components/ui/Reveal';
import { ButtonLink } from '../components/ui/Button';

const TEORI = [
  {
    icon: BookOpen,
    judul: 'Akuntansi biaya full costing',
    isi: 'HPP dihitung dari seluruh biaya produksi, baik tetap maupun variabel: benih, pupuk, pestisida, mulsa & ajir, tenaga kerja, sewa lahan, dan penyusutan. Tenaga kerja keluarga dinilai dengan upah harian setempat (biaya implisit), dijurnal Debit Biaya TK Keluarga / Kredit Modal Pemilik.',
    rumus: 'HPP/kg = Σ biaya produksi ÷ produksi (kg)',
  },
  {
    icon: Scale,
    judul: 'Kontrak forward dengan collar',
    isi: 'Kontrak beli di muka dengan batas bawah dan atas (collar) membagi risiko harga: petani memperoleh jaminan harga minimum, pembeli memperoleh jaminan harga maksimum. Uang muka 10–20% berfungsi sebagai jaminan pelaksanaan.',
    rumus: 'P* = min(max(P pasar, floor), ceiling)',
  },
  {
    icon: ChartLine,
    judul: 'Prakiraan deret waktu',
    isi: 'Model musiman (mis. SARIMAX atau gradient boosting dengan fitur lag) memprakirakan harga dan pasokan 4–8 minggu dengan variabel eksogen curah hujan BMKG dan luas tanam. Ketidakpastian ditampilkan sebagai pita prakiraan.',
    rumus: 'ŷ(t+h) = f(y(t), y(t−52), hujan, luas tanam)',
  },
];

type Nilai = 'ya' | 'tidak' | 'sebagian';
const KOLOM = ['Dasbor harga', 'Marketplace pertanian', 'Contract farming biasa', 'Asuransi pertanian', 'PANGAN-LEDGER'];
const PERBANDINGAN: { aspek: string; nilai: Nilai[] }[] = [
  { aspek: 'Menghitung HPP petani', nilai: ['tidak', 'tidak', 'sebagian', 'tidak', 'ya'] },
  { aspek: 'Prakiraan harga & pasokan per kecamatan', nilai: ['sebagian', 'tidak', 'tidak', 'tidak', 'ya'] },
  { aspek: 'Harga minimum terjamin bagi petani', nilai: ['tidak', 'tidak', 'ya', 'sebagian', 'ya'] },
  { aspek: 'Perlindungan harga bagi pembeli', nilai: ['tidak', 'tidak', 'sebagian', 'tidak', 'ya'] },
  { aspek: 'Petani tetap menikmati kenaikan harga', nilai: ['ya', 'ya', 'tidak', 'ya', 'sebagian'] },
  { aspek: 'Alokasi surplus & rute logistik', nilai: ['tidak', 'sebagian', 'tidak', 'tidak', 'ya'] },
  { aspek: 'Data peringatan dini untuk TPID', nilai: ['sebagian', 'tidak', 'tidak', 'tidak', 'ya'] },
];

const RISIKO = [
  { risiko: 'Pembeli ingkar saat harga anjlok', mitigasi: 'Uang muka 10–20% ditahan di rekening koperasi/BUMDes; prioritas pembeli kelembagaan (BUMD, SPPG).' },
  { risiko: 'Petani menjual ke pihak lain saat harga melonjak (side selling)', mitigasi: 'Ceiling disepakati di atas harga rata-rata musiman; bonus loyalitas dan akses kontrak musim berikutnya.' },
  { risiko: 'Data biaya tidak lengkap atau dilebih-lebihkan', mitigasi: 'Validasi silang dengan standar biaya per hektare dinas dan verifikasi penyuluh pada sampel petani.' },
  { risiko: 'Akurasi prakiraan rendah pada kejadian ekstrem', mitigasi: 'Pita ketidakpastian ditampilkan; keputusan kontrak tetap berbasis floor HPP, bukan semata prakiraan.' },
  { risiko: 'Literasi digital dan sinyal terbatas di desa', mitigasi: 'PWA ringan yang bisa luring, pesan suara berbahasa sehari-hari, dan pendamping kelompok tani.' },
  { risiko: 'Kepatuhan regulasi pembayaran dan dana titipan', mitigasi: 'Dana dikelola lembaga berbadan hukum (koperasi/BUMDes) dengan rekening terpisah dan laporan berkala.' },
];

function Sel({ v, highlight }: { v: Nilai; highlight?: boolean }) {
  if (v === 'ya')
    return (
      <span className={`mx-auto flex h-7 w-7 items-center justify-center rounded-full ${highlight ? 'bg-forest text-white' : 'bg-mint text-forest'}`}>
        <Check className="h-4 w-4" aria-hidden="true" />
        <span className="sr-only">Ya</span>
      </span>
    );
  if (v === 'sebagian')
    return (
      <span className="mx-auto flex h-7 w-7 items-center justify-center rounded-full bg-amber-soft text-amber-ink">
        <span className="text-[13px] font-bold" aria-hidden="true">½</span>
        <span className="sr-only">Sebagian</span>
      </span>
    );
  return (
    <span className="mx-auto flex h-7 w-7 items-center justify-center rounded-full bg-sand text-ink-mute">
      <Minus className="h-4 w-4" aria-hidden="true" />
      <span className="sr-only">Tidak</span>
    </span>
  );
}

export default function Tentang() {
  return (
    <>
      <PageHeader
        eyebrow="Tentang gagasan"
        icon={<Info className="h-3.5 w-3.5" aria-hidden="true" />}
        title="Lindung nilai harga yang lahir dari buku biaya petani"
        lead="PANGAN-LEDGER adalah platform web (PWA) yang memadukan kecerdasan buatan dan akuntansi biaya untuk melindungi petani hortikultura dan menstabilkan harga pangan di Provinsi Bengkulu, dimulai dari sentra sayur Rejang Lebong dan Kepahiang yang memasok Kota Bengkulu."
      />

      <div className="container-page py-14">
        {/* Ringkasan */}
        <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:gap-14">
          <Reveal>
            <p className="eyebrow">Ringkasan gagasan</p>
            <h2 className="mt-3 text-3xl leading-tight sm:text-4xl">Masalahnya bukan hanya harga, tetapi siapa yang menanggung risikonya.</h2>
          </Reveal>
          <Reveal delay={0.08} className="space-y-4 text-[15.5px] leading-relaxed text-ink-soft">
            <p>
              Harga cabai, tomat, dan sayur di Bengkulu bergejolak tajam. Saat panen raya, harga di tingkat petani jatuh di bawah biaya produksi; saat pasokan langka, konsumen kota menanggung inflasi. Petani bertindak sebagai price taker karena tidak menghitung HPP, menanam serentak tanpa data, dan tidak memiliki instrumen lindung nilai.
            </p>
            <p>
              PANGAN-LEDGER menjawabnya dengan tiga modul yang saling terhubung: <strong className="text-ink">Buku Biaya Tani Otomatis</strong> menghasilkan HPP yang dapat dipertanggungjawabkan, <strong className="text-ink">Radar Tanam & Harga</strong> memprakirakan pasokan dan harga per kecamatan, dan <strong className="text-ink">Kontrak Koridor & Alokasi Pasokan</strong> mengikat HPP itu menjadi harga minimum yang dijamin pembeli, sekaligus memberi pembeli batas harga maksimum.
            </p>
            <p>Hasil simulasi untuk petani cabai 0,5 ha: saat harga anjlok ke Rp6.000/kg, rugi Rp48 jt berubah menjadi laba Rp8 jt; saat harga melonjak ke Rp60.000/kg, pembeli menghemat Rp20.000/kg.</p>
          </Reveal>
        </div>

        {/* Teori */}
        <section className="pt-20">
          <SectionHeading eyebrow="Landasan teori" title="Tiga pijakan keilmuan" />
          <div className="mt-10 grid gap-5 lg:grid-cols-3">
            {TEORI.map((t, i) => (
              <Reveal key={t.judul} delay={i * 0.06} className="h-full">
                <article className="card flex h-full flex-col p-6">
                  <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-mint text-forest">
                    <t.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-5 text-xl text-ink">{t.judul}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-ink-soft">{t.isi}</p>
                  <p className="num mt-auto pt-5">
                    <span className="block rounded-xl bg-cream px-3.5 py-2.5 font-mono text-[12.5px] font-semibold text-forest ring-1 ring-line">{t.rumus}</span>
                  </p>
                </article>
              </Reveal>
            ))}
          </div>
        </section>

        {/* Perbandingan */}
        <section className="pt-20">
          <SectionHeading eyebrow="Posisi" title="Perbandingan dengan solusi yang sudah ada" lead="Solusi lain menjawab sebagian masalah. PANGAN-LEDGER menggabungkan pencatatan biaya, prakiraan, dan pembagian risiko dalam satu alur." />
          <Reveal className="mt-10">
            <div className="card scrollbar-thin overflow-x-auto">
              <table className="table-clean w-full min-w-[780px] text-sm">
                <caption className="sr-only">Perbandingan fitur PANGAN-LEDGER dengan solusi lain</caption>
                <thead>
                  <tr>
                    <th scope="col" className="w-[30%]">Aspek</th>
                    {KOLOM.map((k, i) => (
                      <th key={k} scope="col" className={`!text-center ${i === KOLOM.length - 1 ? 'bg-mint-soft !text-forest' : ''}`}>
                        {k}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {PERBANDINGAN.map((r) => (
                    <tr key={r.aspek}>
                      <th scope="row" className="!border-b !border-line !py-3.5 !text-left !text-[13.5px] !font-medium !normal-case !tracking-normal !text-ink">
                        {r.aspek}
                      </th>
                      {r.nilai.map((v, i) => (
                        <td key={i} className={i === r.nilai.length - 1 ? 'bg-mint-soft' : ''}>
                          <Sel v={v} highlight={i === r.nilai.length - 1} />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-3 text-[12px] text-ink-mute">“Sebagian” pada PANGAN-LEDGER untuk kenaikan harga: petani tetap menikmati harga pasar hingga ceiling, lalu berbagi manfaat dengan pembeli.</p>
          </Reveal>
        </section>

        {/* Risiko */}
        <section className="pt-20">
          <SectionHeading eyebrow="Risiko & mitigasi" title="Yang bisa salah, dan cara kami mengantisipasinya" />
          <Reveal className="mt-10">
            <div className="card overflow-hidden">
              <ul className="divide-y divide-line">
                {RISIKO.map((r, i) => (
                  <li key={r.risiko} className="grid gap-2 p-5 sm:grid-cols-[48px_1fr_1.3fr] sm:gap-6 sm:p-6">
                    <span className="num font-serif text-2xl text-line">{String(i + 1).padStart(2, '0')}</span>
                    <p className="font-semibold text-ink">{r.risiko}</p>
                    <p className="text-sm leading-relaxed text-ink-soft">
                      <span className="mr-1.5 inline-block rounded-full bg-mint px-2 py-0.5 text-[10.5px] font-bold uppercase tracking-wide text-forest">Mitigasi</span>
                      {r.mitigasi}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </section>

        {/* Tim */}
        <section className="pt-20">
          <SectionHeading eyebrow="Tim" title="Universitas Bengkulu" lead="Tim lintas disiplin informatika dan akuntansi. Nama anggota dilengkapi pada versi akhir." />
          <div className="mt-10 grid gap-4 sm:grid-cols-3">
            {['Ketua tim', 'Anggota', 'Anggota'].map((peran, i) => (
              <Reveal key={i} delay={i * 0.06}>
                <div className="card flex items-center gap-4 p-5">
                  <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full border-2 border-dashed border-forest/30 bg-mint-soft text-forest">
                    <UserRound className="h-6 w-6" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="font-bold text-ink">[Nama anggota]</p>
                    <p className="text-[13px] text-ink-mute">{peran} · [Program studi]</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-4">
            <div className="card flex items-center gap-4 p-5">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-amber-soft text-amber-ink">
                <GraduationCap className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <p className="font-bold text-ink">[Nama dosen pendamping]</p>
                <p className="text-[13px] text-ink-mute">Dosen pendamping · Universitas Bengkulu</p>
              </div>
            </div>
          </Reveal>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <ButtonLink to="/simulasi">Coba Simulator Kontrak</ButtonLink>
            <ButtonLink to="/buku-biaya" variant="secondary">
              Coba Buku Biaya Tani
            </ButtonLink>
          </div>
        </section>
      </div>
    </>
  );
}
