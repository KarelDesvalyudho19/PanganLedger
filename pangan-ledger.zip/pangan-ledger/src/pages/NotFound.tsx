import { ButtonLink } from '../components/ui/Button';

export default function NotFound() {
  return (
    <section className="container-page flex min-h-[50vh] flex-col items-center justify-center py-20 text-center">
      <p className="eyebrow">404</p>
      <h1 className="mt-3 text-4xl">Halaman tidak ditemukan</h1>
      <p className="mt-3 max-w-md text-ink-soft">Mungkin tautannya berubah. Kembali ke beranda untuk menjelajahi purwarupa PANGAN-LEDGER.</p>
      <ButtonLink to="/" className="mt-8">Kembali ke beranda</ButtonLink>
    </section>
  );
}
