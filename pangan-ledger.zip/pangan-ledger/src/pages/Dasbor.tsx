import { FileText, Handshake, PiggyBank, Scale, ShieldCheck } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Card';
import { ContractTable } from '../components/dashboard/ContractTable';
import { AllocationPanel } from '../components/dashboard/AllocationPanel';
import { RouteMap } from '../components/dashboard/RouteMap';
import { CountUp } from '../components/ui/CountUp';
import { KONTRAK } from '../data/kontrak';
import { rpJt } from '../lib/format';

export default function Dasbor() {
  const volume = KONTRAK.reduce((s, k) => s + k.volumeKg, 0);
  const uangMuka = KONTRAK.filter((k) => k.statusUangMuka !== 'Menunggu').reduce((s, k) => s + (k.uangMukaPct / 100) * k.floor * k.volumeKg * (k.statusUangMuka === 'Sebagian' ? 0.5 : 1), 0);
  const nilaiFloor = KONTRAK.reduce((s, k) => s + k.floor * k.volumeKg, 0);
  const kelompok = new Set(KONTRAK.map((k) => k.kelompok)).size;

  const kpi = [
    { icon: Handshake, label: 'Kontrak aktif', value: KONTRAK.length, fmt: (v: number) => Math.round(v).toString(), sub: `${kelompok} kelompok tani` },
    { icon: ShieldCheck, label: 'Volume terlindungi', value: volume / 1000, fmt: (v: number) => `${v.toLocaleString('id-ID', { maximumFractionDigits: 1 })} ton`, sub: '5 komoditas hortikultura' },
    { icon: PiggyBank, label: 'Uang muka tersimpan', value: uangMuka, fmt: (v: number) => rpJt(v), sub: 'Rekening koperasi/BUMDes' },
    { icon: Scale, label: 'Nilai minimum terjamin', value: nilaiFloor, fmt: (v: number) => rpJt(v), sub: 'Volume × floor' },
  ];

  return (
    <>
      <PageHeader
        eyebrow="Dasbor Kontrak & Alokasi"
        icon={<FileText className="h-3.5 w-3.5" aria-hidden="true" />}
        title="Kontrak, uang muka, dan pasokan dalam satu layar"
        lead="Koperasi atau BUMDes memantau kontrak koridor yang berjalan, memastikan uang muka pembeli tersimpan, lalu mengalokasikan surplus panen ke tujuan dengan nilai bersih terbaik melalui rute hijau."
      />
      <div className="container-page space-y-6 py-10">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {kpi.map((k) => (
            <div key={k.label} className="card p-5">
              <p className="flex items-center gap-2 text-[12px] font-semibold text-ink-mute">
                <k.icon className="h-4 w-4 text-forest" aria-hidden="true" /> {k.label}
              </p>
              <CountUp value={k.value} format={k.fmt} className="mt-2 block font-serif text-[1.9rem] leading-tight text-ink" />
              <p className="mt-1 text-[12px] text-ink-mute">{k.sub}</p>
            </div>
          ))}
        </div>

        <Panel title="Kontrak koridor aktif" subtitle="Musim tanam Oktober–Desember 2026" simulasi>
          <ContractTable />
        </Panel>

        <div className="grid gap-6 xl:grid-cols-[1fr_1.35fr]">
          <Panel title="Alokasi pasokan" subtitle="Nilai bersih = harga tujuan – biaya angkut per kg. Diisi berurutan sesuai kapasitas." simulasi>
            <AllocationPanel />
          </Panel>
          <Panel title="Rute hijau Rejang Lebong → Kota Bengkulu" subtitle="Empat titik jemput digabung lewat hub koperasi di Curup. Peta skematis." simulasi>
            <RouteMap />
          </Panel>
        </div>
      </div>
    </>
  );
}
