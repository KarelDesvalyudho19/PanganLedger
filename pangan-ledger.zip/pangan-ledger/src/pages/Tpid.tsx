import type { ReactNode } from 'react';
import { TriangleAlert, ArrowDownRight, ArrowUpRight, BellRing, Handshake, Landmark, Percent, ShieldCheck, Wheat } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Card';
import { SpreadChart } from '../components/charts/SpreadChart';
import { CountUp } from '../components/ui/CountUp';
import { HARGA_PETANI_KONSUMEN, HARGA_STRATEGIS, NERACA_MINGGU_DEPAN, PERINGATAN, VOLUME_TERLINDUNGI_KG, type Level } from '../data/tpid';
import { KONTRAK } from '../data/kontrak';
import { num, pct, rp } from '../lib/format';

const LEVEL: Record<Level, { label: string; cls: string; dot: string }> = {
  tinggi: { label: 'Tinggi', cls: 'bg-brick-soft text-brick', dot: 'bg-brick' },
  sedang: { label: 'Sedang', cls: 'bg-amber-soft text-amber-ink', dot: 'bg-amber' },
  rendah: { label: 'Rendah', cls: 'bg-mint text-forest', dot: 'bg-forest' },
};

export default function Tpid() {
  const last = HARGA_PETANI_KONSUMEN[HARGA_PETANI_KONSUMEN.length - 1];
  const rataSelisih = HARGA_PETANI_KONSUMEN.reduce((s, d) => s + d.selisih, 0) / HARGA_PETANI_KONSUMEN.length;
  const cabai = NERACA_MINGGU_DEPAN[0];

  return (
    <>
      <PageHeader
        eyebrow="Dasbor Pemerintah · TPID"
        icon={<Landmark className="h-3.5 w-3.5" aria-hidden="true" />}
        title="Peringatan dini untuk pengendalian inflasi daerah"
        lead="Data agregat dari buku biaya petani, kontrak koridor, dan prakiraan pasokan membantu TPID, Dinas TPHP, dan Bank Indonesia Bengkulu bertindak sebelum harga bergejolak."
      />
      <div className="container-page space-y-6 py-10">
        {/* KPI */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <Kpi icon={Percent} label="Inflasi Prov. Bengkulu (yoy)" value={<CountUp value={3.96} format={(v) => pct(v)} />} sub="Triwulan II 2026 · cabai merah pendorong utama" tone="amber" />
          <Kpi icon={Wheat} label="Cabai merah, konsumen" value={rp(last.konsumen)} sub={`Petani ${rp(last.petani)}/kg · Okt 2026`} />
          <Kpi icon={BellRing} label="Neraca cabai minggu depan" value={`+${pct(cabai.selisihPct, 1)}`} sub={`${num(cabai.pasokan)} t pasokan vs ${num(cabai.kebutuhan)} t kebutuhan`} tone="amber" />
          <Kpi icon={Handshake} label="Kontrak koridor aktif" value={<CountUp value={KONTRAK.length} />} sub="Floor rata-rata ≥ HPP + 11%" />
          <Kpi icon={ShieldCheck} label="Volume terlindungi" value={<CountUp value={VOLUME_TERLINDUNGI_KG / 1000} format={(v) => `${v.toLocaleString('id-ID', { maximumFractionDigits: 1 })} ton`} />} sub="Dari pilot Rejang Lebong" tone="forest" />
        </div>

        <div className="grid gap-6 xl:grid-cols-[1.5fr_1fr]">
          <Panel title="Harga cabai merah: petani vs konsumen" subtitle={`Rejang Lebong → Kota Bengkulu, 12 bulan. Rata-rata selisih ${rp(rataSelisih)}/kg.`} simulasi>
            <div className="mb-3 flex flex-wrap gap-x-5 gap-y-2 text-[12px] font-semibold text-ink-soft">
              <span className="flex items-center gap-2"><span className="h-1 w-6 rounded bg-amber" aria-hidden="true" />Konsumen</span>
              <span className="flex items-center gap-2"><span className="h-1 w-6 rounded bg-forest" aria-hidden="true" />Petani</span>
              <span className="flex items-center gap-2"><span className="h-3 w-6 rounded-sm bg-brick/15" aria-hidden="true" />Selisih (disparitas)</span>
            </div>
            <SpreadChart data={HARGA_PETANI_KONSUMEN} />
          </Panel>

          <Panel title="Harga rata-rata komoditas strategis" subtitle="Tingkat konsumen, Kota Bengkulu, pekan ini" simulasi>
            <ul className="divide-y divide-line">
              {HARGA_STRATEGIS.map((h) => {
                const up = h.perubahan > 0;
                return (
                  <li key={h.komoditas} className="flex items-center justify-between gap-3 py-3">
                    <span className="font-medium text-ink">{h.komoditas}</span>
                    <span className="flex items-center gap-3">
                      <span className="num font-bold text-ink">{rp(h.harga)}</span>
                      <span className={`num inline-flex w-[72px] items-center justify-end gap-0.5 text-[12.5px] font-bold ${up ? 'text-brick' : 'text-forest'}`}>
                        {up ? <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" /> : <ArrowDownRight className="h-3.5 w-3.5" aria-hidden="true" />}
                        {pct(Math.abs(h.perubahan), 1)}
                      </span>
                    </span>
                  </li>
                );
              })}
            </ul>
            <h4 className="mt-5 text-[11px] font-bold uppercase tracking-wider text-ink-mute">Neraca pasokan minggu depan (ton)</h4>
            <ul className="mt-3 space-y-3">
              {NERACA_MINGGU_DEPAN.map((n) => {
                const s = n.selisihPct;
                const w = Math.min(Math.abs(s), 20) * 2.5;
                return (
                  <li key={n.komoditas} className="grid grid-cols-[96px_1fr_56px] items-center gap-3 text-[12.5px]">
                    <span className="truncate text-ink-soft">{n.komoditas}</span>
                    <span className="relative h-2.5 rounded-full bg-sand" aria-hidden="true">
                      <span className="absolute left-1/2 top-[-3px] h-4 w-px bg-ink/30" />
                      <span className={`absolute top-0 h-full rounded-full ${s >= 0 ? 'left-1/2 bg-amber' : 'right-1/2 bg-brick'}`} style={{ width: `${w}%` }} />
                    </span>
                    <span className={`num text-right font-bold ${s >= 0 ? 'text-amber-ink' : 'text-brick'}`}>
                      {s >= 0 ? '+' : '–'}
                      {pct(Math.abs(s), 1)}
                    </span>
                  </li>
                );
              })}
            </ul>
            <p className="mt-3 text-[11.5px] text-ink-mute">Kiri: defisit · kanan: surplus terhadap kebutuhan.</p>
          </Panel>
        </div>

        <Panel title="Peringatan dini" subtitle="Diurutkan menurut tingkat risiko terhadap inflasi dan pendapatan petani" simulasi>
          <ul className="grid gap-4 md:grid-cols-2">
            {PERINGATAN.map((p) => {
              const lv = LEVEL[p.level];
              return (
                <li key={p.komoditas + p.wilayah} className="flex gap-4 rounded-2xl border border-line bg-cream/60 p-4 sm:p-5">
                  <span className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${lv.cls}`}>
                    <TriangleAlert className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`rounded-full px-2 py-0.5 text-[10.5px] font-bold uppercase tracking-wide ${lv.cls}`}>Risiko {lv.label}</span>
                      <span className="text-[11.5px] font-semibold text-ink-mute">{p.waktu}</span>
                    </div>
                    <h3 className="mt-2 font-sans text-[15px] font-bold tracking-normal text-ink">
                      {p.jenis}: {p.komoditas} · {p.wilayah}
                    </h3>
                    <p className="mt-1 text-[13.5px] leading-relaxed text-ink-soft">{p.isi}</p>
                    <p className="mt-2 text-[13px] font-semibold text-forest">Saran: {p.saran}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        </Panel>
      </div>
    </>
  );
}

function Kpi({ icon: Icon, label, value, sub, tone }: { icon: typeof Percent; label: string; value: ReactNode; sub: string; tone?: 'amber' | 'forest' }) {
  return (
    <div className="card p-5">
      <p className="flex items-center gap-2 text-[12px] font-semibold text-ink-mute">
        <Icon className={`h-4 w-4 ${tone === 'amber' ? 'text-amber-ink' : 'text-forest'}`} aria-hidden="true" /> {label}
      </p>
      <p className={`num mt-2 font-serif text-[1.75rem] leading-tight ${tone === 'amber' ? 'text-amber-ink' : tone === 'forest' ? 'text-forest' : 'text-ink'}`}>{value}</p>
      <p className="mt-1 text-[12px] leading-snug text-ink-mute">{sub}</p>
    </div>
  );
}
