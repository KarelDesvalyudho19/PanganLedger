import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  BookOpen,
  Building2,
  Calculator,
  CloudRain,
  GraduationCap,
  Handshake,
  Landmark,
  Leaf,
  Newspaper,
  Radar,
  Route,
  Scale,
  ShieldCheck,
  Sprout,
  TrendingDown,
  Users,
  Wheat,
} from 'lucide-react';
import { ButtonLink } from '../components/ui/Button';
import { HeroLandscape } from '../components/ui/Illustrations';
import { HeroMockup } from '../components/landing/HeroMockup';
import { StatCard } from '../components/ui/StatCard';
import { CountUp } from '../components/ui/CountUp';
import { SectionHeading } from '../components/ui/SectionHeading';
import { Reveal } from '../components/ui/Reveal';
import { SupplyChainDiagram } from '../components/landing/SupplyChainDiagram';
import { ModuleCard } from '../components/landing/ModuleCard';
import { Timeline } from '../components/landing/Timeline';
import { DAMPAK, MITRA, PETA_JALAN, STATISTIK, STAT_HPP } from '../data/landing';
import { rp } from '../lib/format';

const MASALAH = [
  { icon: TrendingDown, judul: 'Harga bergejolak', isi: 'Cabai, tomat, dan sayur naik-turun tajam. Inflasi Bengkulu naik ke 3,96% (yoy) pada triwulan II 2026 dengan cabai merah sebagai pendorong utama.' },
  { icon: Wheat, judul: 'Panen raya jadi petaka', isi: 'Saat panen serentak, harga di kebun jatuh di bawah biaya produksi. Sayur pernah dibuang ke jurang dan tomat busuk menutup jalan di Rejang Lebong.' },
  { icon: Calculator, judul: 'Petani tanpa angka', isi: 'Petani adalah price taker: tidak menghitung HPP, menanam serentak tanpa data, dan tidak punya instrumen lindung nilai harga.' },
  { icon: Scale, judul: 'Paradoks sentra pangan', isi: 'Rejang Lebong memasok sayur Kota Bengkulu, tetapi prevalensi kekurangan konsumsi pangannya 11,61% (2025), tertinggi di provinsi.' },
];

const DAMPAK_ICON = { users: Users, shield: ShieldCheck, scale: Scale, leaf: Leaf, route: Route };
const MITRA_ICON = { academic: GraduationCap, gov: Landmark, business: Building2, community: Users, media: Newspaper };

export default function Landing() {
  const location = useLocation();

  useEffect(() => {
    const id = (location.state as { scrollTo?: string } | null)?.scrollTo;
    if (!id) return;
    const t = window.setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
    return () => window.clearTimeout(t);
  }, [location.state]);

  return (
    <>
      {/* ================= HERO ================= */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(70%_60%_at_85%_10%,#DCEBE3_0%,transparent_60%),radial-gradient(50%_50%_at_0%_100%,#F6EADB_0%,transparent_70%)]" aria-hidden="true" />
        <HeroLandscape className="pointer-events-none absolute bottom-0 left-1/2 -z-10 w-[1100px] max-w-none -translate-x-1/2 opacity-70" />
        <div className="container-page grid items-center gap-14 pb-20 pt-10 sm:pt-16 lg:grid-cols-[1.08fr_1fr] lg:gap-10 lg:pb-28 lg:pt-20">
          <div>
            <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="inline-flex items-center gap-2 rounded-full border border-forest/20 bg-white/80 px-3 py-1.5 text-xs font-semibold text-forest">
              <Sprout className="h-3.5 w-3.5" aria-hidden="true" />
              Pilot: sentra sayur Rejang Lebong → Kota Bengkulu
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.05 }}
              className="mt-6 text-[2.35rem] leading-[1.06] text-ink sm:text-5xl lg:text-[3.6rem]"
            >
              Petani tahu biayanya, pasar tahu pasokannya, <em className="font-serif not-italic text-forest">risiko harga dibagi adil.</em>
            </motion.h1>
            <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.12 }} className="mt-6 max-w-xl text-lg leading-relaxed text-ink-soft">
              PANGAN-LEDGER memadukan kecerdasan buatan dan akuntansi biaya: mencatat HPP petani hortikultura secara otomatis, memprakirakan harga dan pasokan, lalu mengikatnya dalam kontrak koridor yang melindungi petani dan pembeli sekaligus.
            </motion.p>
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }} className="mt-8 flex flex-col gap-3 sm:flex-row">
              <ButtonLink to="/simulasi" className="px-6 py-3">
                Coba Simulasi Kontrak <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </ButtonLink>
              <ButtonLink to="/dasbor" variant="secondary" className="px-6 py-3">
                Lihat Dasbor
              </ButtonLink>
            </motion.div>
            <motion.dl initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.35 }} className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-line pt-6">
              {[
                ['–Rp48 jt', '→ +Rp8 jt', 'laba saat harga anjlok'],
                ['Rp18.000', 'per kg', 'HPP tercatat otomatis'],
                ['8 minggu', 'ke depan', 'prakiraan harga & pasokan'],
              ].map(([a, b, c]) => (
                <div key={c}>
                  <dt className="sr-only">{c}</dt>
                  <dd>
                    <span className="num block text-[15px] font-extrabold text-ink sm:text-lg">{a}</span>
                    <span className="num block text-[13px] font-semibold text-forest">{b}</span>
                    <span className="mt-1 block text-[11.5px] leading-snug text-ink-mute">{c}</span>
                  </dd>
                </div>
              ))}
            </motion.dl>
          </div>
          <HeroMockup />
        </div>
      </section>

      {/* ================= STATISTIK ================= */}
      <section aria-label="Data kunci" className="container-page -mt-6 lg:-mt-10">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STATISTIK.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.06} className="h-full">
              <StatCard nilai={s.nilai} digits={s.digits} label={s.label} keterangan={s.keterangan} sumber={s.sumber} tone={s.tone} />
            </Reveal>
          ))}
          <Reveal delay={0.18} className="h-full">
            <div className="card relative flex h-full flex-col overflow-hidden p-5 transition-transform duration-300 hover:-translate-y-1 sm:p-6">
              <span className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-forest to-brick" aria-hidden="true" />
              <div className="flex items-end gap-2">
                <span className="num font-serif text-[2rem] leading-none text-forest">±{rp(STAT_HPP.hpp)}</span>
              </div>
              <div className="mt-1 flex items-center gap-2 text-sm font-semibold">
                <span className="text-ink-mute">vs</span>
                <span className="num font-serif text-2xl text-brick">
                  {rp(STAT_HPP.hargaRendah)}–{rp(STAT_HPP.hargaTinggi).replace('Rp', '')}
                </span>
              </div>
              <div className="mt-3 flex h-2 overflow-hidden rounded-full bg-sand" aria-hidden="true">
                <span className="h-full w-[12.5%] rounded-full bg-brick" />
              </div>
              <p className="mt-3 text-sm font-semibold leading-snug text-ink">{STAT_HPP.label}</p>
              <p className="mt-auto pt-4 text-[11px] font-medium text-ink-mute">Sumber: {STAT_HPP.sumber}</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ================= MASALAH ================= */}
      <section id="masalah" className="container-page scroll-mt-24 pt-24 sm:pt-28">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          <div>
            <SectionHeading
              eyebrow="Masalah"
              title={<>Sentra sayur yang petaninya justru paling rentan</>}
              lead="Di Rejang Lebong, harga ditentukan jauh dari kebun. Tanpa catatan biaya dan tanpa data pasokan, petani menanam serentak, lalu menanggung sendiri seluruh risiko harga."
            />
            <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
              {MASALAH.map((m, i) => (
                <li key={m.judul}>
                <Reveal delay={i * 0.05} className="flex gap-4">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white text-brick shadow-[var(--shadow-soft)] ring-1 ring-line">
                      <m.icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <div>
                      <p className="font-bold text-ink">{m.judul}</p>
                      <p className="mt-1 text-sm leading-relaxed text-ink-soft">{m.isi}</p>
                    </div>
                </Reveal>
                </li>
              ))}
            </ul>
          </div>
          <div className="lg:pt-6">
            <SupplyChainDiagram />
          </div>
        </div>
      </section>

      {/* ================= SOLUSI ================= */}
      <section id="solusi" className="container-page scroll-mt-24 pt-24 sm:pt-32">
        <SectionHeading
          eyebrow="Solusi"
          align="center"
          title="Tiga modul, satu buku besar pangan"
          lead="Setiap modul bisa dipakai terpisah, tetapi kekuatannya ada pada data yang saling mengalir: biaya menjadi HPP, HPP menjadi floor kontrak, prakiraan menjadi alokasi pasokan."
        />
        <div className="mt-12 grid gap-5 lg:grid-cols-3">
          <Reveal className="h-full">
            <ModuleCard
              nomor="01"
              icon={Radar}
              judul="Radar Tanam & Harga"
              tagline="Kecerdasan buatan"
              isi="Prakiraan deret waktu harga dan pasokan 4–8 minggu per kecamatan dari data PIHPS dan cuaca BMKG."
              poin={['Peringatan dini kelebihan pasokan', 'Rekomendasi geser jadwal tanam atau komoditas', 'Peta panas surplus–defisit per kecamatan']}
              to="/radar"
              cta="Buka Radar"
            />
          </Reveal>
          <Reveal delay={0.08} className="h-full">
            <ModuleCard
              nomor="02"
              icon={BookOpen}
              judul="Buku Biaya Tani Otomatis"
              tagline="Akuntansi biaya"
              isi="Petani cukup mengetik atau mengirim pesan suara. Sistem menjurnal biaya dan menghitung HPP per kg secara berjalan."
              poin={['“beli NPK 2 karung 600 ribu” → Debit Biaya Pupuk / Kredit Kas', 'Tenaga kerja keluarga dihitung sebagai biaya implisit', 'HPP real-time dan komposisi biaya']}
              to="/buku-biaya"
              cta="Coba Buku Biaya"
              accent="amber"
            />
          </Reveal>
          <Reveal delay={0.16} className="h-full">
            <ModuleCard
              nomor="03"
              icon={Handshake}
              judul="Kontrak Koridor & Alokasi"
              tagline="Lindung nilai harga"
              isi="Kontrak beli di muka dengan batas bawah (floor) dan batas atas (ceiling). Uang muka 10–20% disimpan di rekening koperasi/BUMDes."
              poin={['Harga diterima = min(max(pasar, floor), ceiling)', 'Surplus dialokasikan ke nilai bersih terbaik', '“Rute hijau” menggabungkan titik jemput']}
              to="/simulasi"
              cta="Jalankan Simulator"
            />
          </Reveal>
        </div>

        <Reveal className="mt-6">
          <div className="card flex flex-col items-start gap-4 bg-forest p-6 text-white sm:flex-row sm:items-center sm:justify-between sm:p-7">
            <div className="flex min-w-0 items-center gap-4">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/10">
                <Calculator className="h-5 w-5" aria-hidden="true" />
              </span>
              <p className="font-serif text-xl leading-snug sm:text-2xl">
                Harga diterima petani = <span className="text-[#F0C58E] sm:whitespace-nowrap">min(max(harga pasar, floor), ceiling)</span>
              </p>
            </div>
            <ButtonLink to="/simulasi" variant="light" className="shrink-0">
              Uji rumusnya <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </ButtonLink>
          </div>
        </Reveal>
      </section>

      {/* ================= CARA KERJA ================= */}
      <section id="cara-kerja" className="container-page scroll-mt-24 pt-24 sm:pt-32">
        <SectionHeading eyebrow="Cara kerja" title="Dari catatan harian sampai laporan musim" lead="Enam langkah yang menyatukan petani, pembeli, dan pemerintah daerah dalam satu alur data." />
        <div className="mt-12">
          <Timeline />
        </div>
      </section>

      {/* ================= DAMPAK ================= */}
      <section id="dampak" className="mt-24 bg-mint-soft py-20 sm:mt-32 sm:py-24">
        <div className="container-page">
          <div className="grid items-end gap-6 lg:grid-cols-[1fr_auto]">
            <SectionHeading
              eyebrow="Dampak & ekonomi hijau"
              title="Indikator yang kami ukur sejak musim pertama"
              lead="Target pilot satu musim tanam di Rejang Lebong. Setiap angka dapat ditelusuri ke buku besar biaya, kontrak, dan catatan distribusi."
            />
            <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-ink-mute ring-1 ring-line">
              <CloudRain className="h-3.5 w-3.5 text-forest" aria-hidden="true" /> Target, bukan capaian
            </span>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {DAMPAK.map((d, i) => {
              const Icon = DAMPAK_ICON[d.icon];
              return (
                <Reveal key={d.indikator} delay={i * 0.05} className="h-full">
                  <div className="card flex h-full flex-col p-5">
                    <Icon className="h-5 w-5 text-forest" aria-hidden="true" />
                    <p className="mt-4 flex items-baseline gap-1.5">
                      <CountUp
                        value={d.target}
                        format={(v) => `${d.target < 0 ? '–' : ''}${Math.round(Math.abs(v)).toLocaleString('id-ID')}`}
                        className="font-serif text-4xl text-ink"
                      />
                      <span className="text-sm font-bold text-ink-mute">{d.satuan}</span>
                    </p>
                    <p className="mt-2 text-sm font-semibold leading-snug text-ink">{d.indikator}</p>
                    <p className="mt-auto pt-3 text-[12px] text-ink-mute">{d.ket}</p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* ================= PETA JALAN ================= */}
      <section id="peta-jalan" className="container-page pt-24 sm:pt-32">
        <SectionHeading eyebrow="Peta jalan" title="24 bulan menuju skala provinsi" lead="Dimulai kecil di satu kabupaten, diuji satu musim tanam penuh, lalu diperluas bersama kelembagaan daerah." />
        <ol className="relative mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          <span className="absolute left-0 right-0 top-[22px] hidden h-px bg-gradient-to-r from-forest via-forest/40 to-amber lg:block" aria-hidden="true" />
          {PETA_JALAN.map((f, i) => (
            <li key={f.fase} className="relative">
              <Reveal delay={i * 0.08} className="h-full">
                <span className={`relative z-10 flex h-11 w-11 items-center justify-center rounded-full border-2 bg-cream font-serif text-lg font-semibold ${i === 3 ? 'border-amber text-amber-ink' : 'border-forest text-forest'}`}>{i + 1}</span>
                <div className="card mt-4 h-[calc(100%-3.75rem)] p-5">
                  <p className="text-xs font-bold uppercase tracking-[0.12em] text-ink-mute">{f.fase}</p>
                  <h3 className="mt-1.5 font-sans text-lg font-bold tracking-normal text-ink">{f.judul}</h3>
                  <ul className="mt-3 space-y-2">
                    {f.isi.map((x) => (
                      <li key={x} className="flex gap-2 text-sm text-ink-soft">
                        <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-forest/60" aria-hidden="true" />
                        {x}
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>
            </li>
          ))}
        </ol>
      </section>

      {/* ================= MITRA ================= */}
      <section id="mitra" className="container-page pt-24 sm:pt-32">
        <SectionHeading eyebrow="Kolaborasi pentahelix" align="center" title="Dirancang untuk dijalankan bersama" />
        <ul className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {MITRA.map((m, i) => {
            const Icon = MITRA_ICON[m.icon];
            return (
              <li key={m.peran}>
              <Reveal delay={i * 0.05} className="card flex h-full flex-col items-center p-5 text-center">
                  <span className="flex h-14 w-14 items-center justify-center rounded-full bg-mint-soft text-forest ring-1 ring-forest/15">
                    <Icon className="h-6 w-6" aria-hidden="true" />
                  </span>
                  <p className="mt-4 font-bold text-ink">{m.peran}</p>
                  <p className="mt-1.5 text-[13px] leading-relaxed text-ink-mute">{m.contoh}</p>
              </Reveal>
              </li>
            );
          })}
        </ul>
      </section>

      {/* ================= CTA ================= */}
      <section className="container-page pt-24 sm:pt-28">
        <Reveal>
          <div className="relative overflow-hidden rounded-[28px] bg-forest px-6 py-12 text-white sm:px-12 sm:py-16">
            <HeroLandscape className="pointer-events-none absolute -bottom-10 right-[-120px] w-[760px] max-w-none opacity-40 mix-blend-screen" />
            <div className="relative max-w-2xl">
              <p className="text-xs font-bold uppercase tracking-[0.14em] text-[#F0C58E]">Simulasi petani cabai 0,5 ha</p>
              <h2 className="mt-3 text-3xl leading-tight sm:text-[2.6rem]">Saat harga anjlok ke Rp6.000/kg, kontrak koridor mengubah rugi Rp48 jt menjadi laba Rp8 jt.</h2>
              <p className="mt-4 text-white/75">Geser harga pasar, ubah margin, dan lihat siapa yang terlindungi di setiap skenario.</p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <ButtonLink to="/simulasi" variant="light" className="px-6 py-3">
                  Coba Simulasi Kontrak <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </ButtonLink>
                <ButtonLink to="/buku-biaya" className="border border-white/25 bg-white/10 px-6 py-3 shadow-none hover:bg-white/15">
                  Catat biaya tani
                </ButtonLink>
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
