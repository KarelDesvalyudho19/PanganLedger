import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, BookOpen, Download, RotateCcw } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Card';
import { LedgerChat } from '../components/ledger/LedgerChat';
import { CostDonut } from '../components/charts/CostDonut';
import { SliderField } from '../components/ui/SliderField';
import { btn } from '../components/ui/Button';
import { CATEGORIES, CATEGORY_ORDER, CONTOH_SATU_MUSIM } from '../lib/parser';
import { ringkasLedger, useLedger } from '../lib/store';
import { num, rp, rpJt } from '../lib/format';

export default function BukuBiaya() {
  const { entries, produksiKg, setProduksiKg, replaceAll, reset, kirimKeSimulator } = useLedger();
  const navigate = useNavigate();
  const { perPos, total } = useMemo(() => ringkasLedger(entries), [entries]);
  const hpp = produksiKg > 0 ? total / produksiKg : 0;

  const rows = CATEGORY_ORDER.filter((k) => perPos[k]).map((k) => ({
    key: k,
    meta: CATEGORIES[k],
    nilai: perPos[k],
    transaksi: entries.filter((e) => e.result.category === k && e.result.ok).length,
  }));
  const tunai = rows.filter((r) => r.key !== 'tkKeluarga').reduce((s, r) => s + r.nilai, 0);
  const implisit = perPos.tkKeluarga ?? 0;

  const gunakan = () => {
    kirimKeSimulator({ totalBiaya: Math.round(total), produksiKg });
    navigate('/simulasi');
  };

  return (
    <>
      <PageHeader
        eyebrow="Buku Biaya Tani Otomatis"
        icon={<BookOpen className="h-3.5 w-3.5" aria-hidden="true" />}
        title="Cukup ketik seperti biasa, jurnalnya jadi sendiri"
        lead="Setiap pesan diubah menjadi jurnal biaya (debit/kredit) dan langsung memperbarui HPP per kg. Tenaga kerja keluarga ikut dihitung sebagai biaya implisit agar petani tahu harga terendah yang benar-benar menguntungkan."
        aside={
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => replaceAll(CONTOH_SATU_MUSIM)} className={btn('secondary')}>
              <Download className="h-4 w-4" aria-hidden="true" /> Muat contoh satu musim
            </button>
            <button type="button" onClick={reset} className={btn('ghost')}>
              <RotateCcw className="h-4 w-4" aria-hidden="true" /> Atur ulang
            </button>
          </div>
        }
      />

      <div className="container-page grid gap-6 py-10 lg:grid-cols-[1.25fr_1fr] lg:items-start">
        <LedgerChat />

        <div className="space-y-6 lg:sticky lg:top-24">
          {/* HPP */}
          <section className="card overflow-hidden" aria-label="Ringkasan HPP">
            <div className="bg-forest px-5 py-5 text-white sm:px-6">
              <p className="text-xs font-bold uppercase tracking-[0.14em] text-white/70">HPP berjalan</p>
              <p className="num mt-2 font-serif text-[2.6rem] leading-none">
                {rp(hpp)}
                <span className="ml-1.5 font-sans text-base font-semibold text-white/70">/kg</span>
              </p>
              <p className="num mt-2 text-sm text-white/75">
                {rpJt(total, 2)} ÷ {num(produksiKg)} kg perkiraan produksi
              </p>
            </div>
            <div className="grid grid-cols-2 divide-x divide-line border-b border-line">
              <div className="px-5 py-3.5">
                <p className="text-[11.5px] font-semibold text-ink-mute">Biaya tunai</p>
                <p className="num mt-0.5 font-bold text-ink">{rp(tunai)}</p>
              </div>
              <div className="px-5 py-3.5">
                <p className="text-[11.5px] font-semibold text-ink-mute">Biaya implisit (TK keluarga)</p>
                <p className="num mt-0.5 font-bold text-amber-ink">{rp(implisit)}</p>
              </div>
            </div>
            <div className="space-y-5 px-5 py-5 sm:px-6">
              <SliderField label="Produksi perkiraan" value={produksiKg} min={500} max={12000} step={100} onChange={setProduksiKg} display={`${num(produksiKg)} kg`} suffix="kg" inputWidth="w-20" hint="Dari luas tanam × produktivitas rata-rata kelompok." />
              <button type="button" onClick={gunakan} disabled={total <= 0} className={btn('primary', 'w-full py-3')}>
                Gunakan HPP ini di Simulator <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>
              {hpp > 0 && hpp < 5000 && (
                <p className="rounded-xl bg-amber-soft/70 px-3 py-2.5 text-[12.5px] leading-snug text-amber-ink">
                  Catatan baru berisi sebagian kecil biaya musim, sehingga HPP masih rendah. Muat contoh satu musim untuk melihat HPP Rp18.000/kg.
                </p>
              )}
            </div>
          </section>

          {/* Buku besar */}
          <Panel title="Buku besar per pos biaya" subtitle={`${entries.filter((e) => e.result.ok).length} jurnal tercatat`} simulasi>
            {rows.length === 0 ? (
              <p className="py-6 text-center text-sm text-ink-mute">Belum ada jurnal. Ketik pengeluaran pertama Anda.</p>
            ) : (
              <>
                <CostDonut data={rows.map((r) => ({ name: r.meta.label, value: r.nilai, color: r.meta.color }))} total={total} />
                <table className="table-clean mt-4 w-full text-sm">
                  <thead>
                    <tr>
                      <th scope="col" className="!px-0">Akun</th>
                      <th scope="col" className="!text-right">Trx</th>
                      <th scope="col" className="!px-0 !text-right">Saldo debit</th>
                    </tr>
                  </thead>
                  <tbody className="num">
                    {rows.map((r) => (
                      <tr key={r.key}>
                        <td className="!px-0">
                          <span className="flex items-center gap-2">
                            <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: r.meta.color }} aria-hidden="true" />
                            <span className="font-medium text-ink">{r.meta.akun}</span>
                          </span>
                        </td>
                        <td className="text-right text-ink-mute">{r.transaksi}</td>
                        <td className="!px-0 text-right font-semibold">{rp(r.nilai)}</td>
                      </tr>
                    ))}
                    <tr>
                      <td className="!px-0 font-bold">Total biaya produksi</td>
                      <td />
                      <td className="!px-0 text-right font-bold text-forest">{rp(total)}</td>
                    </tr>
                  </tbody>
                </table>
              </>
            )}
          </Panel>
        </div>
      </div>
    </>
  );
}
