export type StatusUangMuka = 'Diterima' | 'Sebagian' | 'Menunggu';
export type JenisPembeli = 'BUMD Pangan' | 'Katering' | 'Hotel' | 'Dapur SPPG';

export interface Kontrak {
  id: string;
  kelompok: string;
  kecamatan: string;
  komoditas: string;
  volumeKg: number;
  floor: number;
  ceiling: number;
  pembeli: string;
  jenisPembeli: JenisPembeli;
  uangMukaPct: number;
  statusUangMuka: StatusUangMuka;
  panen: string; // tanggal panen
}

export const KONTRAK: Kontrak[] = [
  { id: 'KK-2611-001', kelompok: 'KT Sumber Rezeki', kecamatan: 'Selupu Rejang', komoditas: 'Cabai merah', volumeKg: 4000, floor: 20000, ceiling: 40000, pembeli: 'BUMD Pangan Bengkulu', jenisPembeli: 'BUMD Pangan', uangMukaPct: 15, statusUangMuka: 'Diterima', panen: '18 Nov 2026' },
  { id: 'KK-2611-002', kelompok: 'KT Maju Bersama', kecamatan: 'Curup', komoditas: 'Tomat', volumeKg: 6500, floor: 4500, ceiling: 9000, pembeli: 'Dapur SPPG Curup', jenisPembeli: 'Dapur SPPG', uangMukaPct: 20, statusUangMuka: 'Diterima', panen: '12 Nov 2026' },
  { id: 'KK-2611-003', kelompok: 'KT Harapan Tani', kecamatan: 'Sindang Kelingi', komoditas: 'Kubis', volumeKg: 9000, floor: 2800, ceiling: 6000, pembeli: 'Katering Raflesia', jenisPembeli: 'Katering', uangMukaPct: 10, statusUangMuka: 'Menunggu', panen: '25 Nov 2026' },
  { id: 'KK-2611-004', kelompok: 'Gapoktan Bermani Jaya', kecamatan: 'Bermani Ulu', komoditas: 'Cabai rawit', volumeKg: 1800, floor: 26000, ceiling: 55000, pembeli: 'Hotel di Kota Bengkulu', jenisPembeli: 'Hotel', uangMukaPct: 15, statusUangMuka: 'Diterima', panen: '3 Des 2026' },
  { id: 'KK-2611-005', kelompok: 'KWT Melati', kecamatan: 'Kota Padang', komoditas: 'Bawang merah', volumeKg: 2500, floor: 22000, ceiling: 38000, pembeli: 'BUMD Pangan Bengkulu', jenisPembeli: 'BUMD Pangan', uangMukaPct: 20, statusUangMuka: 'Sebagian', panen: '9 Des 2026' },
  { id: 'KK-2611-006', kelompok: 'KT Sumber Rezeki', kecamatan: 'Selupu Rejang', komoditas: 'Kubis', volumeKg: 7000, floor: 2800, ceiling: 6000, pembeli: 'Dapur SPPG Kota Bengkulu', jenisPembeli: 'Dapur SPPG', uangMukaPct: 15, statusUangMuka: 'Diterima', panen: '15 Des 2026' },
  { id: 'KK-2611-007', kelompok: 'KT Tunas Baru', kecamatan: 'Curup', komoditas: 'Cabai merah', volumeKg: 3200, floor: 20500, ceiling: 40000, pembeli: 'Katering Raflesia', jenisPembeli: 'Katering', uangMukaPct: 10, statusUangMuka: 'Menunggu', panen: '29 Nov 2026' },
  { id: 'KK-2611-008', kelompok: 'KT Bukit Kaba Lestari', kecamatan: 'Selupu Rejang', komoditas: 'Tomat', volumeKg: 5000, floor: 4500, ceiling: 9000, pembeli: 'Hotel di Kota Bengkulu', jenisPembeli: 'Hotel', uangMukaPct: 20, statusUangMuka: 'Diterima', panen: '6 Des 2026' },
];

/* ---------------- Alokasi surplus ---------------- */

export const LOT_SURPLUS = {
  komoditas: 'Cabai merah',
  volumeKg: 2400,
  asal: 'KT Sumber Rezeki, Selupu Rejang',
  panen: '18 Nov 2026',
  hpp: 18000,
};

export interface Tujuan {
  nama: string;
  jenis: string;
  lokasi: string;
  harga: number; // Rp/kg
  angkut: number; // Rp/kg
  kapasitasKg: number;
}

export const TUJUAN: Tujuan[] = [
  { nama: 'Hotel mitra', jenis: 'Hotel', lokasi: 'Kota Bengkulu', harga: 27500, angkut: 1400, kapasitasKg: 300 },
  { nama: 'Pasar Panorama', jenis: 'Pasar kota', lokasi: 'Kota Bengkulu', harga: 26500, angkut: 1150, kapasitasKg: 1200 },
  { nama: 'BUMD Pangan', jenis: 'Pembeli kontrak', lokasi: 'Kota Bengkulu', harga: 25000, angkut: 900, kapasitasKg: 1000 },
  { nama: 'Dapur SPPG Curup', jenis: 'Dapur MBG', lokasi: 'Curup', harga: 24000, angkut: 250, kapasitasKg: 400 },
  { nama: 'Pasar Atas Curup', jenis: 'Pasar lokal', lokasi: 'Curup', harga: 23000, angkut: 150, kapasitasKg: 2000 },
];

export interface Alokasi extends Tujuan {
  bersih: number;
  alokasiKg: number;
  peringkat: number;
}

/** Alokasi rakus (greedy): isi tujuan dengan nilai bersih tertinggi lebih dulu sesuai kapasitas. */
export function alokasikan(volume: number, tujuan: Tujuan[] = TUJUAN): Alokasi[] {
  const sorted = [...tujuan].map((t) => ({ ...t, bersih: t.harga - t.angkut })).sort((a, b) => b.bersih - a.bersih);
  let sisa = volume;
  return sorted.map((t, i) => {
    const kgAlok = Math.max(0, Math.min(sisa, t.kapasitasKg));
    sisa -= kgAlok;
    return { ...t, alokasiKg: kgAlok, peringkat: i + 1 };
  });
}

/* ---------------- Rute hijau ---------------- */

export interface Titik {
  id: string;
  nama: string;
  x: number;
  y: number;
  jenis: 'jemput' | 'hub' | 'tujuan' | 'transit';
  muatanKg?: number;
}

/** Koordinat skematis (bukan peta asli), kanvas 640 × 420. */
export const TITIK: Titik[] = [
  { id: 'bu', nama: 'Bermani Ulu', x: 112, y: 60, jenis: 'jemput', muatanKg: 1800 },
  { id: 'sr', nama: 'Selupu Rejang', x: 176, y: 118, jenis: 'jemput', muatanKg: 2400 },
  { id: 'kp', nama: 'Kota Padang', x: 70, y: 262, jenis: 'jemput', muatanKg: 900 },
  { id: 'sk', nama: 'Sindang Kelingi', x: 92, y: 172, jenis: 'jemput', muatanKg: 1300 },
  { id: 'cu', nama: 'Curup (hub koperasi)', x: 222, y: 186, jenis: 'hub' },
  { id: 'kph', nama: 'Kepahiang', x: 330, y: 242, jenis: 'transit' },
  { id: 'kb', nama: 'Kota Bengkulu', x: 556, y: 342, jenis: 'tujuan' },
];

export const RUTE_HIJAU = ['bu', 'sr', 'sk', 'kp', 'cu', 'kph', 'kb'];

export const METRIK_RUTE = {
  kmTanpa: 296,
  kmDengan: 168,
  emisiFaktor: 0.84, // kg CO2e per km truk engkel (asumsi simulasi)
  muatanTon: 6.4,
  susutTanpaPct: 8.5,
  susutDenganPct: 4.3,
};
