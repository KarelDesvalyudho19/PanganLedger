/**
 * Data simulasi resmi PANGAN-LEDGER — dipakai konsisten di seluruh halaman.
 * Petani cabai merah, lahan 0,5 ha, produksi 4.000 kg, total biaya Rp72 jt → HPP Rp18.000/kg.
 */
export const SIMULASI = {
  komoditas: 'Cabai merah',
  luasHa: 0.5,
  produksiKg: 4000,
  totalBiaya: 72_000_000,
  hpp: 18_000,
  marginFloorPct: 11, // 18.000 × 1,11 = 19.980 → dibulatkan Rp20.000
  floor: 20_000,
  ceiling: 40_000,
  hargaPasarDefault: 28_000,
} as const;

export const RINCIAN_BIAYA = [
  { pos: 'Benih', nilai: 5_000_000 },
  { pos: 'Pupuk', nilai: 16_000_000 },
  { pos: 'Pestisida', nilai: 14_000_000 },
  { pos: 'Mulsa & ajir', nilai: 7_000_000 },
  { pos: 'Tenaga kerja (termasuk keluarga)', nilai: 24_000_000 },
  { pos: 'Sewa lahan & penyusutan', nilai: 6_000_000 },
];

export type SkenarioKey = 'anjlok' | 'normal' | 'melonjak';

export const SKENARIO: { key: SkenarioKey; label: string; harga: number; deskripsi: string }[] = [
  { key: 'anjlok', label: 'Anjlok', harga: 6_000, deskripsi: 'Panen raya serentak, harga jatuh jauh di bawah HPP' },
  { key: 'normal', label: 'Normal', harga: 28_000, deskripsi: 'Harga di dalam koridor, kontrak tidak mengubah apa pun' },
  { key: 'melonjak', label: 'Melonjak', harga: 60_000, deskripsi: 'Pasokan langka, pembeli terlindungi oleh batas atas' },
];
