export const STATISTIK = [
  {
    nilai: 3.96,
    format: 'pct' as const,
    digits: 2,
    label: 'Inflasi Provinsi Bengkulu (yoy), triwulan II 2026',
    keterangan: 'Cabai merah menjadi pendorong utama',
    sumber: 'BPS & Bank Indonesia Prov. Bengkulu',
    tone: 'amber' as const,
  },
  {
    nilai: 11.61,
    format: 'pct' as const,
    digits: 2,
    label: 'Prevalensi kekurangan konsumsi pangan (PoU) Rejang Lebong 2025',
    keterangan: 'Tertinggi di Provinsi Bengkulu, padahal sentra sayur',
    sumber: 'BPS, Statistik Ketahanan Pangan 2025',
    tone: 'brick' as const,
  },
  {
    nilai: 62.8,
    format: 'pct' as const,
    digits: 1,
    label: 'Pasokan sayur nasional yang hilang atau terbuang',
    keterangan: 'Susut terjadi dari kebun hingga meja makan',
    sumber: 'Kajian Food Loss & Waste, Bappenas',
    tone: 'forest' as const,
  },
];

export const STAT_HPP = {
  hpp: 20_000,
  hargaRendah: 2_000,
  hargaTinggi: 3_000,
  label: 'HPP cabai ±Rp20.000/kg, tetapi harga di petani pernah jatuh ke Rp2.000–3.000/kg',
  sumber: 'Pemberitaan media daerah, Rejang Lebong',
};

export const RANTAI_KONVENSIONAL = [
  { nama: 'Petani', ket: 'Price taker, tanpa HPP' },
  { nama: 'Pengumpul', ket: 'Menentukan harga beli' },
  { nama: 'Pedagang besar', ket: 'Menahan & menimbun' },
  { nama: 'Grosir kota', ket: 'Margin berlapis' },
  { nama: 'Pengecer', ket: 'Harga ikut naik' },
  { nama: 'Konsumen', ket: 'Membayar inflasi' },
];

export const RANTAI_PANGAN_LEDGER = [
  { nama: 'Kelompok tani', ket: 'HPP tercatat, jadwal tanam berbasis data' },
  { nama: 'PANGAN-LEDGER', ket: 'Kontrak koridor, alokasi & rute hijau' },
  { nama: 'Pembeli kontrak / pasar kota', ket: 'BUMD pangan, SPPG, katering, hotel, pasar' },
];

export const LANGKAH = [
  { judul: 'Catat biaya', isi: 'Petani mengetik atau mengirim pesan suara harian. Sistem menjurnal otomatis ke pos biaya.' },
  { judul: 'Lihat HPP & prakiraan', isi: 'HPP per kg berjalan muncul langsung, berdampingan dengan prakiraan harga 4–8 minggu.' },
  { judul: 'Tawarkan kontrak', isi: 'Kelompok tani menawarkan volume panen dengan floor = HPP + margin wajar dan ceiling yang disepakati.' },
  { judul: 'Pembeli setuju + uang muka', isi: 'BUMD, katering, hotel, atau dapur SPPG menyetor uang muka 10–20% ke rekening koperasi/BUMDes.' },
  { judul: 'Panen & rute hijau', isi: 'Surplus dialokasikan ke tujuan dengan nilai bersih terbaik; titik jemput digabung dalam satu rute.' },
  { judul: 'Pelunasan & laporan', isi: 'Pembayaran mengikuti rumus koridor. Laporan laba rugi musim dan data agregat dikirim ke TPID.' },
];

export const DAMPAK = [
  { indikator: 'Petani dengan HPP tercatat', target: 120, satuan: 'petani', ket: 'Target pilot satu musim tanam', icon: 'users' as const },
  { indikator: 'Volume terjual ≥ HPP', target: 90, satuan: '%', ket: 'Dari total volume kontrak', icon: 'shield' as const },
  { indikator: 'Selisih harga petani–konsumen', target: -25, satuan: '%', ket: 'Penyempitan disparitas harga', icon: 'scale' as const },
  { indikator: 'Sayur terselamatkan dari busuk', target: 180, satuan: 'ton', ket: 'Lewat alokasi surplus terarah', icon: 'leaf' as const },
  { indikator: 'Angkutan per ton', target: 26, satuan: 'km/ton', ket: 'Turun dari ±46 km/ton lewat rute hijau', icon: 'route' as const },
];

export const PETA_JALAN = [
  { fase: 'Bulan 1–3', judul: 'Persiapan & purwarupa', isi: ['Survei biaya 3 kelompok tani', 'Purwarupa PWA dan parser biaya', 'Kurasi data PIHPS & BMKG'] },
  { fase: 'Bulan 4–9', judul: 'Pilot satu musim tanam', isi: ['120 petani cabai di Rejang Lebong', 'Kontrak koridor pertama dengan pembeli', 'Evaluasi akurasi prakiraan'] },
  { fase: 'Bulan 10–15', judul: 'Integrasi kelembagaan', isi: ['BUMD pangan & koperasi/BUMDes', 'Dasbor peringatan dini untuk TPID', 'Rekening uang muka terpisah'] },
  { fase: 'Bulan 16–24', judul: 'Perluasan', isi: ['Kepahiang sebagai wilayah kedua', 'Komoditas bawang merah & tomat', 'Skema pembiayaan musim tanam'] },
];

export const MITRA = [
  { peran: 'Akademisi', contoh: 'Perguruan tinggi: model prakiraan, pendampingan akuntansi tani', icon: 'academic' as const },
  { peran: 'Pemerintah', contoh: 'TPID, Dinas TPHP, Bank Indonesia: data & kebijakan stabilisasi', icon: 'gov' as const },
  { peran: 'Bisnis', contoh: 'BUMD pangan, katering, hotel, dapur SPPG: pembeli kontrak', icon: 'business' as const },
  { peran: 'Komunitas', contoh: 'Kelompok tani, koperasi, BUMDes: pengelola uang muka & logistik', icon: 'community' as const },
  { peran: 'Media', contoh: 'Media daerah: literasi harga dan transparansi pasar', icon: 'media' as const },
];
