import { KONTRAK } from './kontrak';

/** Harga bulanan cabai merah: tingkat petani (Rejang Lebong) vs konsumen (Kota Bengkulu). Simulasi. */
export const HARGA_PETANI_KONSUMEN = [
  { bulan: 'Nov 25', petani: 24000, konsumen: 41000 },
  { bulan: 'Des 25', petani: 31000, konsumen: 52000 },
  { bulan: 'Jan 26', petani: 36000, konsumen: 58000 },
  { bulan: 'Feb 26', petani: 29000, konsumen: 50000 },
  { bulan: 'Mar 26', petani: 17000, konsumen: 38000 },
  { bulan: 'Apr 26', petani: 12000, konsumen: 33000 },
  { bulan: 'Mei 26', petani: 21000, konsumen: 44000 },
  { bulan: 'Jun 26', petani: 34000, konsumen: 61000 },
  { bulan: 'Jul 26', petani: 38000, konsumen: 64000 },
  { bulan: 'Agu 26', petani: 26000, konsumen: 49000 },
  { bulan: 'Sep 26', petani: 14000, konsumen: 36000 },
  { bulan: 'Okt 26', petani: 19500, konsumen: 39500 },
].map((d) => ({ ...d, selisih: d.konsumen - d.petani }));

export const HARGA_STRATEGIS = [
  { komoditas: 'Cabai merah', harga: 39500, perubahan: 4.2, satuan: 'kg' },
  { komoditas: 'Cabai rawit', harga: 47000, perubahan: -2.1, satuan: 'kg' },
  { komoditas: 'Bawang merah', harga: 36500, perubahan: 1.4, satuan: 'kg' },
  { komoditas: 'Tomat', harga: 11000, perubahan: -6.8, satuan: 'kg' },
  { komoditas: 'Kubis', harga: 7500, perubahan: -3.5, satuan: 'kg' },
];

export const NERACA_MINGGU_DEPAN = [
  { komoditas: 'Cabai merah', pasokan: 412, kebutuhan: 388 },
  { komoditas: 'Cabai rawit', pasokan: 96, kebutuhan: 104 },
  { komoditas: 'Tomat', pasokan: 530, kebutuhan: 455 },
  { komoditas: 'Kubis', pasokan: 760, kebutuhan: 702 },
  { komoditas: 'Bawang merah', pasokan: 118, kebutuhan: 141 },
].map((d) => ({ ...d, selisihPct: ((d.pasokan - d.kebutuhan) / d.kebutuhan) * 100 }));

export const VOLUME_TERLINDUNGI_KG = KONTRAK.reduce((s, k) => s + k.volumeKg, 0);

export type Level = 'tinggi' | 'sedang' | 'rendah';

export const PERINGATAN = [
  { level: 'tinggi' as Level, jenis: 'Kelebihan pasokan', komoditas: 'Cabai merah', wilayah: 'Selupu Rejang', waktu: 'Minggu ke-5 (30 Nov 26)', isi: 'Surplus 18% di atas kebutuhan. Risiko harga petani turun di bawah HPP Rp18.000/kg.', saran: 'Dorong kontrak koridor tambahan dengan BUMD pangan dan dapur SPPG.' },
  { level: 'tinggi' as Level, jenis: 'Kekurangan pasokan', komoditas: 'Bawang merah', wilayah: 'Kota Bengkulu', waktu: 'Minggu depan', isi: 'Pasokan 16% di bawah kebutuhan; bawang merah masih banyak didatangkan dari luar provinsi.', saran: 'Koordinasi pasokan antardaerah dan pantau harga eceran harian.' },
  { level: 'sedang' as Level, jenis: 'Kelebihan pasokan', komoditas: 'Tomat', wilayah: 'Curup', waktu: 'Minggu ke-2–3', isi: 'Surplus 16%. Pola serupa pernah membuat tomat busuk dibuang di jalan.', saran: 'Alokasikan ke pengolah saus/pasta dan dapur SPPG.' },
  { level: 'sedang' as Level, jenis: 'Cuaca', komoditas: 'Cabai merah & rawit', wilayah: 'Bermani Ulu', waktu: 'Minggu ke-1–2', isi: 'Curah hujan tinggi meningkatkan risiko antraknosa dan gagal panen sebagian.', saran: 'Sosialisasi pengendalian hama terpadu melalui penyuluh.' },
  { level: 'rendah' as Level, jenis: 'Disparitas harga', komoditas: 'Cabai merah', wilayah: 'Rejang Lebong → Kota Bengkulu', waktu: 'Okt 2026', isi: 'Selisih harga petani–konsumen Rp20.000/kg (102% dari harga petani).', saran: 'Perluas penjualan langsung lewat pembeli kontrak.' },
];
