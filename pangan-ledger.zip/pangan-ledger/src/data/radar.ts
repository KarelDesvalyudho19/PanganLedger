/**
 * Data dummy Radar Tanam & Harga — dibangkitkan secara deterministik (seeded),
 * meniru pola musiman harga PIHPS dan prakiraan pasokan per kecamatan.
 */

export type KomoditasKey = 'cabaiMerah' | 'cabaiRawit' | 'tomat' | 'kubis' | 'bawangMerah';

export const KOMODITAS: { key: KomoditasKey; label: string; base: number; amp: number; vol: number; hpp: number }[] = [
  { key: 'cabaiMerah', label: 'Cabai merah', base: 31_000, amp: 0.32, vol: 0.07, hpp: 18_000 },
  { key: 'cabaiRawit', label: 'Cabai rawit', base: 38_000, amp: 0.36, vol: 0.08, hpp: 22_000 },
  { key: 'tomat', label: 'Tomat', base: 7_200, amp: 0.38, vol: 0.09, hpp: 4_000 },
  { key: 'kubis', label: 'Kubis', base: 4_600, amp: 0.3, vol: 0.08, hpp: 2_500 },
  { key: 'bawangMerah', label: 'Bawang merah', base: 30_000, amp: 0.22, vol: 0.05, hpp: 19_500 },
];

export const KECAMATAN = ['Curup', 'Selupu Rejang', 'Sindang Kelingi', 'Bermani Ulu', 'Kota Padang'] as const;
export type Kecamatan = (typeof KECAMATAN)[number];

const KEC_FAKTOR: Record<Kecamatan, number> = {
  Curup: 1.04,
  'Selupu Rejang': 0.97,
  'Sindang Kelingi': 0.96,
  'Bermani Ulu': 0.95,
  'Kota Padang': 0.98,
};

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}

const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
export const HARI_INI = new Date(2026, 9, 26); // Senin, 26 Oktober 2026

function tanggalLabel(d: Date) {
  return `${d.getDate()} ${BULAN[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`;
}

/* ---------------- Heatmap surplus/defisit ---------------- */

export const MINGGU_PRAKIRAAN = 8;

/** Nilai % surplus (+) / defisit (–) terhadap kebutuhan, per kecamatan per minggu ke depan. */
export function heatmapSurplus(kom: KomoditasKey): number[][] {
  const rnd = mulberry32(hash(`heat-${kom}`));
  const rows = KECAMATAN.map((kec, ki) => {
    const row: number[] = [];
    // gelombang panen bergeser antar kecamatan
    const fase = (ki * 1.3 + hash(kom) % 5) % 8;
    for (let w = 0; w < MINGGU_PRAKIRAAN; w++) {
      const wave = Math.sin(((w - fase) / 8) * Math.PI * 2) * 13;
      const noise = (rnd() - 0.5) * 9;
      row.push(Math.round(wave + noise + (kec === 'Curup' ? -4 : 0)));
    }
    return row;
  });
  // Skenario resmi untuk demo: cabai merah surplus 18% minggu ke-5 di Selupu Rejang
  if (kom === 'cabaiMerah') {
    rows[1][3] = 11;
    rows[1][4] = 18;
    rows[1][5] = 9;
    rows[0][4] = 7;
    rows[3][4] = 12;
    rows[2][6] = -14;
    rows[4][1] = -11;
  }
  return rows;
}

export function labelMinggu(w: number) {
  const d = new Date(HARI_INI);
  d.setDate(d.getDate() + (w + 1) * 7);
  return { pendek: `M${w + 1}`, panjang: `Minggu ke-${w + 1}`, tanggal: tanggalLabel(d) };
}

/* ---------------- Seri harga historis + prakiraan ---------------- */

export interface HargaPoint {
  tanggal: string;
  bulan: string;
  aktual?: number;
  prakiraan?: number;
  pita?: [number, number];
  hpp: number;
}

export function seriHarga(kom: KomoditasKey, kec: Kecamatan): HargaPoint[] {
  const k = KOMODITAS.find((x) => x.key === kom)!;
  const rnd = mulberry32(hash(`harga-${kom}-${kec}`));
  const faktor = KEC_FAKTOR[kec];
  const pts: HargaPoint[] = [];
  const minggu = 52;
  let last = 0;
  let drift = 0;
  for (let i = minggu - 1; i >= 0; i--) {
    const d = new Date(HARI_INI);
    d.setDate(d.getDate() - i * 7);
    const t = d.getMonth() + d.getDate() / 31; // posisi tahun (0–12)
    // pola musiman: puncak Jan–Feb & Jun–Jul, lembah Sep–Okt (panen raya)
    const musim = 0.55 * Math.cos(((t - 1.2) / 12) * Math.PI * 2) + 0.45 * Math.cos(((t - 6.3) / 6) * Math.PI * 2);
    drift = drift * 0.7 + (rnd() - 0.5) * k.vol * 2;
    const harga = k.base * faktor * (1 + k.amp * musim + drift);
    last = Math.round(harga / 50) * 50;
    pts.push({ tanggal: tanggalLabel(d), bulan: `${BULAN[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`, aktual: last, hpp: k.hpp });
  }
  // sambungkan garis prakiraan ke titik terakhir
  pts[pts.length - 1].prakiraan = last;
  pts[pts.length - 1].pita = [last, last];

  const heat = heatmapSurplus(kom)[KECAMATAN.indexOf(kec)];
  let p = last;
  for (let w = 0; w < MINGGU_PRAKIRAAN; w++) {
    const d = new Date(HARI_INI);
    d.setDate(d.getDate() + (w + 1) * 7);
    const elastis = -0.55 * (heat[w] / 100); // surplus menekan harga
    const tren = 0.012; // menuju musim hujan & akhir tahun
    const target = last * (1 + tren * (w + 1)) * (1 + elastis);
    p = 0.35 * p + 0.65 * target;
    const lebar = 0.05 + 0.018 * w;
    const v = Math.round(p / 50) * 50;
    pts.push({
      tanggal: tanggalLabel(d),
      bulan: `${BULAN[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`,
      prakiraan: v,
      pita: [Math.round((v * (1 - lebar)) / 50) * 50, Math.round((v * (1 + lebar)) / 50) * 50],
      hpp: k.hpp,
    });
  }
  return pts;
}

/* ---------------- Rekomendasi ---------------- */

export interface Rekomendasi {
  jenis: 'surplus' | 'defisit' | 'cuaca';
  judul: string;
  isi: string;
  aksi: string;
  keyakinan: number; // %
}

export function rekomendasi(kom: KomoditasKey, kec: Kecamatan): Rekomendasi[] {
  const k = KOMODITAS.find((x) => x.key === kom)!;
  const grid = heatmapSurplus(kom);
  let maxV = -Infinity;
  let maxK = 0;
  let maxW = 0;
  let minV = Infinity;
  let minK = 0;
  let minW = 0;
  grid.forEach((row, ki) =>
    row.forEach((v, w) => {
      if (v > maxV) [maxV, maxK, maxW] = [v, ki, w];
      if (v < minV) [minV, minK, minW] = [v, ki, w];
    }),
  );
  const kecRow = grid[KECAMATAN.indexOf(kec)];
  const kecMax = Math.max(...kecRow);
  const kecMaxW = kecRow.indexOf(kecMax);
  const nama = k.label.toLowerCase();

  const out: Rekomendasi[] = [
    {
      jenis: 'surplus',
      judul: `Surplus ${maxV}% di ${KECAMATAN[maxK]}`,
      isi: `Pasokan ${nama} diprakirakan surplus ${maxV}% pada minggu ke-${maxW + 1} (${labelMinggu(maxW).tanggal}) di ${KECAMATAN[maxK]}. Pertimbangkan menggeser tanam 2 minggu atau mengalokasikan ke pembeli kontrak.`,
      aksi: 'Tawarkan kontrak koridor',
      keyakinan: 78,
    },
    {
      jenis: 'defisit',
      judul: `Celah pasokan di ${KECAMATAN[minK]}`,
      isi: `Kebutuhan ${nama} di ${KECAMATAN[minK]} diprakirakan melebihi pasokan ${Math.abs(minV)}% pada minggu ke-${minW + 1}. Surplus dari kecamatan tetangga dapat dialihkan lewat rute hijau sebelum dikirim ke Kota Bengkulu.`,
      aksi: 'Lihat alokasi pasokan',
      keyakinan: 71,
    },
  ];
  if (kecMax >= 8) {
    out.push({
      jenis: 'cuaca',
      judul: `Jadwal tanam ${kec}`,
      isi: `Curah hujan tinggi diprakirakan BMKG pada dua minggu pertama. Untuk ${kec}, puncak panen jatuh di minggu ke-${kecMaxW + 1}; menunda semai 10–14 hari menurunkan risiko panen serentak dan serangan antraknosa.`,
      aksi: 'Simpan pengingat tanam',
      keyakinan: 64,
    });
  } else {
    out.push({
      jenis: 'cuaca',
      judul: `${kec} relatif seimbang`,
      isi: `Neraca ${nama} di ${kec} berada dalam rentang ±8% selama 8 minggu. Jadwal tanam saat ini aman; pantau prakiraan hujan BMKG untuk perawatan tanaman.`,
      aksi: 'Pantau mingguan',
      keyakinan: 69,
    });
  }
  return out;
}
