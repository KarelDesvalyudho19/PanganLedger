import { useEffect } from 'react';
import { useLocation, useOutlet } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { DemoTabs } from './DemoTabs';

const DEMO_PATHS = ['/buku-biaya', '/radar', '/simulasi', '/dasbor', '/tpid'];

export function Layout() {
  const location = useLocation();
  const outlet = useOutlet();
  const isDemo = DEMO_PATHS.includes(location.pathname);

  useEffect(() => {
    const state = location.state as { scrollTo?: string } | null;
    if (state?.scrollTo) return; // ditangani halaman beranda
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [location.pathname, location.state]);

  return (
    <div className="flex min-h-screen flex-col">
      <a href="#konten" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-forest focus:px-4 focus:py-2 focus:text-white">
        Lewati ke konten
      </a>
      <Navbar />
      {isDemo && <DemoTabs />}
      {/* Fade-in setiap pergantian halaman (key memaksa remount) */}
      <motion.main
        id="konten"
        key={location.pathname}
        className="flex-1"
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: 'easeOut' }}
      >
        {outlet}
      </motion.main>
      <Footer />
    </div>
  );
}
