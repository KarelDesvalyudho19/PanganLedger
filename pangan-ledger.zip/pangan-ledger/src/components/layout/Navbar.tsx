import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, Menu, X } from 'lucide-react';
import { LedgerLeafMark } from '../ui/Illustrations';
import { btn } from '../ui/Button';

type Item = { label: string; to?: string; anchor?: string };

const ITEMS: Item[] = [
  { label: 'Masalah', anchor: 'masalah' },
  { label: 'Solusi', anchor: 'solusi' },
  { label: 'Simulasi', to: '/simulasi' },
  { label: 'Dasbor', to: '/dasbor' },
  { label: 'Tentang', to: '/tentang' },
];

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <LedgerLeafMark className="h-9 w-9 shrink-0" />
      <span className="leading-none">
        <span className={`block whitespace-nowrap font-sans text-[15px] font-extrabold tracking-[0.06em] ${light ? 'text-white' : 'text-forest-ink'}`}>PANGAN-LEDGER</span>
        <span className={`mt-1 block whitespace-nowrap text-[10.5px] font-medium tracking-wide ${light ? 'text-white/70' : 'text-ink-mute'}`}>AI × akuntansi biaya tani</span>
      </span>
    </span>
  );
}

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setOpen(false), [location.pathname]);

  const goAnchor = (id: string) => {
    setOpen(false);
    if (location.pathname === '/') {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      navigate('/', { state: { scrollTo: id } });
    }
  };

  const linkCls = (active: boolean) =>
    `relative rounded-full px-3.5 py-2 text-sm font-semibold transition-colors ${active ? 'text-forest' : 'text-ink-soft hover:text-forest'}`;

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${scrolled || open ? 'border-b border-line bg-cream/90 backdrop-blur-md' : 'border-b border-transparent bg-cream/0'}`}
    >
      <nav className="container-page flex h-16 items-center justify-between gap-4" aria-label="Navigasi utama">
        <Link to="/" aria-label="PANGAN-LEDGER, ke beranda" className="rounded-lg">
          <Logo />
        </Link>

        <ul className="hidden items-center gap-1 lg:flex">
          {ITEMS.map((it) => (
            <li key={it.label}>
              {it.to ? (
                <NavLink to={it.to} className={({ isActive }) => linkCls(isActive)}>
                  {it.label}
                </NavLink>
              ) : (
                <button type="button" onClick={() => goAnchor(it.anchor!)} className={linkCls(false)}>
                  {it.label}
                </button>
              )}
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <span className="hidden sm:block">
            <Link to="/buku-biaya" className={btn('primary')}>
              Coba Demo <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </span>
          <button
            type="button"
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-line bg-white text-ink lg:hidden"
            aria-label={open ? 'Tutup menu' : 'Buka menu'}
            aria-expanded={open}
            aria-controls="menu-seluler"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            id="menu-seluler"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="border-t border-line bg-cream lg:hidden"
          >
            <ul className="container-page grid gap-1 py-4">
              {ITEMS.map((it) => (
                <li key={it.label}>
                  {it.to ? (
                    <NavLink to={it.to} className={({ isActive }) => `block rounded-xl px-3 py-3 text-base font-semibold ${isActive ? 'bg-mint-soft text-forest' : 'text-ink'}`}>
                      {it.label}
                    </NavLink>
                  ) : (
                    <button type="button" onClick={() => goAnchor(it.anchor!)} className="block w-full rounded-xl px-3 py-3 text-left text-base font-semibold text-ink">
                      {it.label}
                    </button>
                  )}
                </li>
              ))}
              <li className="mt-1 border-t border-line pt-3">
                <p className="px-3 pb-2 text-xs font-bold uppercase tracking-wider text-ink-mute">Modul demo</p>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    ['Buku Biaya', '/buku-biaya'],
                    ['Radar Harga', '/radar'],
                    ['Simulator Kontrak', '/simulasi'],
                    ['Dasbor TPID', '/tpid'],
                  ].map(([l, to]) => (
                    <Link key={to} to={to} className="rounded-xl border border-line bg-white px-3 py-2.5 text-sm font-semibold text-forest">
                      {l}
                    </Link>
                  ))}
                </div>
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
