import { Link } from 'react-router-dom';
import { FlaskConical } from 'lucide-react';
import { Logo } from './Navbar';
import { HillLines } from '../ui/Illustrations';

export function Footer() {
  return (
    <footer className="relative mt-24 overflow-hidden bg-forest-ink text-white/80">
      <HillLines className="pointer-events-none absolute -top-2 right-0 h-36 w-[640px] max-w-none text-white/10" />
      <div className="container-page relative grid gap-10 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo light />
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-white/70">
            Kecerdasan buatan dan akuntansi biaya untuk melindungi petani hortikultura serta menstabilkan harga pangan di Provinsi Bengkulu. Wilayah pilot: sentra sayur Rejang Lebong dan Kepahiang.
          </p>
          <p className="mt-6 inline-flex items-center gap-2 rounded-full border border-amber/40 bg-amber/10 px-3 py-1.5 text-xs font-semibold text-[#F0C58E]">
            <FlaskConical className="h-3.5 w-3.5" aria-hidden="true" />
            Purwarupa. Data bersifat simulasi.
          </p>
        </div>
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-white/50">Modul</p>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li><Link className="hover:text-white" to="/buku-biaya">Buku Biaya Tani</Link></li>
            <li><Link className="hover:text-white" to="/radar">Radar Tanam & Harga</Link></li>
            <li><Link className="hover:text-white" to="/simulasi">Simulator Kontrak Koridor</Link></li>
            <li><Link className="hover:text-white" to="/dasbor">Kontrak & Alokasi Pasokan</Link></li>
            <li><Link className="hover:text-white" to="/tpid">Dasbor Pemerintah/TPID</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-white/50">Gagasan</p>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li><Link className="hover:text-white" to="/tentang">Landasan teori</Link></li>
            <li><Link className="hover:text-white" to="/tentang">Perbandingan solusi</Link></li>
            <li><Link className="hover:text-white" to="/tentang">Risiko & mitigasi</Link></li>
            <li><Link className="hover:text-white" to="/tentang">Tim Universitas Bengkulu</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container-page flex flex-col gap-2 py-5 text-xs text-white/50 sm:flex-row sm:items-center sm:justify-between">
          <p>© 2026 PANGAN-LEDGER · Universitas Bengkulu</p>
          <p>Sumber data acuan: PIHPS, BMKG, BPS. Angka di purwarupa ini disimulasikan.</p>
        </div>
      </div>
    </footer>
  );
}
