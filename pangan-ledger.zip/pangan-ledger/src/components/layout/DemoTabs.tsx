import { NavLink } from 'react-router-dom';
import { BookOpen, Calculator, Landmark, Radar, Route } from 'lucide-react';

const TABS = [
  { to: '/buku-biaya', label: 'Buku Biaya Tani', icon: BookOpen },
  { to: '/radar', label: 'Radar Tanam & Harga', icon: Radar },
  { to: '/simulasi', label: 'Simulator Kontrak', icon: Calculator },
  { to: '/dasbor', label: 'Kontrak & Alokasi', icon: Route },
  { to: '/tpid', label: 'Dasbor TPID', icon: Landmark },
];

/** Strip navigasi antar-modul demo, tampil di halaman aplikasi. */
export function DemoTabs() {
  return (
    <div className="border-b border-line bg-white/70">
      <nav className="container-page scrollbar-thin flex gap-1 overflow-x-auto py-2" aria-label="Modul demo">
        {TABS.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex shrink-0 items-center gap-2 rounded-full px-3.5 py-2 text-[13px] font-semibold transition-colors ${
                isActive ? 'bg-forest text-white' : 'text-ink-soft hover:bg-mint-soft hover:text-forest'
              }`
            }
          >
            <Icon className="h-4 w-4" aria-hidden="true" />
            {label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
