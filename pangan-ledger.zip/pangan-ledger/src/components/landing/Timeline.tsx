import { LANGKAH } from '../../data/landing';
import { Reveal } from '../ui/Reveal';

export function Timeline() {
  return (
    <ol className="relative grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {LANGKAH.map((l, i) => (
        <li key={l.judul}>
          <Reveal delay={i * 0.06} className="h-full">
            <div className="card relative h-full p-6">
              <div className="flex items-center gap-3">
                <span className="num flex h-10 w-10 items-center justify-center rounded-full border-2 border-forest bg-white font-serif text-lg font-semibold text-forest">{i + 1}</span>
                <span className="h-px flex-1 bg-gradient-to-r from-forest/40 to-transparent" aria-hidden="true" />
              </div>
              <h3 className="mt-4 font-sans text-[17px] font-bold tracking-normal text-ink">{l.judul}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-soft">{l.isi}</p>
            </div>
          </Reveal>
        </li>
      ))}
    </ol>
  );
}
