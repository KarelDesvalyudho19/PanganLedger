import { Link } from 'react-router-dom';
import { ArrowUpRight, type LucideIcon } from 'lucide-react';

interface Props {
  nomor: string;
  icon: LucideIcon;
  judul: string;
  tagline: string;
  isi: string;
  poin: string[];
  to: string;
  cta: string;
  accent?: 'forest' | 'amber';
}

export function ModuleCard({ nomor, icon: Icon, judul, tagline, isi, poin, to, cta, accent = 'forest' }: Props) {
  return (
    <article className="card group flex h-full flex-col p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-lift)] sm:p-7">
      <div className="flex items-center justify-between">
        <span className={`flex h-12 w-12 items-center justify-center rounded-2xl ${accent === 'amber' ? 'bg-amber-soft text-amber-ink' : 'bg-mint text-forest'}`}>
          <Icon className="h-6 w-6" aria-hidden="true" />
        </span>
        <span className="num font-serif text-3xl text-line">{nomor}</span>
      </div>
      <p className="mt-6 text-xs font-bold uppercase tracking-[0.12em] text-ink-mute">{tagline}</p>
      <h3 className="mt-1.5 text-2xl text-ink">{judul}</h3>
      <p className="mt-3 text-[15px] leading-relaxed text-ink-soft">{isi}</p>
      <ul className="mt-5 space-y-2.5 border-t border-line pt-5">
        {poin.map((p) => (
          <li key={p} className="flex gap-2.5 text-sm text-ink-soft">
            <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-forest" aria-hidden="true" />
            {p}
          </li>
        ))}
      </ul>
      <Link to={to} className="mt-auto inline-flex items-center gap-1.5 pt-6 text-sm font-bold text-forest">
        {cta}
        <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
      </Link>
    </article>
  );
}
