import { ArrowDown, ArrowRight } from 'lucide-react';
import { RANTAI_KONVENSIONAL, RANTAI_PANGAN_LEDGER } from '../../data/landing';
import { Reveal } from '../ui/Reveal';
import { LedgerLeafMark } from '../ui/Illustrations';

function Arrow({ tone }: { tone: 'mute' | 'forest' }) {
  const cls = tone === 'forest' ? 'text-forest' : 'text-ink-mute/60';
  return (
    <span className="flex items-center justify-center" aria-hidden="true">
      <ArrowRight className={`hidden h-4 w-4 lg:block ${cls}`} />
      <ArrowDown className={`h-4 w-4 lg:hidden ${cls}`} />
    </span>
  );
}

export function SupplyChainDiagram() {
  return (
    <div className="grid gap-6">
      <Reveal>
        <div className="card p-5 sm:p-7">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-sm font-bold text-ink">Rantai pasok saat ini</p>
            <span className="rounded-full bg-brick-soft px-2.5 py-1 text-[11px] font-bold text-brick">5 titik perpindahan · margin berlapis</span>
          </div>
          <ol className="mt-5 grid grid-cols-1 items-stretch gap-2 lg:grid-cols-[1fr_auto_1fr_auto_1fr_auto_1fr_auto_1fr_auto_1fr] lg:gap-1.5">
            {RANTAI_KONVENSIONAL.map((n, i) => (
              <li key={n.nama} className="contents">
                <div className={`rounded-xl border px-3 py-3 text-center lg:min-w-0 ${i === 0 ? 'border-brick/30 bg-brick-soft/50' : 'border-line bg-cream'}`}>
                  <p className="text-sm font-bold text-ink">{n.nama}</p>
                  <p className="mt-0.5 text-[11.5px] leading-snug text-ink-mute">{n.ket}</p>
                </div>
                {i < RANTAI_KONVENSIONAL.length - 1 && <Arrow tone="mute" />}
              </li>
            ))}
          </ol>
          <p className="mt-4 text-[13px] text-ink-mute">Petani hanya menerima harga sisa setelah lima lapis margin; saat panen raya, harga di kebun jatuh di bawah biaya produksi.</p>
        </div>
      </Reveal>

      <Reveal delay={0.1}>
        <div className="card relative overflow-hidden border-forest/25 p-5 sm:p-7">
          <span className="absolute inset-y-0 left-0 w-1 bg-forest" aria-hidden="true" />
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-sm font-bold text-ink">Dengan PANGAN-LEDGER</p>
            <span className="rounded-full bg-mint px-2.5 py-1 text-[11px] font-bold text-forest">2 titik · risiko harga dibagi</span>
          </div>
          <ol className="mt-5 grid grid-cols-1 items-stretch gap-2 lg:grid-cols-[1fr_auto_1.15fr_auto_1fr] lg:gap-3">
            {RANTAI_PANGAN_LEDGER.map((n, i) => (
              <li key={n.nama} className="contents">
                <div className={`flex items-center gap-3 rounded-xl border px-4 py-4 ${i === 1 ? 'border-forest bg-forest text-white' : 'border-forest/20 bg-mint-soft'}`}>
                  {i === 1 && <LedgerLeafMark className="h-9 w-9 shrink-0" />}
                  <div>
                    <p className={`text-sm font-bold ${i === 1 ? 'text-white' : 'text-ink'}`}>{n.nama}</p>
                    <p className={`mt-0.5 text-[12px] leading-snug ${i === 1 ? 'text-white/80' : 'text-ink-mute'}`}>{n.ket}</p>
                  </div>
                </div>
                {i < RANTAI_PANGAN_LEDGER.length - 1 && <Arrow tone="forest" />}
              </li>
            ))}
          </ol>
        </div>
      </Reveal>
    </div>
  );
}
