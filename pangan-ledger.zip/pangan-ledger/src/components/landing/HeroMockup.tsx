import { motion } from 'framer-motion';
import { ShieldCheck, TrendingDown } from 'lucide-react';
import { RINCIAN_BIAYA, SIMULASI } from '../../data/simulasi';
import { rp, rpJt } from '../../lib/format';

/** Grafik koridor mini (SVG statis): harga pasar bergejolak vs harga diterima petani yang terjepit floor–ceiling. */
function MiniCorridor() {
  const W = 300;
  const H = 130;
  const harga = [27, 33, 41, 49, 44, 31, 19, 9, 6, 12, 22, 29, 36, 47, 58, 52, 38, 28];
  const floor = 20;
  const ceiling = 40;
  const max = 64;
  const x = (i: number) => 8 + (i / (harga.length - 1)) * (W - 16);
  const y = (v: number) => H - 10 - (v / max) * (H - 22);
  const pasar = harga.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(' ');
  const terima = harga.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(Math.min(Math.max(v, floor), ceiling)).toFixed(1)}`).join(' ');
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" aria-hidden="true">
      <rect x="8" y={y(ceiling)} width={W - 16} height={y(floor) - y(ceiling)} rx="6" fill="#DCEBE3" opacity="0.65" />
      <line x1="8" x2={W - 8} y1={y(ceiling)} y2={y(ceiling)} stroke="#C9822B" strokeDasharray="4 4" strokeWidth="1.2" />
      <line x1="8" x2={W - 8} y1={y(floor)} y2={y(floor)} stroke="#1F5F4A" strokeDasharray="4 4" strokeWidth="1.2" />
      <path d={pasar} fill="none" stroke="#8A959C" strokeWidth="1.6" strokeDasharray="5 4" />
      <path d={terima} fill="none" stroke="#1F5F4A" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />
      <text x={W - 10} y={y(ceiling) - 5} textAnchor="end" fontSize="9.5" fontWeight="700" fill="#8E5512">ceiling Rp40 rb</text>
      <text x={W - 10} y={y(floor) + 13} textAnchor="end" fontSize="9.5" fontWeight="700" fill="#1F5F4A">floor Rp20 rb</text>
    </svg>
  );
}

export function HeroMockup() {
  const maxBiaya = Math.max(...RINCIAN_BIAYA.map((r) => r.nilai));
  return (
    <div className="relative mx-auto w-full max-w-[520px] lg:mx-0">
      {/* Kartu HPP */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 w-full sm:w-[88%]"
      >
        <div className="card animate-float p-5 sm:p-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-semibold text-ink-mute">HPP berjalan · Cabai merah 0,5 ha</p>
            <p className="num mt-1 font-serif text-[2.1rem] leading-none text-ink">
              {rp(SIMULASI.hpp)}
              <span className="ml-1 font-sans text-sm font-semibold text-ink-mute">/kg</span>
            </p>
          </div>
          <span className="rounded-full bg-mint px-2.5 py-1 text-[11px] font-bold text-forest">Buku Biaya</span>
        </div>
        <ul className="mt-5 space-y-2">
          {RINCIAN_BIAYA.map((r) => (
            <li key={r.pos} className="grid grid-cols-[1fr_auto] items-center gap-x-3 gap-y-1 text-[12px]">
              <span className="truncate text-ink-soft">{r.pos}</span>
              <span className="num font-semibold text-ink">{rpJt(r.nilai)}</span>
              <span className="col-span-2 h-1.5 overflow-hidden rounded-full bg-sand">
                <span className="block h-full rounded-full bg-forest/80" style={{ width: `${(r.nilai / maxBiaya) * 100}%` }} />
              </span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex items-center justify-between border-t border-line pt-3 text-[12px]">
          <span className="text-ink-mute">Total {rpJt(SIMULASI.totalBiaya)} ÷ 4.000 kg</span>
          <span className="font-semibold text-forest">Termasuk TK keluarga</span>
        </div>
        </div>
      </motion.div>

      {/* Kartu koridor */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-20 ml-auto mt-4 w-full sm:-mt-16 sm:w-[78%]"
      >
        <div className="card animate-float-slow p-4 sm:p-5">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-xs font-bold text-ink">Kontrak koridor</p>
          <span className="text-[10.5px] font-semibold text-ink-mute">harga diterima vs pasar</span>
        </div>
        <MiniCorridor />
        </div>
      </motion.div>

      {/* Chip peringatan */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.7 }}
        className="absolute -left-2 bottom-6 z-30 hidden items-center gap-2 rounded-2xl border border-line bg-white px-3 py-2 shadow-[var(--shadow-lift)] sm:flex"
      >
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-soft text-amber-ink">
          <TrendingDown className="h-4 w-4" aria-hidden="true" />
        </span>
        <span className="text-[11.5px] leading-tight">
          <span className="block font-bold text-ink">Surplus 18% · Mg ke-5</span>
          <span className="text-ink-mute">Selupu Rejang</span>
        </span>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.9 }}
        className="absolute -top-3 right-2 z-30 hidden items-center gap-2 sm:flex rounded-2xl border border-line bg-white px-3 py-2 shadow-[var(--shadow-lift)]"
      >
        <ShieldCheck className="h-4 w-4 text-forest" aria-hidden="true" />
        <span className="text-[11.5px] font-bold text-ink">Floor = HPP + margin wajar</span>
      </motion.div>
    </div>
  );
}
