import { KECAMATAN, MINGGU_PRAKIRAAN, labelMinggu } from '../../data/radar';

interface Props {
  grid: number[][];
  selectedKec?: string;
  onSelectKec?: (k: (typeof KECAMATAN)[number]) => void;
}

/** Warna divergen: defisit = merah bata, seimbang = hijau lembut, surplus = amber. */
export function cellColor(v: number) {
  const t = Math.min(Math.abs(v) / 22, 1);
  if (Math.abs(v) <= 4) return { bg: '#EEF5F1', fg: '#1F5F4A' };
  if (v > 0) {
    const a = 0.18 + t * 0.72;
    return { bg: `rgba(201,130,43,${a.toFixed(2)})`, fg: a > 0.55 ? '#fff' : '#6B3F0C' };
  }
  const a = 0.16 + t * 0.7;
  return { bg: `rgba(181,71,58,${a.toFixed(2)})`, fg: a > 0.55 ? '#fff' : '#7A2A20' };
}

export function Heatmap({ grid, selectedKec, onSelectKec }: Props) {
  const weeks = Array.from({ length: MINGGU_PRAKIRAAN }, (_, w) => labelMinggu(w));
  return (
    <div>
      <div className="scrollbar-thin relative overflow-x-auto">
        <table className="w-full min-w-[560px] border-separate border-spacing-1 text-[12px]">
          <caption className="sr-only">Prakiraan surplus (+) dan defisit (–) pasokan dalam persen per kecamatan per minggu</caption>
          <thead>
            <tr>
              <th scope="col" className="w-36 px-2 pb-1 text-left text-[11px] font-bold uppercase tracking-wider text-ink-mute">Kecamatan</th>
              {weeks.map((w) => (
                <th key={w.pendek} scope="col" className="px-1 pb-1 text-center font-semibold text-ink-mute">
                  <span className="block text-ink">{w.pendek}</span>
                  <span className="block text-[10px] font-medium">{w.tanggal.replace(/ \d+$/, '')}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {KECAMATAN.map((kec, ki) => {
              const active = kec === selectedKec;
              return (
                <tr key={kec}>
                  <th scope="row" className="px-0 text-left">
                    <button
                      type="button"
                      onClick={() => onSelectKec?.(kec)}
                      aria-pressed={active}
                      className={`w-full rounded-lg px-2 py-2 text-left text-[12.5px] font-semibold transition-colors ${active ? 'bg-forest text-white' : 'text-ink hover:bg-mint-soft'}`}
                    >
                      {kec}
                    </button>
                  </th>
                  {grid[ki].map((v, w) => {
                    const c = cellColor(v);
                    return (
                      <td
                        key={w}
                        className={`num h-10 rounded-lg text-center font-bold transition-transform hover:scale-[1.06] ${active ? 'ring-2 ring-forest/40' : ''}`}
                        style={{ background: c.bg, color: c.fg }}
                        title={`${kec}, ${weeks[w].panjang}: ${v > 0 ? 'surplus' : v < 0 ? 'defisit' : 'seimbang'} ${Math.abs(v)}%`}
                      >
                        {v > 0 ? `+${v}` : v < 0 ? `–${Math.abs(v)}` : '0'}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11.5px] font-semibold text-ink-mute">
        <span className="flex items-center gap-2">
          <span className="h-3 w-10 rounded bg-gradient-to-r from-[rgba(181,71,58,0.85)] to-[rgba(181,71,58,0.2)]" aria-hidden="true" /> Defisit (harga berisiko naik)
        </span>
        <span className="flex items-center gap-2">
          <span className="h-3 w-4 rounded bg-mint-soft ring-1 ring-forest/20" aria-hidden="true" /> Seimbang ±4%
        </span>
        <span className="flex items-center gap-2">
          <span className="h-3 w-10 rounded bg-gradient-to-r from-[rgba(201,130,43,0.2)] to-[rgba(201,130,43,0.9)]" aria-hidden="true" /> Surplus (harga petani berisiko jatuh)
        </span>
      </div>
    </div>
  );
}
