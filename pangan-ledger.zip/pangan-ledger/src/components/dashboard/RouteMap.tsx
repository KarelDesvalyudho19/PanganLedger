import { Factory, Leaf, Route, Truck } from 'lucide-react';
import { METRIK_RUTE, RUTE_HIJAU, TITIK } from '../../data/kontrak';
import { num } from '../../lib/format';

/** Peta skematis (bukan peta asli) Rejang Lebong → Kota Bengkulu dengan rute hijau gabungan. */
export function RouteMap() {
  const byId = Object.fromEntries(TITIK.map((t) => [t.id, t]));
  const hub = byId.cu;
  const kb = byId.kb;
  const path = RUTE_HIJAU.map((id, i) => `${i ? 'L' : 'M'}${byId[id].x} ${byId[id].y}`).join(' ');
  const pickups = TITIK.filter((t) => t.jenis === 'jemput');
  const m = METRIK_RUTE;
  const emisiTanpa = m.kmTanpa * m.emisiFaktor;
  const emisiDengan = m.kmDengan * m.emisiFaktor;
  const susutKg = (m.muatanTon * 1000 * (m.susutTanpaPct - m.susutDenganPct)) / 100;

  return (
    <div>
      <div className="relative overflow-hidden rounded-2xl border border-line bg-[#F6F3EA]">
        <svg viewBox="0 0 640 420" className="h-auto w-full" role="img" aria-label="Peta skematis rute hijau dari titik jemput di Rejang Lebong melalui hub Curup dan Kepahiang ke Kota Bengkulu.">
          <defs>
            <pattern id="dots" width="16" height="16" patternUnits="userSpaceOnUse">
              <circle cx="1.2" cy="1.2" r="1.2" fill="#1F5F4A" opacity="0.08" />
            </pattern>
            <marker id="arrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
              <path d="M0 0L10 5L0 10z" fill="#1F5F4A" />
            </marker>
          </defs>
          <rect width="640" height="420" fill="url(#dots)" />
          {/* kontur pegunungan Bukit Barisan */}
          <path d="M0 120 C 90 70, 170 40, 270 90 S 420 170, 470 130" stroke="#1F5F4A" strokeOpacity="0.14" fill="none" strokeWidth="1.2" />
          <path d="M0 160 C 100 110, 190 90, 290 140 S 420 210, 500 180" stroke="#1F5F4A" strokeOpacity="0.1" fill="none" strokeWidth="1" />
          {/* garis pantai */}
          <path d="M420 420 C 470 380, 520 360, 560 300 S 620 230, 640 210 L 640 420 Z" fill="#DCEBE3" opacity="0.8" />
          <text x="604" y="404" textAnchor="end" fontSize="11" fill="#1F5F4A" opacity="0.6" fontStyle="italic">Samudra Hindia</text>
          <text x="28" y="32" fontSize="11" fontWeight="700" fill="#66737B" letterSpacing="1.5">KAB. REJANG LEBONG</text>
          <text x="318" y="292" fontSize="10" fontWeight="700" fill="#66737B" letterSpacing="1.2">KAB. KEPAHIANG</text>

          {/* rute terpisah (tanpa konsolidasi) */}
          {pickups.map((p) => (
            <path key={`old-${p.id}`} d={`M${p.x} ${p.y} Q ${(p.x + kb.x) / 2} ${(p.y + kb.y) / 2 - 70} ${kb.x} ${kb.y}`} stroke="#8A959C" strokeOpacity="0.45" strokeDasharray="3 5" fill="none" strokeWidth="1.2" />
          ))}

          {/* rute hijau */}
          <path d={path} stroke="#DCEBE3" strokeWidth="11" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          <path d={path} stroke="#1F5F4A" strokeWidth="3.4" fill="none" strokeLinecap="round" strokeLinejoin="round" markerEnd="url(#arrow)" strokeDasharray="10 7">
            <animate attributeName="stroke-dashoffset" from="34" to="0" dur="1.6s" repeatCount="indefinite" />
          </path>

          {TITIK.map((t) => {
            const isHub = t.jenis === 'hub';
            const isEnd = t.jenis === 'tujuan';
            const r = isHub ? 11 : isEnd ? 12 : t.jenis === 'transit' ? 6 : 8;
            const fill = isHub ? '#1F5F4A' : isEnd ? '#C9822B' : t.jenis === 'transit' ? '#fff' : '#fff';
            const labelRight = t.x < 300;
            return (
              <g key={t.id}>
                <circle cx={t.x} cy={t.y} r={r + 5} fill={isEnd ? '#C9822B' : '#1F5F4A'} opacity="0.12" />
                <circle cx={t.x} cy={t.y} r={r} fill={fill} stroke="#1F5F4A" strokeWidth={t.jenis === 'jemput' || t.jenis === 'transit' ? 2.4 : 0} />
                <text x={labelRight ? t.x + r + 8 : t.x - r - 8} y={isEnd ? t.y + 30 : t.y + 4} textAnchor={isEnd ? 'middle' : labelRight ? 'start' : 'end'} fontSize="12" fontWeight="700" fill="#1E2A30">
                  {t.nama}
                </text>
                {t.muatanKg && (
                  <text x={labelRight ? t.x + r + 8 : t.x - r - 8} y={t.y + 18} textAnchor={labelRight ? 'start' : 'end'} fontSize="10.5" fill="#66737B">
                    jemput {num(t.muatanKg)} kg
                  </text>
                )}
              </g>
            );
          })}
          <text x={hub.x + 19} y={hub.y + 18} fontSize="10.5" fill="#66737B">sortasi & cold box</text>
        </svg>
        <div className="absolute left-3 top-10 flex flex-col gap-1.5 rounded-xl bg-white/90 px-3 py-2.5 text-[11px] font-semibold text-ink-soft shadow-sm backdrop-blur sm:left-auto sm:right-3 sm:top-3">
          <span className="flex items-center gap-2"><span className="w-5 border-t-[3px] border-dashed border-forest" aria-hidden="true" />Rute hijau gabungan</span>
          <span className="flex items-center gap-2"><span className="w-5 border-t border-dashed border-ink-mute" aria-hidden="true" />Rute terpisah (lama)</span>
        </div>
      </div>

      <dl className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Metric icon={Route} label="Jarak tempuh" value={`${m.kmDengan} km`} sub={`dari ${m.kmTanpa} km (–${Math.round((1 - m.kmDengan / m.kmTanpa) * 100)}%)`} />
        <Metric icon={Factory} label="Emisi CO₂e" value={`${num(emisiDengan)} kg`} sub={`hemat ${num(emisiTanpa - emisiDengan)} kg per rit`} />
        <Metric icon={Leaf} label="Susut dihindari" value={`${num(susutKg)} kg`} sub={`susut ${m.susutTanpaPct}% → ${m.susutDenganPct}%`.replace(/\./g, ',')} />
        <Metric icon={Truck} label="Km per ton" value={`${(m.kmDengan / m.muatanTon).toLocaleString('id-ID', { maximumFractionDigits: 1 })}`} sub={`dari ${(m.kmTanpa / m.muatanTon).toLocaleString('id-ID', { maximumFractionDigits: 1 })} km/ton`} />
      </dl>
    </div>
  );
}

function Metric({ icon: Icon, label, value, sub }: { icon: typeof Route; label: string; value: string; sub: string }) {
  return (
    <div className="rounded-xl border border-line bg-white p-3.5">
      <dt className="flex items-center gap-1.5 text-[11.5px] font-semibold text-ink-mute">
        <Icon className="h-3.5 w-3.5 text-forest" aria-hidden="true" /> {label}
      </dt>
      <dd>
        <span className="num mt-1 block text-lg font-extrabold text-ink">{value}</span>
        <span className="num block text-[11.5px] font-semibold text-forest">{sub}</span>
      </dd>
    </div>
  );
}
