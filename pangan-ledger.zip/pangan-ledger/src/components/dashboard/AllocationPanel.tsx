import { useMemo } from 'react';
import { Award } from 'lucide-react';
import { LOT_SURPLUS, alokasikan } from '../../data/kontrak';
import { num, rp, rpJt } from '../../lib/format';

export function AllocationPanel() {
  const alok = useMemo(() => alokasikan(LOT_SURPLUS.volumeKg), []);
  const maxBersih = Math.max(...alok.map((a) => a.bersih));
  const nilaiTotal = alok.reduce((s, a) => s + a.alokasiKg * a.bersih, 0);
  const lokal = alok.find((a) => a.nama === 'Pasar Atas Curup')!;
  const nilaiLokal = LOT_SURPLUS.volumeKg * lokal.bersih;

  return (
    <div>
      <div className="rounded-xl border border-line bg-cream px-4 py-3 text-[13px]">
        <p className="font-semibold text-ink">
          Lot surplus: {LOT_SURPLUS.komoditas} {num(LOT_SURPLUS.volumeKg)} kg
        </p>
        <p className="text-ink-mute">
          {LOT_SURPLUS.asal} · panen {LOT_SURPLUS.panen}
        </p>
      </div>

      <ol className="mt-4 space-y-2.5">
        {alok.map((a) => {
          const best = a.peringkat === 1;
          const share = (a.alokasiKg / LOT_SURPLUS.volumeKg) * 100;
          return (
            <li key={a.nama} className={`rounded-xl border p-3.5 ${best ? 'border-forest/40 bg-mint-soft' : 'border-line bg-white'}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 text-[13.5px] font-bold text-ink">
                    <span className="num text-ink-mute">{a.peringkat}.</span> {a.nama}
                    {best && (
                      <span className="ml-1 inline-flex items-center gap-1 rounded-full bg-forest px-2 py-0.5 text-[10.5px] font-bold text-white">
                        <Award className="h-3 w-3" aria-hidden="true" /> Tujuan terbaik
                      </span>
                    )}
                  </p>
                  <p className="text-[11.5px] text-ink-mute">
                    {a.jenis} · {a.lokasi} · kapasitas {num(a.kapasitasKg)} kg
                  </p>
                </div>
                <div className="text-right">
                  <p className="num text-[15px] font-extrabold text-forest">{rp(a.bersih)}</p>
                  <p className="text-[10.5px] font-semibold uppercase tracking-wide text-ink-mute">bersih/kg</p>
                </div>
              </div>
              <div className="num mt-2.5 grid grid-cols-3 gap-2 text-[11.5px] text-ink-soft">
                <span>Harga {rp(a.harga)}</span>
                <span className="text-brick">Angkut –{rp(a.angkut)}</span>
                <span className="text-right font-semibold text-ink">{a.alokasiKg > 0 ? `${num(a.alokasiKg)} kg` : 'Tidak dialokasikan'}</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-sand" aria-hidden="true">
                <span className="block h-full rounded-full bg-forest" style={{ width: `${share}%`, opacity: 0.4 + (a.bersih / maxBersih) * 0.6 }} />
              </div>
            </li>
          );
        })}
      </ol>

      <div className="mt-4 grid grid-cols-2 gap-3 border-t border-line pt-4">
        <div>
          <p className="text-[11.5px] font-semibold text-ink-mute">Nilai bersih alokasi</p>
          <p className="num text-lg font-extrabold text-ink">{rpJt(nilaiTotal, 2)}</p>
        </div>
        <div>
          <p className="text-[11.5px] font-semibold text-ink-mute">vs semua ke pasar lokal</p>
          <p className="num text-lg font-extrabold text-forest">+{rpJt(nilaiTotal - nilaiLokal, 2)}</p>
        </div>
      </div>
    </div>
  );
}
