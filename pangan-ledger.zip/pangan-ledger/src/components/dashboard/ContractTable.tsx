import { useMemo, useState } from 'react';
import { Building2, Hotel, Soup, UtensilsCrossed } from 'lucide-react';
import { KONTRAK, type JenisPembeli, type StatusUangMuka } from '../../data/kontrak';
import { num, rp } from '../../lib/format';

const STATUS: Record<StatusUangMuka, string> = {
  Diterima: 'bg-mint text-forest',
  Sebagian: 'bg-amber-soft text-amber-ink',
  Menunggu: 'bg-sand text-ink-soft',
};

const PEMBELI_ICON: Record<JenisPembeli, typeof Building2> = {
  'BUMD Pangan': Building2,
  Katering: UtensilsCrossed,
  Hotel: Hotel,
  'Dapur SPPG': Soup,
};

const FILTERS = ['Semua', 'BUMD Pangan', 'Dapur SPPG', 'Katering', 'Hotel'] as const;

export function ContractTable() {
  const [f, setF] = useState<(typeof FILTERS)[number]>('Semua');
  const rows = useMemo(() => (f === 'Semua' ? KONTRAK : KONTRAK.filter((k) => k.jenisPembeli === f)), [f]);

  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-2" role="group" aria-label="Saring menurut jenis pembeli">
        {FILTERS.map((x) => (
          <button
            key={x}
            type="button"
            aria-pressed={f === x}
            onClick={() => setF(x)}
            className={`rounded-full px-3 py-1.5 text-[12.5px] font-semibold transition-colors ${f === x ? 'bg-ink text-white' : 'border border-line bg-cream text-ink-soft hover:text-ink'}`}
          >
            {x}
          </button>
        ))}
      </div>
      <div className="scrollbar-thin relative -mx-5 overflow-x-auto sm:-mx-6">
        <table className="table-clean w-full min-w-[920px] text-[13.5px]">
          <caption className="sr-only">Daftar kontrak koridor aktif</caption>
          <thead>
            <tr>
              <th scope="col" className="!pl-5 sm:!pl-6">Kelompok tani</th>
              <th scope="col">Komoditas</th>
              <th scope="col" className="!text-right">Volume</th>
              <th scope="col" className="!text-right">Floor</th>
              <th scope="col" className="!text-right">Ceiling</th>
              <th scope="col">Pembeli</th>
              <th scope="col">Uang muka</th>
              <th scope="col" className="!pr-5 sm:!pr-6">Panen</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((k) => {
              const Icon = PEMBELI_ICON[k.jenisPembeli];
              return (
                <tr key={k.id} className="transition-colors hover:bg-cream/70">
                  <td className="!pl-5 sm:!pl-6">
                    <p className="font-semibold text-ink">{k.kelompok}</p>
                    <p className="text-[11.5px] text-ink-mute">
                      {k.kecamatan} · {k.id}
                    </p>
                  </td>
                  <td className="whitespace-nowrap">{k.komoditas}</td>
                  <td className="num whitespace-nowrap text-right font-semibold">{num(k.volumeKg)} kg</td>
                  <td className="num whitespace-nowrap text-right text-forest">{rp(k.floor)}</td>
                  <td className="num whitespace-nowrap text-right text-amber-ink">{rp(k.ceiling)}</td>
                  <td>
                    <span className="flex items-center gap-2">
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-mint-soft text-forest">
                        <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                      </span>
                      <span className="leading-tight">
                        <span className="block font-medium text-ink">{k.pembeli}</span>
                        <span className="text-[11.5px] text-ink-mute">{k.jenisPembeli}</span>
                      </span>
                    </span>
                  </td>
                  <td className="whitespace-nowrap">
                    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-bold ${STATUS[k.statusUangMuka]}`}>
                      <span className="num">{k.uangMukaPct}%</span> · {k.statusUangMuka}
                    </span>
                    <span className="num mt-1 block text-[11px] text-ink-mute">{rp((k.uangMukaPct / 100) * k.floor * k.volumeKg)}</span>
                  </td>
                  <td className="num whitespace-nowrap !pr-5 sm:!pr-6">{k.panen}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
