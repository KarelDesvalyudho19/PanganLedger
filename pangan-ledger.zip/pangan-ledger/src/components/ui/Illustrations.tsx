interface SvgProps {
  className?: string;
}

/** Kontur bukit bertingkat — garis tipis, mewarisi currentColor. */
export function HillLines({ className }: SvgProps) {
  return (
    <svg viewBox="0 0 640 160" fill="none" className={className} aria-hidden="true" preserveAspectRatio="xMaxYMax meet">
      <path d="M0 150 C 80 110, 150 70, 230 92 S 380 150, 460 104 S 590 40, 640 62" stroke="currentColor" strokeWidth="1.4" />
      <path d="M0 158 C 90 126, 170 96, 250 112 S 400 160, 480 124 S 600 74, 640 88" stroke="currentColor" strokeWidth="1.1" />
      <path d="M40 160 C 120 138, 200 118, 280 130 S 420 160, 500 140 S 610 104, 640 112" stroke="currentColor" strokeWidth="0.9" />
      <path d="M520 104 c 6 -18, 18 -26, 30 -28 c -2 14, -12 24, -30 28 z" stroke="currentColor" strokeWidth="1.2" />
      <path d="M520 104 c 8 -9, 16 -15, 26 -20" stroke="currentColor" strokeWidth="0.9" />
    </svg>
  );
}

/** Ikon logo: buku besar + daun. */
export function LedgerLeafMark({ className }: SvgProps) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      <rect width="40" height="40" rx="11" fill="#1F5F4A" />
      <path d="M11 10h12.5a5 5 0 0 1 5 5v15H16a5 5 0 0 1-5-5z" fill="none" stroke="#FAF7F0" strokeWidth="2.2" strokeLinejoin="round" />
      <path d="M15 16.5h8.5M15 21h6" stroke="#FAF7F0" strokeWidth="2" strokeLinecap="round" />
      <path d="M24.5 29.5c0-6 3.2-9.2 8-9.8-.6 5.3-3.3 8.6-8 9.8z" fill="#C9822B" />
      <path d="M24.8 29.2c1.8-2.4 3.7-4.4 6-6" stroke="#FAF7F0" strokeWidth="0.9" strokeLinecap="round" />
    </svg>
  );
}

/** Daun garis untuk ornamen kartu. */
export function LeafLine({ className }: SvgProps) {
  return (
    <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
      <path d="M10 54C10 30 26 14 54 10 52 36 36 52 10 54Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M10 54C22 40 34 28 48 17" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M22 40l-1-9M30 32l-1-9M36 26l8 1M27 36l9 1" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
    </svg>
  );
}

/** Lanskap besar untuk hero: bukit, teras sayur, matahari. */
export function HeroLandscape({ className }: SvgProps) {
  return (
    <svg viewBox="0 0 720 420" fill="none" className={className} aria-hidden="true">
      <circle cx="560" cy="110" r="46" stroke="#C9822B" strokeOpacity="0.55" strokeWidth="1.4" />
      <circle cx="560" cy="110" r="64" stroke="#C9822B" strokeOpacity="0.22" strokeWidth="1" />
      <path d="M0 300 C 110 220, 210 190, 320 232 S 520 300, 720 200" stroke="#1F5F4A" strokeOpacity="0.28" strokeWidth="1.5" />
      <path d="M0 330 C 130 262, 240 240, 350 270 S 560 330, 720 250" stroke="#1F5F4A" strokeOpacity="0.22" strokeWidth="1.2" />
      <path d="M0 360 C 140 306, 260 290, 380 310 S 580 360, 720 300" stroke="#1F5F4A" strokeOpacity="0.18" strokeWidth="1" />
      {Array.from({ length: 9 }).map((_, i) => (
        <path
          key={i}
          d={`M${40 + i * 74} ${392 - (i % 3) * 6} q 10 -22 22 -26 q -2 16 -22 26 z`}
          stroke="#1F5F4A"
          strokeOpacity="0.3"
          strokeWidth="1"
        />
      ))}
      <path d="M0 400 H720" stroke="#1F5F4A" strokeOpacity="0.12" />
    </svg>
  );
}
