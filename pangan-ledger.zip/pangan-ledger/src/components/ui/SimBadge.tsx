import { FlaskConical } from 'lucide-react';

export function SimBadge({ className = '', label = 'Data simulasi' }: { className?: string; label?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border border-amber/30 bg-amber-soft px-2 py-0.5 text-[11px] font-semibold text-amber-ink ${className}`}
    >
      <FlaskConical className="h-3 w-3" aria-hidden="true" />
      {label}
    </span>
  );
}
