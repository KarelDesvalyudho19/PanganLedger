import { useEffect, useId, useState } from 'react';

interface Props {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  /** tampilan nilai di samping label */
  display: string;
  prefix?: string;
  suffix?: string;
  hint?: string;
  inputWidth?: string;
}

/** Slider + input angka yang tersinkron, dengan label yang dapat diakses. */
export function SliderField({ label, value, min, max, step, onChange, display, prefix, suffix, hint, inputWidth = 'w-28' }: Props) {
  const id = useId();
  const fmt = (v: number) => v.toLocaleString('id-ID', { maximumFractionDigits: 2 });
  const [draft, setDraft] = useState(fmt(value));
  const [focused, setFocused] = useState(false);
  useEffect(() => {
    if (!focused) setDraft(fmt(value));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, focused]);

  const fill = ((Math.min(Math.max(value, min), max) - min) / (max - min)) * 100;

  const commit = (raw: string) => {
    const n = Number(raw.replace(/\./g, '').replace(',', '.'));
    if (Number.isFinite(n)) onChange(Math.min(Math.max(n, min), max));
    else setDraft(fmt(value));
  };

  return (
    <div>
      <div className="flex items-baseline justify-between gap-3">
        <label htmlFor={`${id}-range`} className="text-sm font-semibold text-ink">
          {label}
        </label>
        <span className="num text-sm font-bold text-forest">{display}</span>
      </div>
      <input
        id={`${id}-range`}
        type="range"
        className="range mt-3"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{ ['--fill' as string]: `${fill}%` }}
      />
      <div className="mt-2.5 flex items-center justify-between gap-3">
        {hint ? <p className="text-[12px] leading-snug text-ink-mute">{hint}</p> : <span />}
        <label className="flex shrink-0 items-center gap-1.5 rounded-lg border border-line bg-cream px-2 py-1 focus-within:border-forest">
          <span className="sr-only">{label} (angka)</span>
          {prefix && <span className="text-xs font-semibold text-ink-mute">{prefix}</span>}
          <input
            type="text"
            inputMode="decimal"
            className={`num ${inputWidth} bg-transparent text-right text-sm font-semibold text-ink outline-none`}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onFocus={() => setFocused(true)}
            onBlur={(e) => {
              setFocused(false);
              commit(e.target.value);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') commit((e.target as HTMLInputElement).value);
            }}
          />
          {suffix && <span className="text-xs font-semibold text-ink-mute">{suffix}</span>}
        </label>
      </div>
    </div>
  );
}
