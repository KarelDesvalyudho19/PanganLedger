import type { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { HillLines } from './Illustrations';

interface Props {
  eyebrow: string;
  title: ReactNode;
  lead: ReactNode;
  icon?: ReactNode;
  aside?: ReactNode;
}

export function PageHeader({ eyebrow, title, lead, icon, aside }: Props) {
  return (
    <header className="relative overflow-hidden border-b border-line bg-gradient-to-b from-mint-soft to-cream">
      <HillLines className="pointer-events-none absolute -bottom-4 right-0 h-40 w-[640px] max-w-none text-forest/15" />
      <div className="container-page relative py-10 sm:py-14">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <p className="eyebrow flex items-center gap-2">
              {icon}
              {eyebrow}
            </p>
            <h1 className="mt-3 text-3xl leading-tight text-ink sm:text-[2.6rem]">{title}</h1>
            <p className="mt-3 text-base leading-relaxed text-ink-soft sm:text-lg">{lead}</p>
          </div>
          {aside}
        </motion.div>
      </div>
    </header>
  );
}
