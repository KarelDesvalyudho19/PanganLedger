import { useEffect, useState } from 'react';
import { useInViewOnce } from '../../lib/useInView';

interface Props {
  value: number;
  format?: (v: number) => string;
  duration?: number;
  className?: string;
}

/** Angka yang menghitung naik saat pertama kali terlihat. */
export function CountUp({ value, format = (v) => Math.round(v).toLocaleString('id-ID'), duration = 1400, className }: Props) {
  const { ref, inView } = useInViewOnce<HTMLSpanElement>();
  const [shown, setShown] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduce) {
      setShown(value);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const from = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setShown(from + (value - from) * eased);
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, value, duration]);

  return (
    <span ref={ref} className={`num ${className ?? ''}`} aria-label={format(value)}>
      <span aria-hidden="true">{format(shown)}</span>
    </span>
  );
}
