import type { ReactNode } from 'react';
import { SimBadge } from './SimBadge';

interface Props {
  title?: ReactNode;
  subtitle?: ReactNode;
  action?: ReactNode;
  simulasi?: boolean;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
}

/** Kartu panel standar: judul, subjudul, badge "Data simulasi" opsional. */
export function Panel({ title, subtitle, action, simulasi, children, className = '', bodyClassName = '' }: Props) {
  return (
    <section className={`card ${className}`}>
      {(title || action || simulasi) && (
        <div className="flex flex-wrap items-start justify-between gap-3 px-5 pt-5 sm:px-6">
          <div className="min-w-0">
            {title && <h3 className="font-sans text-base font-bold tracking-normal text-ink">{title}</h3>}
            {subtitle && <p className="mt-1 text-sm text-ink-mute">{subtitle}</p>}
          </div>
          <div className="flex items-center gap-2">
            {simulasi && <SimBadge />}
            {action}
          </div>
        </div>
      )}
      <div className={`px-5 pb-5 pt-4 sm:px-6 sm:pb-6 ${bodyClassName}`}>{children}</div>
    </section>
  );
}
