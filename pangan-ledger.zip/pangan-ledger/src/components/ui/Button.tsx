import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'light';

const base =
  'inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-50';
const variants: Record<Variant, string> = {
  primary: 'bg-forest text-white shadow-[0_6px_18px_-8px_rgb(31_95_74/0.7)] hover:bg-forest-deep hover:-translate-y-0.5',
  secondary: 'border border-forest/25 bg-white text-forest hover:border-forest/50 hover:bg-mint-soft',
  ghost: 'text-forest hover:bg-mint-soft',
  light: 'bg-white text-forest-ink hover:bg-mint-soft',
};

export function btn(variant: Variant = 'primary', extra = '') {
  return `${base} ${variants[variant]} ${extra}`;
}

interface LinkProps {
  to: string;
  variant?: Variant;
  children: ReactNode;
  className?: string;
}

export function ButtonLink({ to, variant = 'primary', children, className = '' }: LinkProps) {
  return (
    <Link to={to} className={btn(variant, className)}>
      {children}
    </Link>
  );
}
