import { CountUp } from './CountUp';
import { pct } from '../../lib/format';

interface Props {
  nilai: number;
  digits?: number;
  label: string;
  keterangan?: string;
  sumber: string;
  tone?: 'forest' | 'amber' | 'brick';
}

const TONE = {
  forest: 'text-forest',
  amber: 'text-amber-ink',
  brick: 'text-brick',
};
const BAR = {
  forest: 'bg-forest',
  amber: 'bg-amber',
  brick: 'bg-brick',
};

export function StatCard({ nilai, digits = 2, label, keterangan, sumber, tone = 'forest' }: Props) {
  return (
    <div className="card relative flex h-full flex-col overflow-hidden p-5 transition-transform duration-300 hover:-translate-y-1 sm:p-6">
      <span className={`absolute inset-x-0 top-0 h-1 ${BAR[tone]}`} aria-hidden="true" />
      <CountUp value={nilai} format={(v) => pct(v, digits)} className={`font-serif text-[2.6rem] leading-none ${TONE[tone]}`} />
      <p className="mt-3 text-sm font-semibold leading-snug text-ink">{label}</p>
      {keterangan && <p className="mt-1 text-sm text-ink-mute">{keterangan}</p>}
      <p className="mt-auto pt-4 text-[11px] font-medium text-ink-mute">Sumber: {sumber}</p>
    </div>
  );
}
