import { Area, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { rp, rpRb } from '../../lib/format';
import { C, axisLine, axisTick } from './theme';
import { TooltipShell, type TipProps } from './ChartTooltip';

interface Datum {
  bulan: string;
  petani: number;
  konsumen: number;
  selisih: number;
}

function Tip({ active, payload, label }: TipProps) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload as unknown as Datum;
  return (
    <TooltipShell
      title={String(label)}
      rows={[
        { label: 'Konsumen (Kota Bengkulu)', value: rp(d.konsumen), color: C.amber },
        { label: 'Petani (Rejang Lebong)', value: rp(d.petani), color: C.forest },
        { label: 'Selisih', value: rp(d.selisih), color: C.brick, strong: true },
      ]}
    />
  );
}

export function SpreadChart({ data }: { data: Datum[] }) {
  const withBand = data.map((d) => ({ ...d, band: [d.petani, d.konsumen] as [number, number] }));
  return (
    <div className="h-[300px] w-full xl:h-[390px]" role="img" aria-label="Grafik harga cabai merah di tingkat petani dan konsumen beserta selisihnya selama 12 bulan.">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={withBand} margin={{ top: 16, right: 12, bottom: 0, left: 4 }}>
          <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
          <XAxis dataKey="bulan" tick={axisTick} axisLine={axisLine} tickLine={false} interval="preserveStartEnd" minTickGap={10} />
          <YAxis tickFormatter={rpRb} tick={axisTick} axisLine={false} tickLine={false} width={52} />
          <Tooltip content={<Tip />} cursor={{ stroke: C.ink, strokeOpacity: 0.2 }} />
          <Area type="monotone" dataKey="band" stroke="none" fill={C.brick} fillOpacity={0.09} isAnimationActive={false} name="Selisih" />
          <Line type="monotone" dataKey="konsumen" stroke={C.amber} strokeWidth={2.6} dot={{ r: 3, fill: C.amber, strokeWidth: 0 }} isAnimationActive={false} name="Konsumen" />
          <Line type="monotone" dataKey="petani" stroke={C.forest} strokeWidth={2.6} dot={{ r: 3, fill: C.forest, strokeWidth: 0 }} isAnimationActive={false} name="Petani" />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
