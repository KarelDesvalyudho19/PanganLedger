import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { rp, rpJt } from '../../lib/format';
import { TooltipShell, type TipProps } from './ChartTooltip';

export interface DonutDatum {
  name: string;
  value: number;
  color: string;
}

function Tip({ active, payload, total }: TipProps & { total: number }) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload as unknown as DonutDatum;
  return <TooltipShell title={d.name} rows={[{ label: 'Nilai', value: rp(d.value), color: d.color }, { label: 'Porsi', value: `${((d.value / total) * 100).toLocaleString('id-ID', { maximumFractionDigits: 1 })}%` }]} />;
}

export function CostDonut({ data, total }: { data: DonutDatum[]; total: number }) {
  return (
    <div className="relative h-[200px] w-full" role="img" aria-label={`Komposisi biaya produksi, total ${rp(total)}.`}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="name" innerRadius="64%" outerRadius="92%" paddingAngle={data.length > 1 ? 2 : 0} stroke="none" isAnimationActive={false}>
            {data.map((d) => (
              <Cell key={d.name} fill={d.color} />
            ))}
          </Pie>
          <Tooltip content={<Tip total={total} />} />
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-ink-mute">Total biaya</span>
        <span className="num mt-0.5 font-serif text-xl text-ink">{rpJt(total, 2)}</span>
      </div>
    </div>
  );
}
