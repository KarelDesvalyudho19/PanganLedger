import { Bar, BarChart, CartesianGrid, Cell, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { rpJtSigned } from '../../lib/format';
import { C, axisLine, axisTick } from './theme';
import { TooltipShell, type TipProps } from './ChartTooltip';

export interface ScenarioDatum {
  nama: string;
  tanpa: number; // juta
  dengan: number; // juta
}

function Tip({ active, payload, label }: TipProps) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload as unknown as ScenarioDatum;
  return (
    <TooltipShell
      title={String(label)}
      rows={[
        { label: 'Tanpa kontrak', value: rpJtSigned(d.tanpa * 1e6), color: C.gray },
        { label: 'Dengan kontrak', value: rpJtSigned(d.dengan * 1e6), color: C.forest, strong: true },
      ]}
    />
  );
}

export function ScenarioBars({ data, active }: { data: ScenarioDatum[]; active?: string }) {
  const fmt = (v: number) => `${v > 0 ? '+' : v < 0 ? '–' : ''}${Math.abs(v)}`;
  return (
    <div className="h-[250px] w-full" role="img" aria-label="Diagram batang laba per skenario harga, tanpa dan dengan kontrak.">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 22, right: 8, bottom: 14, left: 0 }} barGap={6} barCategoryGap="26%">
          <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
          <XAxis dataKey="nama" tick={axisTick} axisLine={axisLine} tickLine={false} />
          <YAxis tickFormatter={(v: number) => `${v} jt`} tick={axisTick} axisLine={false} tickLine={false} width={56} />
          <ReferenceLine y={0} stroke={C.ink} strokeOpacity={0.35} />
          <Tooltip content={<Tip />} cursor={{ fill: C.mint, fillOpacity: 0.4 }} />
          <Bar dataKey="tanpa" name="Tanpa kontrak" radius={[6, 6, 6, 6]} maxBarSize={44} isAnimationActive={false} label={{ position: 'top', formatter: fmt, fill: C.inkMute, fontSize: 11, fontWeight: 700 }}>
            {data.map((d) => (
              <Cell key={d.nama} fill={d.tanpa < 0 ? C.brick : C.gray} fillOpacity={active && active !== d.nama ? 0.45 : 0.9} />
            ))}
          </Bar>
          <Bar dataKey="dengan" name="Dengan kontrak" radius={[6, 6, 6, 6]} maxBarSize={44} isAnimationActive={false} label={{ position: 'top', formatter: fmt, fill: C.forest, fontSize: 11, fontWeight: 700 }}>
            {data.map((d) => (
              <Cell key={d.nama} fill={C.forest} fillOpacity={active && active !== d.nama ? 0.45 : 1} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
