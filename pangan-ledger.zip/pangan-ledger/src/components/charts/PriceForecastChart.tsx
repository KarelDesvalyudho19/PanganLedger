import { Area, CartesianGrid, ComposedChart, Line, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { HargaPoint } from '../../data/radar';
import { rp, rpRb } from '../../lib/format';
import { C, axisLine, axisTick } from './theme';
import { TooltipShell, type TipProps } from './ChartTooltip';

function Tip({ active, payload, label }: TipProps) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload as unknown as HargaPoint;
  const rows = [] as { label: string; value: string; color?: string; strong?: boolean }[];
  if (d.aktual !== undefined) rows.push({ label: 'Harga aktual', value: rp(d.aktual), color: C.forest, strong: true });
  if (d.prakiraan !== undefined && d.aktual === undefined) {
    rows.push({ label: 'Prakiraan', value: rp(d.prakiraan), color: C.amber, strong: true });
    if (d.pita) rows.push({ label: 'Rentang 80%', value: `${rpRb(d.pita[0])}–${rpRb(d.pita[1])}` });
  }
  rows.push({ label: 'HPP acuan', value: rp(d.hpp), color: C.brick });
  return <TooltipShell title={`Pekan ${label}`} rows={rows} />;
}

export function PriceForecastChart({ data, hariIni, hpp }: { data: HargaPoint[]; hariIni: string; hpp: number }) {
  const ticks = data.filter((_, i) => i % 8 === 0).map((d) => d.tanggal);
  // Domain Y selalu memuat garis HPP agar jarak harga ke titik impas terlihat
  const nilai = data.flatMap((d) => [d.aktual, d.prakiraan, ...(d.pita ?? [])]).filter((v): v is number => typeof v === 'number');
  const step = hpp >= 10000 ? 5000 : 1000;
  const yMin = Math.floor((Math.min(...nilai, hpp) * 0.9) / step) * step;
  const yMax = Math.ceil((Math.max(...nilai) * 1.05) / step) * step;
  return (
    <div className="h-[300px] w-full sm:h-[360px] xl:h-[470px]" role="img" aria-label="Grafik harga historis 52 minggu dan prakiraan 8 minggu dengan pita ketidakpastian.">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 24, right: 12, bottom: 0, left: 4 }}>
          <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
          <XAxis dataKey="tanggal" ticks={ticks} tick={axisTick} axisLine={axisLine} tickLine={false} minTickGap={8} />
          <YAxis tickFormatter={rpRb} tick={axisTick} axisLine={false} tickLine={false} width={52} domain={[yMin, yMax]} allowDataOverflow />
          <Tooltip content={<Tip />} cursor={{ stroke: C.ink, strokeOpacity: 0.2 }} />
          <Area type="monotone" dataKey="pita" stroke="none" fill={C.amber} fillOpacity={0.18} isAnimationActive={false} name="Rentang prakiraan" />
          <ReferenceLine y={hpp} stroke={C.brick} strokeDasharray="5 4" label={{ value: `HPP ${rp(hpp)}`, position: 'insideBottomLeft', fill: C.brick, fontSize: 11, fontWeight: 700 }} />
          <ReferenceLine x={hariIni} stroke={C.ink} strokeOpacity={0.4} label={{ value: 'Hari ini', position: 'top', fill: C.ink, fontSize: 11, fontWeight: 600 }} />
          <Line type="monotone" dataKey="aktual" stroke={C.forest} strokeWidth={2.4} dot={false} isAnimationActive={false} name="Harga aktual" />
          <Line type="monotone" dataKey="prakiraan" stroke={C.amber} strokeWidth={2.6} strokeDasharray="6 5" dot={false} isAnimationActive={false} name="Prakiraan" connectNulls />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
