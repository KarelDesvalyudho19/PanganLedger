import { CartesianGrid, Line, LineChart, ReferenceArea, ReferenceDot, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useMemo } from 'react';
import { hargaKoridor, payoffSeries } from '../../lib/contract';
import { rp, rpJtSigned, rpRb } from '../../lib/format';
import { C, axisLine, axisTick } from './theme';
import { useMediaQuery } from '../../lib/useMediaQuery';
import { TooltipShell, type TipProps } from './ChartTooltip';

interface Props {
  produksiKg: number;
  totalBiaya: number;
  hpp: number;
  floor: number;
  ceiling: number;
  hargaPasar: number;
}

const MAX = 70_000;

function PayoffTip({ active, payload, floor, ceiling }: TipProps & { floor: number; ceiling: number }) {
  if (!active || !payload?.length) return null;
  const p = payload[0].payload as { harga: number; tanpa: number; dengan: number };
  return (
    <TooltipShell
      title={`Harga pasar ${rp(p.harga)}/kg`}
      rows={[
        { label: 'Tanpa kontrak', value: rpJtSigned(p.tanpa * 1e6), color: C.gray },
        { label: 'Dengan kontrak', value: rpJtSigned(p.dengan * 1e6), color: C.forest, strong: true },
      ]}
      footer={`Petani menerima ${rp(hargaKoridor(p.harga, floor, ceiling))}/kg`}
    />
  );
}

export function PayoffChart({ produksiKg, totalBiaya, hpp, floor, ceiling, hargaPasar }: Props) {
  const compact = useMediaQuery('(max-width: 639px)');
  const data = useMemo(() => payoffSeries(produksiKg, totalBiaya, floor, ceiling, MAX, 1000), [produksiKg, totalBiaya, floor, ceiling]);
  const titikY = (produksiKg * hargaKoridor(Math.min(hargaPasar, MAX), floor, ceiling) - totalBiaya) / 1e6;

  return (
    <div className="h-[300px] w-full sm:h-[360px]" role="img" aria-label={`Grafik payoff: laba tanpa dan dengan kontrak untuk harga pasar Rp0 hingga Rp70.000 per kg. Floor ${rp(floor)}, ceiling ${rp(ceiling)}, HPP ${rp(hpp)}.`}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 28, right: 12, bottom: 4, left: 4 }}>
          <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
          <ReferenceArea
            x1={0}
            x2={floor}
            fill={C.forest}
            fillOpacity={0.08}
            ifOverflow="hidden"
            label={{ value: compact ? 'Petani' : 'Perlindungan petani', position: 'insideTopLeft', fill: C.forest, fontSize: 11, fontWeight: 700 }}
          />
          <ReferenceArea
            x1={Math.min(ceiling, MAX)}
            x2={MAX}
            fill={C.amber}
            fillOpacity={0.11}
            ifOverflow="hidden"
            label={{ value: compact ? 'Pembeli' : 'Perlindungan pembeli', position: 'insideTopRight', fill: C.amberInk, fontSize: 11, fontWeight: 700 }}
          />
          <XAxis
            dataKey="harga"
            type="number"
            domain={[0, MAX]}
            ticks={compact ? [0, 20000, 40000, 60000] : [0, 10000, 20000, 30000, 40000, 50000, 60000, 70000]}
            tickFormatter={rpRb}
            tick={axisTick}
            axisLine={axisLine}
            tickLine={false}
          />
          <YAxis tickFormatter={(v: number) => `${v} jt`} tick={axisTick} axisLine={false} tickLine={false} width={58} />
          <ReferenceLine y={0} stroke={C.ink} strokeOpacity={0.35} />
          <ReferenceLine
            x={hpp}
            stroke={C.brick}
            strokeWidth={1.6}
            strokeDasharray="5 4"
            label={{ value: compact ? 'HPP' : `HPP ${rp(hpp)}`, position: 'insideBottomRight', fill: C.brick, fontSize: 11, fontWeight: 700 }}
          />
          <Tooltip content={<PayoffTip floor={floor} ceiling={ceiling} />} cursor={{ stroke: C.ink, strokeOpacity: 0.2 }} />
          <Line type="linear" dataKey="tanpa" name="Tanpa kontrak" stroke={C.gray} strokeWidth={2} strokeDasharray="7 6" dot={false} isAnimationActive={false} />
          <Line type="linear" dataKey="dengan" name="Dengan kontrak" stroke={C.forest} strokeWidth={3.5} dot={false} isAnimationActive={false} />
          {hargaPasar <= MAX && <ReferenceDot x={hargaPasar} y={titikY} r={6} fill={C.forest} stroke="#fff" strokeWidth={2.5} />}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
