export const C = {
  forest: '#1F5F4A',
  forestSoft: '#3E7F69',
  mint: '#DCEBE3',
  amber: '#C9822B',
  amberInk: '#8E5512',
  ink: '#1E2A30',
  inkMute: '#66737B',
  grid: '#E9E3D7',
  brick: '#B5473A',
  gray: '#8A959C',
};

export const axisTick = { fill: C.inkMute, fontSize: 11.5, fontWeight: 500 };
export const axisLine = { stroke: C.grid };
