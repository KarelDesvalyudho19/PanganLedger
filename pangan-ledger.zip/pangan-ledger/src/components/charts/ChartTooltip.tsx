import type { ReactNode } from 'react';

export interface TipItem {
  name?: string | number;
  value?: number | string | (number | string)[];
  color?: string;
  stroke?: string;
  fill?: string;
  dataKey?: string | number;
  payload?: Record<string, unknown>;
}

export interface TipProps {
  active?: boolean;
  label?: string | number;
  payload?: TipItem[];
}

interface ShellProps {
  title: ReactNode;
  rows: { label: ReactNode; value: ReactNode; color?: string; strong?: boolean }[];
  footer?: ReactNode;
}

export function TooltipShell({ title, rows, footer }: ShellProps) {
  return (
    <div className="min-w-[180px] rounded-xl border border-line bg-white/95 px-3.5 py-3 text-[12.5px] shadow-[var(--shadow-lift)] backdrop-blur">
      <p className="mb-2 font-semibold text-ink">{title}</p>
      <ul className="space-y-1.5">
        {rows.map((r, i) => (
          <li key={i} className="flex items-center justify-between gap-4">
            <span className="flex items-center gap-2 text-ink-mute">
              {r.color && <span className="h-2 w-2 rounded-full" style={{ background: r.color }} />}
              {r.label}
            </span>
            <span className={`num ${r.strong ? 'font-bold text-ink' : 'font-semibold text-ink'}`}>{r.value}</span>
          </li>
        ))}
      </ul>
      {footer && <p className="mt-2 border-t border-line pt-2 text-[11.5px] text-ink-mute">{footer}</p>}
    </div>
  );
}
