import { useEffect, useRef, useState, type FormEvent } from 'react';
import { motion } from 'framer-motion';
import { Mic, Send, Sparkles } from 'lucide-react';
import { useLedger } from '../../lib/store';
import { SARAN_KETIK } from '../../lib/parser';
import { JournalCard } from './JournalCard';
import { LedgerLeafMark } from '../ui/Illustrations';

type SpeechCtor = new () => {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
};

function getSpeech(): SpeechCtor | null {
  const w = window as unknown as { SpeechRecognition?: SpeechCtor; webkitSpeechRecognition?: SpeechCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function LedgerChat() {
  const { entries, addEntry, removeEntry } = useLedger();
  const [text, setText] = useState('');
  const [listening, setListening] = useState(false);
  const [voiceNote, setVoiceNote] = useState<string | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const prevCount = useRef(entries.length);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const grew = entries.length > prevCount.current;
    prevCount.current = entries.length;
    el.scrollTo({ top: el.scrollHeight, behavior: grew ? 'smooth' : 'auto' });
  }, [entries.length]);

  const submit = (e?: FormEvent) => {
    e?.preventDefault();
    const t = text.trim();
    if (!t) return;
    addEntry(t);
    setText('');
    setVoiceNote(null);
  };

  const startVoice = () => {
    const Speech = getSpeech();
    if (!Speech) {
      // Peramban tanpa Web Speech API: tampilkan transkrip contoh agar alur demo tetap utuh.
      setListening(true);
      window.setTimeout(() => {
        setListening(false);
        setText('beli urea 1 karung 350 ribu');
        setVoiceNote('Transkrip contoh (peramban ini belum mendukung pengenalan suara).');
      }, 1200);
      return;
    }
    try {
      const rec = new Speech();
      rec.lang = 'id-ID';
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      rec.onresult = (ev) => {
        const t = ev.results[0]?.[0]?.transcript ?? '';
        setText(t);
        setVoiceNote('Hasil pesan suara. Periksa lalu kirim.');
      };
      rec.onerror = () => setVoiceNote('Suara tidak tertangkap. Coba lagi atau ketik catatan.');
      rec.onend = () => setListening(false);
      setListening(true);
      rec.start();
    } catch {
      setListening(false);
    }
  };

  return (
    <section className="card flex h-[640px] flex-col overflow-hidden lg:h-[720px]" aria-label="Obrolan Buku Biaya Tani">
      <header className="flex items-center gap-3 border-b border-line px-4 py-3.5 sm:px-5">
        <LedgerLeafMark className="h-9 w-9" />
        <div className="min-w-0 flex-1">
          <p className="font-bold text-ink">Asisten Buku Biaya</p>
          <p className="truncate text-[12px] text-ink-mute">Ketik pengeluaran seperti biasa, sistem yang menjurnal</p>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-mint px-2.5 py-1 text-[11px] font-bold text-forest">
          <span className="h-1.5 w-1.5 rounded-full bg-forest" aria-hidden="true" /> Luring siap
        </span>
      </header>

      <div ref={scroller} className="scrollbar-thin flex-1 space-y-5 overflow-y-auto bg-[linear-gradient(#FAF7F0,#FFFFFF)] px-3 py-5 sm:px-5" aria-live="polite">
        <div className="mx-auto max-w-md rounded-xl bg-sand/70 px-4 py-3 text-center text-[12.5px] leading-relaxed text-ink-soft">
          Contoh: <span className="font-semibold">“beli NPK 2 karung 600 ribu”</span> atau{' '}
          <span className="font-semibold">“saya dan istri nyemprot 1 hari”</span>. Tenaga keluarga dinilai Rp100.000/hari kerja.
        </div>
        {entries.map((e) => (
          <motion.div key={e.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="space-y-2">
            <div className="flex justify-end">
              <div className="max-w-[85%] rounded-2xl rounded-br-md bg-forest px-4 py-2.5 text-[14px] text-white shadow-sm">
                {e.text}
                <span className="mt-0.5 block text-right text-[10.5px] text-white/60">{e.waktu}</span>
              </div>
            </div>
            <div className="flex gap-2">
              <span className="mt-1 hidden h-7 w-7 shrink-0 items-center justify-center rounded-full bg-mint text-forest sm:flex" aria-hidden="true">
                <Sparkles className="h-3.5 w-3.5" />
              </span>
              <div className="min-w-0 max-w-full flex-1 sm:max-w-[88%]">
                <JournalCard entry={e} onRemove={() => removeEntry(e.id)} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="border-t border-line bg-white px-3 py-3 sm:px-4">
        <div className="scrollbar-thin mb-2.5 flex gap-2 overflow-x-auto pb-1">
          {SARAN_KETIK.map((s) => (
            <button key={s} type="button" onClick={() => setText(s)} className="shrink-0 rounded-full border border-line bg-cream px-3 py-1.5 text-[12px] font-medium text-ink-soft hover:border-forest/40 hover:text-forest">
              {s}
            </button>
          ))}
        </div>
        {voiceNote && <p className="mb-2 text-[11.5px] text-amber-ink">{voiceNote}</p>}
        <form onSubmit={submit} className="flex items-center gap-2">
          <button
            type="button"
            onClick={startVoice}
            aria-label={listening ? 'Sedang mendengarkan' : 'Kirim pesan suara'}
            className={`relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full border transition-colors ${listening ? 'border-brick bg-brick text-white' : 'border-line bg-cream text-forest hover:bg-mint-soft'}`}
          >
            {listening && <span className="absolute inset-0 animate-ping rounded-full bg-brick/40" aria-hidden="true" />}
            <Mic className="relative h-5 w-5" aria-hidden="true" />
          </button>
          <label htmlFor="catatan-biaya" className="sr-only">
            Catatan biaya
          </label>
          <input
            id="catatan-biaya"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={listening ? 'Mendengarkan…' : 'Tulis pengeluaran, mis. “pestisida 1 botol 150 ribu”'}
            className="h-11 min-w-0 flex-1 rounded-full border border-line bg-cream px-4 text-[14px] text-ink placeholder:text-ink-mute/80 focus:border-forest focus:bg-white focus:outline-none focus:ring-2 focus:ring-forest/20"
            autoComplete="off"
          />
          <button type="submit" disabled={!text.trim()} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-forest text-white transition-colors hover:bg-forest-deep disabled:opacity-40" aria-label="Kirim catatan">
            <Send className="h-[18px] w-[18px]" aria-hidden="true" />
          </button>
        </form>
      </div>
    </section>
  );
}
