import { CircleAlert, Trash2 } from 'lucide-react';
import { CATEGORIES } from '../../lib/parser';
import type { LedgerEntry } from '../../lib/store';
import { rp } from '../../lib/format';

export function JournalCard({ entry, onRemove }: { entry: LedgerEntry; onRemove?: () => void }) {
  const r = entry.result;
  if (!r.ok || !r.category || !r.amount) {
    return (
      <div className="flex gap-3 rounded-2xl border border-amber/30 bg-amber-soft/60 p-4 text-sm">
        <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-ink" aria-hidden="true" />
        <div className="flex-1">
          <p className="font-semibold text-ink">Belum bisa dijurnal</p>
          <p className="mt-1 text-ink-soft">{r.error}</p>
        </div>
        {onRemove && (
          <button type="button" onClick={onRemove} className="self-start rounded-full p-1.5 text-ink-mute hover:bg-white hover:text-brick" aria-label="Hapus catatan ini">
            <Trash2 className="h-4 w-4" />
          </button>
        )}
      </div>
    );
  }
  const meta = CATEGORIES[r.category];
  return (
    <article className="relative overflow-hidden rounded-2xl border border-line bg-white shadow-[var(--shadow-soft)]">
      <header className="flex items-center justify-between gap-2 border-b border-line bg-cream/70 px-4 py-2.5">
        <span className="flex items-center gap-2 text-[12px] font-semibold text-ink-soft">
          <span className="h-2.5 w-2.5 rounded-full" style={{ background: meta.color }} aria-hidden="true" />
          Jurnal umum · {meta.label}
        </span>
        <span className="flex items-center gap-1">
          {r.credit === 'Modal Pemilik' && <span className="rounded-full bg-amber-soft px-2 py-0.5 text-[10.5px] font-bold text-amber-ink">Biaya implisit</span>}
          {onRemove && (
            <button type="button" onClick={onRemove} className="rounded-full p-1.5 text-ink-mute hover:bg-white hover:text-brick" aria-label={`Hapus jurnal ${meta.label}`}>
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          )}
        </span>
      </header>
      <table className="w-full text-[13px]">
        <caption className="sr-only">Jurnal untuk catatan: {entry.text}</caption>
        <thead>
          <tr className="text-[10.5px] uppercase tracking-wider text-ink-mute">
            <th scope="col" className="px-4 pb-1 pt-3 text-left font-bold">Akun</th>
            <th scope="col" className="px-4 pb-1 pt-3 text-right font-bold">Debit</th>
            <th scope="col" className="px-4 pb-1 pt-3 text-right font-bold">Kredit</th>
          </tr>
        </thead>
        <tbody className="num">
          <tr>
            <td className="px-4 py-1.5 font-semibold text-ink">{r.debit}</td>
            <td className="px-4 py-1.5 text-right font-semibold text-ink">{rp(r.amount)}</td>
            <td className="px-4 py-1.5 text-right text-ink-mute">–</td>
          </tr>
          <tr>
            <td className="py-1.5 pl-9 pr-4 text-ink-soft">{r.credit}</td>
            <td className="px-4 py-1.5 text-right text-ink-mute">–</td>
            <td className="px-4 py-1.5 text-right font-semibold text-ink">{rp(r.amount)}</td>
          </tr>
        </tbody>
      </table>
      <footer className="mx-4 mb-3 mt-2 border-t border-dashed border-line pt-2.5 text-[12px] leading-relaxed text-ink-mute">
        <span className="num font-semibold text-ink-soft">{r.rincian}</span>
        <span className="block">{r.catatan}</span>
      </footer>
    </article>
  );
}
