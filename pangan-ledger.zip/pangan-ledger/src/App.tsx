import { BrowserRouter, HashRouter, Route, Routes } from 'react-router-dom';
import { Layout } from './components/layout/Layout';
import { LedgerProvider } from './lib/store';
import Landing from './pages/Landing';
import Simulasi from './pages/Simulasi';
import BukuBiaya from './pages/BukuBiaya';
import RadarPage from './pages/Radar';
import Dasbor from './pages/Dasbor';
import Tpid from './pages/Tpid';
import Tentang from './pages/Tentang';
import NotFound from './pages/NotFound';

// Vercel memakai BrowserRouter (lihat vercel.json). Set VITE_ROUTER=hash untuk hosting statis tanpa rewrite.
const Router = import.meta.env.VITE_ROUTER === 'hash' ? HashRouter : BrowserRouter;

export default function App() {
  return (
    <LedgerProvider>
      <Router>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Landing />} />
            <Route path="simulasi" element={<Simulasi />} />
            <Route path="buku-biaya" element={<BukuBiaya />} />
            <Route path="radar" element={<RadarPage />} />
            <Route path="dasbor" element={<Dasbor />} />
            <Route path="tpid" element={<Tpid />} />
            <Route path="tentang" element={<Tentang />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </Router>
    </LedgerProvider>
  );
}
