import { clamp } from './format';

export interface ContractInput {
  luasHa: number;
  produksiKg: number;
  totalBiaya: number;
  marginFloorPct: number; // margin wajar di atas HPP, %
  ceiling: number; // Rp/kg
  hargaPasar: number; // Rp/kg saat panen
}

export interface ContractResult {
  hpp: number;
  floor: number;
  ceiling: number;
  hargaDiterima: number;
  labaTanpa: number;
  labaDengan: number;
  selisihPembeliPerKg: number; // + = pembeli bayar lebih, – = pembeli hemat
  selisihPembeliTotal: number;
  zona: 'petani' | 'pasar' | 'pembeli';
}

/** Harga patokan dibulatkan ke kelipatan Rp500 (praktik umum di pasar sayur). */
export function roundTo(value: number, step = 500) {
  return Math.round(value / step) * step;
}

export function hitungHpp(totalBiaya: number, produksiKg: number) {
  return produksiKg > 0 ? totalBiaya / produksiKg : 0;
}

export function hitungFloor(hpp: number, marginPct: number) {
  return roundTo(hpp * (1 + marginPct / 100));
}

/** Rumus inti: harga diterima petani = min(max(harga pasar, floor), ceiling) */
export function hargaKoridor(hargaPasar: number, floor: number, ceiling: number) {
  return clamp(hargaPasar, floor, Math.max(ceiling, floor));
}

export function hitungKontrak(input: ContractInput): ContractResult {
  const hpp = hitungHpp(input.totalBiaya, input.produksiKg);
  const floor = hitungFloor(hpp, input.marginFloorPct);
  const ceiling = Math.max(input.ceiling, floor);
  const hargaDiterima = hargaKoridor(input.hargaPasar, floor, ceiling);
  const labaTanpa = input.produksiKg * input.hargaPasar - input.totalBiaya;
  const labaDengan = input.produksiKg * hargaDiterima - input.totalBiaya;
  const selisihPembeliPerKg = hargaDiterima - input.hargaPasar;
  const zona = input.hargaPasar < floor ? 'petani' : input.hargaPasar > ceiling ? 'pembeli' : 'pasar';
  return {
    hpp,
    floor,
    ceiling,
    hargaDiterima,
    labaTanpa,
    labaDengan,
    selisihPembeliPerKg,
    selisihPembeliTotal: selisihPembeliPerKg * input.produksiKg,
    zona,
  };
}

export interface PayoffPoint {
  harga: number;
  tanpa: number; // juta rupiah
  dengan: number; // juta rupiah
}

export function payoffSeries(produksiKg: number, totalBiaya: number, floor: number, ceiling: number, max = 70000, step = 1000): PayoffPoint[] {
  const pts: PayoffPoint[] = [];
  for (let h = 0; h <= max; h += step) {
    const terima = hargaKoridor(h, floor, ceiling);
    pts.push({
      harga: h,
      tanpa: (produksiKg * h - totalBiaya) / 1_000_000,
      dengan: (produksiKg * terima - totalBiaya) / 1_000_000,
    });
  }
  return pts;
}
