import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { CONTOH_AWAL, parseExpense, type ParseResult } from './parser';
import { SIMULASI } from '../data/simulasi';

export interface LedgerEntry {
  id: string;
  text: string;
  waktu: string;
  result: ParseResult;
}

interface BiayaSimulator {
  totalBiaya: number;
  produksiKg: number;
  sumber: 'buku-biaya';
}

interface LedgerState {
  entries: LedgerEntry[];
  produksiKg: number;
  setProduksiKg: (v: number) => void;
  addEntry: (text: string) => LedgerEntry;
  removeEntry: (id: string) => void;
  replaceAll: (texts: string[]) => void;
  reset: () => void;
  biayaSimulator: BiayaSimulator | null;
  kirimKeSimulator: (v: Omit<BiayaSimulator, 'sumber'>) => void;
  lepasDariSimulator: () => void;
}

const LedgerContext = createContext<LedgerState | null>(null);
const STORAGE_KEY = 'pangan-ledger:buku-biaya:v1';

let counter = 0;
function makeEntry(text: string, offsetMin = 0): LedgerEntry {
  const d = new Date();
  d.setMinutes(d.getMinutes() - offsetMin);
  counter += 1;
  return {
    id: `${Date.now().toString(36)}-${counter}`,
    text,
    waktu: d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    result: parseExpense(text),
  };
}

function initialEntries(): LedgerEntry[] {
  return CONTOH_AWAL.map((t, i) => makeEntry(t, (CONTOH_AWAL.length - i) * 7));
}

function load(): { entries: LedgerEntry[]; produksiKg: number } | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (!Array.isArray(data.entries)) return null;
    return { entries: data.entries, produksiKg: Number(data.produksiKg) || SIMULASI.produksiKg };
  } catch {
    return null;
  }
}

export function LedgerProvider({ children }: { children: ReactNode }) {
  const saved = useMemo(load, []);
  const [entries, setEntries] = useState<LedgerEntry[]>(() => saved?.entries ?? initialEntries());
  const [produksiKg, setProduksiKg] = useState<number>(() => saved?.produksiKg ?? SIMULASI.produksiKg);
  const [biayaSimulator, setBiayaSimulator] = useState<BiayaSimulator | null>(null);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ entries, produksiKg }));
    } catch {
      /* penyimpanan tidak tersedia — abaikan */
    }
  }, [entries, produksiKg]);

  const addEntry = useCallback((text: string) => {
    const e = makeEntry(text);
    setEntries((prev) => [...prev, e]);
    return e;
  }, []);

  const removeEntry = useCallback((id: string) => setEntries((prev) => prev.filter((e) => e.id !== id)), []);

  const replaceAll = useCallback((texts: string[]) => {
    setEntries(texts.map((t, i) => makeEntry(t, (texts.length - i) * 5)));
  }, []);

  const reset = useCallback(() => {
    setEntries(initialEntries());
    setProduksiKg(SIMULASI.produksiKg);
  }, []);

  const value = useMemo<LedgerState>(
    () => ({
      entries,
      produksiKg,
      setProduksiKg,
      addEntry,
      removeEntry,
      replaceAll,
      reset,
      biayaSimulator,
      kirimKeSimulator: (v) => setBiayaSimulator({ ...v, sumber: 'buku-biaya' }),
      lepasDariSimulator: () => setBiayaSimulator(null),
    }),
    [entries, produksiKg, addEntry, removeEntry, replaceAll, reset, biayaSimulator],
  );

  return <LedgerContext.Provider value={value}>{children}</LedgerContext.Provider>;
}

export function useLedger() {
  const ctx = useContext(LedgerContext);
  if (!ctx) throw new Error('useLedger harus dipakai di dalam LedgerProvider');
  return ctx;
}

export function ringkasLedger(entries: LedgerEntry[]) {
  const perPos: Record<string, number> = {};
  let total = 0;
  for (const e of entries) {
    if (!e.result.ok || !e.result.category || !e.result.amount) continue;
    perPos[e.result.category] = (perPos[e.result.category] ?? 0) + e.result.amount;
    total += e.result.amount;
  }
  return { perPos, total };
}
