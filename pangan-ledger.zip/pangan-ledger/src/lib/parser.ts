/**
 * Parser catatan biaya berbasis kata kunci & regex (tanpa API).
 * Mengubah kalimat sehari-hari petani menjadi jurnal biaya (debit/kredit).
 *
 * Contoh:
 *  "beli NPK 2 karung 600 ribu"                → Biaya Pupuk 600.000 / Kas
 *  "upah 4 orang tanam 2 hari 100 ribu sehari" → Biaya TK (Upah) 4 × 2 × 100.000
 *  "saya dan istri nyemprot 1 hari"            → Biaya TK Keluarga (imputasi HOK) / Modal Pemilik
 */

export type CostCategory = 'benih' | 'pupuk' | 'pestisida' | 'alat' | 'upah' | 'tkKeluarga' | 'sewa' | 'lainnya';

export interface CategoryMeta {
  key: CostCategory;
  label: string; // nama pos (pendek)
  akun: string; // nama akun debit
  color: string;
}

export const CATEGORIES: Record<CostCategory, CategoryMeta> = {
  benih: { key: 'benih', label: 'Benih', akun: 'Biaya Benih', color: '#7FA88F' },
  pupuk: { key: 'pupuk', label: 'Pupuk', akun: 'Biaya Pupuk', color: '#1F5F4A' },
  pestisida: { key: 'pestisida', label: 'Pestisida', akun: 'Biaya Pestisida', color: '#C9822B' },
  alat: { key: 'alat', label: 'Mulsa, ajir & alat', akun: 'Biaya Mulsa, Ajir & Alat', color: '#A9B98A' },
  upah: { key: 'upah', label: 'Upah tenaga kerja', akun: 'Biaya TK Upahan', color: '#3E7F69' },
  tkKeluarga: { key: 'tkKeluarga', label: 'TK keluarga', akun: 'Biaya TK Keluarga', color: '#E2B57A' },
  sewa: { key: 'sewa', label: 'Sewa & penyusutan', akun: 'Biaya Sewa Lahan & Penyusutan', color: '#5B6F78' },
  lainnya: { key: 'lainnya', label: 'Lain-lain', akun: 'Biaya Lain-lain', color: '#B5A48A' },
};

export const CATEGORY_ORDER: CostCategory[] = ['benih', 'pupuk', 'pestisida', 'alat', 'upah', 'tkKeluarga', 'sewa', 'lainnya'];

/** Upah harian (HOK) standar desa yang dipakai untuk menilai tenaga kerja keluarga. */
export const UPAH_HOK = 100_000;

export interface ParseResult {
  ok: boolean;
  category?: CostCategory;
  amount?: number;
  debit?: string;
  credit?: string;
  rincian?: string; // penjelasan perhitungan
  catatan?: string; // catatan akuntansi
  error?: string;
}

const KEYWORDS: Record<Exclude<CostCategory, 'tkKeluarga' | 'lainnya'>, RegExp> = {
  sewa: /\b(sewa|kontrak lahan|penyusutan|susut alat|gadai lahan)\b/i,
  benih: /\b(benih|bibit|semai|semaian|persemaian|biji)\b/i,
  pupuk: /\b(pupuk|npk|urea|za|kcl|tsp|sp-?36|phonska|ponska|kompos|kandang|dolomit|kapur|organik|mutiara|kno3|gandasil)\b/i,
  pestisida: /\b(pestisida|insektisida|fungisida|herbisida|bakterisida|racun|obat( hama| tanaman)?|antracol|dithane|curacron|decis|furadan|gramoxone|regent|score|amistar|perekat)\b/i,
  alat: /\b(mulsa|ajir|bambu|tali|sprayer|tangki|cangkul|parang|plastik|selang|alat|mesin|terpal|keranjang|waring|polybag|tray)\b/i,
  upah: /\b(upah|buruh|borongan|gaji|ongkos kerja|pekerja|tukang|harian|orang)\b/i,
};

const FAMILY = /\b(saya|aku|istri|isteri|suami|anak|keluarga|sendiri|berdua|bertiga|bapak|ibu|adik|kakak)\b/i;
const WORK_VERB = /\b(kerja|nyemprot|semprot|menyemprot|tanam|nanam|menanam|panen|matun|menyiang|siang|nyiang|olah|cangkul|mupuk|memupuk|pasang|petik|metik|siram|nyiram|bantu|jaga|rawat)\b/i;
const CREDIT_UTANG = /\b(utang|hutang|ngutang|bon|kasbon|nanti dibayar|bayar belakang|tempo)\b/i;

const NUMBER_RE = /(rp\.?\s*)?(\d+(?:[.,]\d+)*)\s*(jutaan|juta|jt|ribuan|ribu|rbu|rb|k)?\b/gi;
const QTY_UNIT = /^\s*(karung|sak|botol|liter|ltr|kg|kilo|bungkus|bks|sachet|roll|rol|batang|ikat|orang|org|hari|hr|ha|hektar|hektare|kali|minggu|pohon|bedeng|lembar|meter|m|buah|pcs|unit|dus)\b/i;

function parseNumberToken(raw: string, scaled: boolean): number {
  // "150.000" atau "1.250.000" → pemisah ribuan
  if (/^\d{1,3}([.,]\d{3})+$/.test(raw) && !scaled) return Number(raw.replace(/[.,]/g, ''));
  if (/^\d{1,3}(\.\d{3})+$/.test(raw)) return Number(raw.replace(/\./g, ''));
  return Number(raw.replace(',', '.'));
}

interface MoneyHit {
  value: number;
  index: number;
  end: number;
}

function findMoney(text: string): MoneyHit[] {
  const hits: MoneyHit[] = [];
  NUMBER_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = NUMBER_RE.exec(text))) {
    const [full, rpPrefix, rawNum, unit] = m;
    const after = text.slice(m.index + full.length);
    const u = unit?.toLowerCase();
    const scale = u ? (u.startsWith('j') ? 1_000_000 : 1_000) : 1;
    if (!u && !rpPrefix && QTY_UNIT.test(after)) continue; // ini jumlah barang, bukan uang
    const value = parseNumberToken(rawNum, scale !== 1) * scale;
    if (!Number.isFinite(value)) continue;
    if (!u && !rpPrefix && value < 1000) continue; // angka kecil tanpa satuan → abaikan
    hits.push({ value, index: m.index, end: m.index + full.length });
  }
  return hits;
}

function countBefore(text: string, unit: RegExp): number | undefined {
  const m = text.match(unit);
  if (!m) return undefined;
  const n = Number(m[1].replace(',', '.'));
  return Number.isFinite(n) ? n : undefined;
}

function countFamily(text: string): number {
  const t = text.toLowerCase();
  if (/\bbertiga\b/.test(t)) return 3;
  if (/\bberdua\b/.test(t)) return 2;
  let n = 0;
  if (/\b(saya|aku)\b/.test(t)) n++;
  if (/\b(istri|isteri|suami)\b/.test(t)) n++;
  const anak = t.match(/(\d+)\s*anak/);
  if (anak) n += Number(anak[1]);
  else if (/\banak\b/.test(t)) n++;
  if (/\b(bapak|ibu|adik|kakak)\b/.test(t)) n++;
  const orang = t.match(/(\d+)\s*(orang|org)/);
  if (orang) n = Math.max(n, Number(orang[1]));
  return Math.max(n, 1);
}

const rp = (v: number) => `Rp${Math.round(v).toLocaleString('id-ID')}`;

export function parseExpense(input: string): ParseResult {
  const text = input.trim();
  if (!text) return { ok: false, error: 'Catatan masih kosong.' };
  const lower = text.toLowerCase();

  const money = findMoney(lower);
  const orang = countBefore(lower, /(\d+)\s*(?:orang|org|buruh|pekerja)\b/);
  const hari = countBefore(lower, /(\d+(?:[.,]\d+)?)\s*(?:hari|hr)\b/);
  const qtyMatch = lower.match(/(\d+(?:[.,]\d+)?)\s*(karung|sak|botol|liter|kg|bungkus|roll|batang|ikat|lembar)\b/);
  const perQty = qtyMatch ? new RegExp(`(per|/|@)\\s*${qtyMatch[2]}`).test(lower) || /@/.test(lower) : false;
  const perHari = /(sehari|per\s*hari|perhari|\/\s*hari|per\s*hok|\/\s*hok)/.test(lower);
  const perOrang = /(per\s*orang|perorang|seorang|\/\s*orang|masing)/.test(lower);

  const isFamily = FAMILY.test(lower) && (WORK_VERB.test(lower) || money.length === 0) && !/\b(beli|bayar|upah buruh)\b/.test(lower);

  // --- Kategori ---
  let category: CostCategory = 'lainnya';
  if (isFamily) category = 'tkKeluarga';
  else {
    const order: (keyof typeof KEYWORDS)[] = ['sewa', 'benih', 'pupuk', 'pestisida', 'alat', 'upah'];
    const found = order.find((k) => KEYWORDS[k].test(lower));
    if (found) category = found;
  }

  // --- Nominal ---
  let amount = 0;
  let rincian = '';
  if (category === 'tkKeluarga') {
    const persons = countFamily(lower);
    const days = hari ?? 1;
    if (money.length) {
      amount = money[money.length - 1].value;
      rincian = `Nilai yang dicatat: ${rp(amount)}`;
    } else {
      amount = persons * days * UPAH_HOK;
      rincian = `${persons} orang × ${days} hari × ${rp(UPAH_HOK)} (upah harian desa)`;
    }
  } else {
    if (!money.length) {
      return {
        ok: false,
        category,
        error: 'Nominal belum terbaca. Coba tulis seperti: "beli urea 1 karung 350 ribu" atau "upah 3 orang 2 hari 100rb sehari".',
      };
    }
    const base = money[money.length - 1].value;
    amount = base;
    const parts: string[] = [];
    if (perHari || perOrang) {
      const o = orang ?? 1;
      const h = hari ?? 1;
      amount = base * o * h;
      if (o > 1) parts.push(`${o} orang`);
      if (h > 1) parts.push(`${h} hari`);
      rincian = parts.length ? `${parts.join(' × ')} × ${rp(base)}` : `${rp(base)}`;
    } else if (perQty && qtyMatch) {
      const q = Number(qtyMatch[1].replace(',', '.'));
      amount = base * q;
      rincian = `${q} ${qtyMatch[2]} × ${rp(base)}`;
    } else {
      rincian = qtyMatch ? `${qtyMatch[1]} ${qtyMatch[2]}, total ${rp(base)}` : `Total ${rp(base)}`;
    }
  }

  const meta = CATEGORIES[category];
  let credit = 'Kas';
  let catatan = 'Pengeluaran tunai menambah biaya produksi musim ini.';
  if (category === 'tkKeluarga') {
    credit = 'Modal Pemilik';
    catatan = 'Biaya implisit: tidak ada uang keluar, tetapi tenaga keluarga tetap dihitung agar HPP tidak semu.';
  } else if (CREDIT_UTANG.test(lower)) {
    credit = 'Utang Usaha';
    catatan = 'Dibeli secara tempo, dicatat sebagai utang kepada kios/pengepul.';
  } else if (category === 'sewa' && /penyusutan|susut/.test(lower)) {
    catatan = 'Sewa lahan dan penyusutan alat dibebankan ke musim tanam berjalan.';
  }

  return {
    ok: true,
    category,
    amount: Math.round(amount),
    debit: meta.akun,
    credit,
    rincian,
    catatan,
  };
}

export const CONTOH_AWAL = [
  'beli NPK 2 karung 600 ribu',
  'upah 4 orang tanam 2 hari 100 ribu sehari',
  'saya dan istri nyemprot 1 hari',
  'pestisida 1 botol 150 ribu',
];

/** Rekap satu musim tanam cabai merah 0,5 ha — total Rp72 jt (data simulasi resmi). */
export const CONTOH_SATU_MUSIM = [
  'beli benih cabai merah 10 bungkus 5 juta',
  'pupuk kandang, NPK dan dolomit satu musim 16 jt',
  'pestisida dan fungisida satu musim 14 juta',
  'mulsa plastik dan ajir bambu 7 jt',
  'upah buruh olah lahan sampai panen 18 juta',
  'saya dan istri kerja kebun 30 hari',
  'sewa lahan setengah hektare dan penyusutan sprayer 6 juta',
];

export const SARAN_KETIK = ['beli urea 1 karung 350rb', 'mulsa 2 roll 1,2 jt', 'anak bantu panen 2 hari', 'sewa traktor 750 ribu'];
