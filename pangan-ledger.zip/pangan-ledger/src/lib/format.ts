const idNumber = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 });

/** Rp18.000 — tanpa spasi, pemisah ribuan titik. Nilai negatif → –Rp48.000 */
export function rp(value: number): string {
  const sign = value < 0 ? '–' : '';
  return `${sign}Rp${idNumber.format(Math.round(Math.abs(value)))}`;
}

/** Rp72 jt / Rp1,5 jt / –Rp48 jt */
export function rpJt(value: number, digits = 1): string {
  const sign = value < 0 ? '–' : '';
  const jt = Math.abs(value) / 1_000_000;
  const str = jt.toLocaleString('id-ID', { maximumFractionDigits: digits });
  return `${sign}Rp${str} jt`;
}

/** Bertanda: +Rp8 jt / –Rp48 jt */
export function rpJtSigned(value: number, digits = 1): string {
  if (value > 0) return `+${rpJt(value, digits)}`;
  return rpJt(value, digits);
}

/** Rp20 rb (sumbu grafik) */
export function rpRb(value: number): string {
  if (value === 0) return '0';
  return `${(value / 1000).toLocaleString('id-ID', { maximumFractionDigits: 1 })} rb`;
}

export function num(value: number, digits = 0): string {
  return value.toLocaleString('id-ID', { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

export function pct(value: number, digits = 2): string {
  return `${value.toLocaleString('id-ID', { minimumFractionDigits: digits, maximumFractionDigits: digits })}%`;
}

export function kg(value: number): string {
  if (Math.abs(value) >= 1000) {
    const t = value / 1000;
    return `${t.toLocaleString('id-ID', { maximumFractionDigits: 1 })} ton`;
  }
  return `${idNumber.format(Math.round(value))} kg`;
}

export function clamp(v: number, lo: number, hi: number) {
  return Math.min(Math.max(v, lo), hi);
}
