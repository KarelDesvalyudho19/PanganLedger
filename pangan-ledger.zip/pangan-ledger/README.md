# PANGAN-LEDGER — Purwarupa

Platform web (PWA) yang memadukan kecerdasan buatan dan akuntansi biaya untuk melindungi petani hortikultura dan menstabilkan harga pangan di Provinsi Bengkulu (pilot: Rejang Lebong & Kepahiang).

> Purwarupa pendukung esai. **Seluruh data bersifat simulasi.**

## Menjalankan

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # hasil di dist/
npm run typecheck  # opsional, pemeriksaan tipe TypeScript
```

Butuh Node.js 18+.

## Deploy ke Vercel

1. Unggah folder ini ke repositori GitHub.
2. Di Vercel: **Add New → Project**, pilih repositori. Framework terdeteksi otomatis sebagai Vite.
3. Build command `npm run build`, output `dist`. `vercel.json` sudah menangani rute SPA (/simulasi, /radar, dst.).

Untuk hosting statis tanpa aturan rewrite (mis. GitHub Pages), build dengan `VITE_ROUTER=hash npm run build`.

## Halaman

| Rute | Isi |
|---|---|
| `/` | Landing: masalah, solusi, cara kerja, dampak, peta jalan, mitra |
| `/simulasi` | Simulator Kontrak Koridor: grafik payoff, tiga skenario |
| `/buku-biaya` | Buku Biaya Tani: obrolan → jurnal debit/kredit, HPP real-time |
| `/radar` | Radar Tanam & Harga: prakiraan 8 minggu, peta panas, rekomendasi |
| `/dasbor` | Kontrak aktif, alokasi pasokan, rute hijau |
| `/tpid` | Dasbor pemerintah/TPID: KPI, disparitas harga, peringatan dini |
| `/tentang` | Landasan teori, perbandingan, risiko & mitigasi, tim |

## Struktur

```
src/
  data/        data simulasi (simulasi.ts = angka resmi: HPP Rp18.000, floor Rp20.000, ceiling Rp40.000)
  lib/         contract.ts (rumus koridor), parser.ts (parser biaya regex), store.tsx (state + localStorage), format.ts
  components/  layout/, ui/, charts/ (Recharts), landing/, ledger/, dashboard/
  pages/       satu file per halaman
```

Rumus inti: `harga diterima = min(max(harga pasar, floor), ceiling)`, dengan `floor = HPP × (1 + margin)` dibulatkan ke kelipatan Rp500.

Parser Buku Biaya mengenali pos (pupuk, pestisida, benih, upah, TK keluarga, sewa, alat) dan nominal ("600 ribu", "1,5 jt", "100rb", "Rp150.000"), termasuk pola "4 orang × 2 hari × 100 ribu sehari". Tenaga keluarga tanpa nominal dinilai Rp100.000/HOK dan dijurnal ke Modal Pemilik. Catatan biaya tersimpan di localStorage peramban.

Nama anggota tim di halaman Tentang masih placeholder (`[Nama anggota]`) — ubah di `src/pages/Tentang.tsx`.
